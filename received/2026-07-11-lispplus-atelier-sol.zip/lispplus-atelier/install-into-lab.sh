#!/usr/bin/env bash
set -euo pipefail
SOURCE="$(cd "$(dirname "$0")" && pwd)"
TARGET="${1:-/home/gauss/Claude-Code-Lab/experiments/lispplus/atelier}"
mkdir -p "$TARGET"
cp -a "$SOURCE/kernel" "$SOURCE/reliquaries" "$SOURCE/instruments" "$SOURCE/toys" "$SOURCE/strata" "$TARGET/"
cp "$SOURCE/CANON.md" "$SOURCE/MANIFEST.sexp" "$SOURCE/run-all.sh" "$SOURCE/static-check.py" "$TARGET/"
printf 'Installed Lisp+ Atelier cabinet to %s\n' "$TARGET"
printf 'Run: cd %q && ./static-check.py && ./run-all.sh\n' "$TARGET"
