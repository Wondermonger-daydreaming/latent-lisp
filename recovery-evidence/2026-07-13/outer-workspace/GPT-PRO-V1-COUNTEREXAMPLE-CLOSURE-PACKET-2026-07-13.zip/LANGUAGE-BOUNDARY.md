# LANGUAGE-BOUNDARY.md

## Mneme / Lisp+ language-boundary audit

**Audit target:** `Wondermonger-daydreaming/latent-lisp`  
**Pinned revision:** `9e9c031a720cd40559297c9d8bb07bf8137adb54`  
**Audit date:** 2026-07-13  
**Primary scope:** `mneme/latent-mvp/`, `mneme/language-a/`, `mneme/canon/`, `mneme/CONSTITUTION*.md`, `mneme/v0.3/constitution/BOOK-0.md`, and `mneme/verify-all.sh`.

This is a source audit of the pinned repository state. I inspected the implementation, test programs, CI shell, canonicalization prototype, and constitutional documents. I did **not** independently rerun SBCL in this environment; therefore references to “7 checks,” “18/0,” “9/0,” or “14/14” describe what the repository’s scripts and documentation currently assert and count, not a freshly reproduced execution transcript.

The audit deliberately does not promote every `mneme/atelier/` specimen into language semantics. Those specimens carry local, executable distinctions, but they do not run through one shared evaluator or object model. Their exclusion from the core is itself a finding: a CI umbrella can aggregate experiments without thereby creating one language.

---

## Executive ruling

The repository currently contains a serious **embedded epistemic runtime**, several executable **semantic-profile validators**, a useful hostile-data decoder, and a draft canonical representation. It does not yet contain one implementation-independent Lisp+ language.

The decisive fact is not the absence of a custom parser. The decisive fact is that the claimed distinctions are not closed under the host language.

At the pinned revision there are two semantic centers:

1. `mneme/latent-mvp/kernel.lisp` is the broad v0 kernel used by `conformance-walk.lisp` to demonstrate the seven laws. It exports raw `defstruct` constructors, accessors, mutable authority state, and receipt constructors. It enforces a preferred route, not an invariant.
2. `mneme/latent-mvp/kernel-hardened.lisp` is the narrower v1 kernel used by the adversarial and process-boundary suites. It makes claim, attestation, capability, and receipt constructors private and validates mint provenance. It does **not** contain the full seven-law object model, Language A validator, canonical codec, latent reader, inference discipline, retrieval semantics, or the neutral Book-0 calculus.

The repository itself says migration of the v0 bricks onto the hardened kernel is still owed. Consequently, the current CI floor is an **aggregate of neighboring semantic systems**, not a conformance suite for one operational semantics.

There is also a presently exploitable v1 defect inside the documented client surface: propositions admit mutable strings, while both ingress and exported readers use `copy-tree`. `copy-tree` copies cons cells but not strings. A caller can therefore mutate a proposition after verification while the stored fingerprint remains unchanged, then successfully raise the now-altered claim with the old attestation. This defeats the advertised “private immutable copy” and exact-target invariant without using `mneme::` internals.

The shortest accurate description is:

> **Mneme is currently an epistemic framework implemented as several Common Lisp libraries, with a hardened EDSL nucleus and executable profile tests. Lisp+ becomes a programming language when the nucleus—not merely its API conventions—is specified and enforced by an evaluator, module/effect boundary, canonical reader/codec, and implementation-independent transition semantics.**

---

## 1. The criterion: semantic closure, not punctuation

For this audit, a distinction counts as a **language semantic** only when all of the following hold.

### 1.1 Contextual closure

Every well-formed Lisp+ program must encounter the rule. A client must not be able to evade it by calling another constructor, mutating a returned object, naming a different package, dynamically rebinding a printer variable, invoking an FFI function, or passing through an ordinary Common Lisp path that the rule forgot.

### 1.2 Representation independence

The law must be stated over abstract values and transitions, not over one implementation’s `defstruct`, package visibility, hash-table identity, `gensym`, printer, or filesystem behavior.

### 1.3 Cross-implementation determinacy

Two conforming implementations receiving the same program and explicit inputs must agree on the relevant observable result: whether a warrant is genuine, what claim it targets, whether authority is live, what survives revival, which condition is raised, and what bytes identify an artifact.

### 1.4 Compositional preservation

The distinction must survive module import, macro expansion, compilation, optimization, serialization, process boundaries, repeated handoffs, mutation, concurrency, and foreign calls. A law that holds only immediately after one constructor call is a checked convention, not yet a language invariant.

### 1.5 A specified escape hatch

A language may expose an unsafe FFI. It may not quietly let the host FFI dissolve its laws while continuing to call the result authenticated. Unsafe transitions must be explicit, effect-typed, and incapable of minting privileged Lisp+ values.

### 1.6 Enforcement scale used below

| Level | Meaning |
|---|---|
| **P0 — prose** | A constitutional intention or comment with no current execution path. |
| **P1 — test/convention** | Demonstrated by fixtures or expected client behavior, but bypassable through ordinary host operations. |
| **P2 — library check** | A function checks the rule when that function is called. Callers can route around it or mutate the result. |
| **P3 — façade invariant** | The documented exported API prevents a class of forgery, under an explicit external-client threat model. |
| **P4 — language-closed invariant** | Every language evaluation path preserves the rule, including modules, effects, mutation, serialization, and FFI. |
| **P5 — implementation-independent law** | The rule has a normative representation/operational specification and independent implementations agree. |

The current implementation reaches **P3** in several important places. It does not presently reach P4 or P5.

---

## 2. Repository topology: five adjacent semantic systems

### 2.1 v0 shared kernel: broad vocabulary, forgeable representation

`mneme/latent-mvp/kernel.lisp` defines claims, grades, witnesses, certificates, judgments, receipts, authority, verification, grade raising, serialization, and revival. `conformance-walk.lisp` loads this file and walks L1–L7.

Its virtues are conceptual consolidation and executable examples. Its decisive weakness is representational: it exports `make-claim`, `make-witness`, `make-certificate`, `make-judgment`, `make-receipt`, mutable `defstruct` accessors, `*authority*`, and `*clock*`. Therefore a caller can manufacture the very states whose provenance the laws purport to regulate.

### 2.2 v1 hardened kernel: narrower but genuinely generative

`mneme/latent-mvp/kernel-hardened.lisp` introduces:

- an implementation package exporting nothing;
- `mneme.client` and `mneme.operator` façade packages;
- private constructors and private `%accessors`;
- a procedure registry;
- bearer verifier capabilities backed by a live registry;
- a mint registry for attestations;
- prospective and warrant-level retrospective revocation;
- target and scope checks at `raise-claim`;
- hostile serialized-data decoding;
- inert revival;
- typed Mneme conditions.

These are real runtime mechanisms. They are not merely notation. Their current jurisdiction, however, is “a caller restricted to the documented client façade.” Common Lisp packages do not provide confinement, and several values remain mutable through shared leaves.

### 2.3 Language A: structural deposition validator

`mneme/language-a/validator.lisp` validates a separate s-expression `judgment` record. It explicitly says it reuses the spirit of the kernel but none of its structs. Its twelve checks concern record coherence: identifiers, references, status vocabulary, confidence range, support links, receipt names, boundary fields, bounded absence, unresolved fields, answer support, external-verification labels, and named procedures.

This is a profile validator. It is not integrated with v1 attestation minting, capability custody, code identity, or artifact verification. In particular, a record that says a certificate issuer is non-model can pass without any generative proof that such an issuer exists.

### 2.4 Canonicalization prototype: Language-A representation only

`mneme/canon/canonical.lisp` defines `mneme-canon/0` for Language-A records. It sorts record clauses, preserves data-list order, refuses many object types, emits a deterministic string, and demonstrates resistance to ambient printer settings.

It is not the v1 claim fingerprinting path. It is not run by `mneme/verify-all.sh`. It strips symbol package identity, returns a string from a function named `canonical-bytes`, uses SBCL-specific UTF-8 and MD5 helpers, and explicitly pins float rendering to SBCL 2.4.6. Its reader reads the first form but does not reject trailing forms or verify that the input itself was canonical.

### 2.5 Constitutions and atelier: proposed laws and design probes

`mneme/v0.3/constitution/BOOK-0.md` and `mneme/CONSTITUTION-v0.5-mneme-skeleton.md` are design documents with stronger and broader commitments than the current runtime. `mneme/atelier/` contains executable instruments for individual distinctions. Neither is yet the normative semantics of the v1 evaluator—because there is no v1 evaluator encompassing them.

---

## 3. Semantic-commitment ledger

The following tables identify the current commitments, where they are enforced, their present strength, and where they belong in a reference language.

### 3.1 v0 `latent-mvp/kernel.lisp`

| Current commitment | Enforcement point | Present status | Proper destination |
|---|---|---:|---|
| A new claim defaults to `:asserted`. | `defstruct claim` default. | P2 on constructor path; caller may pass another grade or mutate it. | Abstract `Claim` constructor/evaluator rule. |
| Warrant modes map event kinds to grades. | `*grades*`, `grade-for`. | P1/P2; mutable global alist. | Mneme profile policy, not base syntax. |
| A witness supports only the exact proposition it faces. | `witness-supports-p` uses `equal` on target/proposition. | P2; witness and claim are caller-constructible and mutable. | Typed evidence relation in operational semantics. |
| Support also requires an admissible kind, `:supports`, verified status, and provenance. | `witness-supports-p`. | P2; all fields forgeable. | Profile warrant-admissibility policy. |
| Authority maps principals to issuable event kinds. | `*authority*`, `may-issue-p`. | P1/P2; exported mutable global. | Runtime authority store/module grants. |
| Verification re-runs a procedure and compares actual to expected. | `verify-proposition`; `(fdefinition proc)` and `funcall`. | P2; procedure is caller-named host code. | Evaluator-controlled procedure reference and effect semantics. |
| Verification emits a certificate with target, verifier, verdict, event kind, time, and procedure digest. | `make-certificate` in `verify-proposition`. | P1; the same constructor is exported to callers. | Opaque generative warrant value. |
| A report cannot raise a claim; a certificate is required. | `certificate-p` check in `raise-claim`. | P1/P2; nominal shape is forgeable. | Mint-provenance rule. |
| Certificate target, verdict, and issuer authority are checked. | `raise-claim`. | P2; fields are caller-controlled. | Warrant-consumption transition. |
| Grade authentication after handoff rechecks accepted certificates. | `authenticate-grade`. | P2; accepted certificates may be forged. | Successor-side warrant validation. |
| Model production yields a `judgment`, not truth. | `defstruct judgment`; museum brick/documentation. | P1; no evaluator forces model calls to return it. | Mneme profile effect operation. |
| Freeze serializes proposition, grade, and `as-of`. | `freeze`, schema 1. | P2; serialized grade is trusted on revival. | Artifact codec with inert standing. |
| Revival is reconstruction and marks freshness `:aging`. | `mneme-revive`. | P2; raw text can choose its own grade. | Core revival transition and lineage. |
| Handoff follows prepared → committed → received. | `prepare`, `commit`, `receive`. | P1/P2; `make-receipt` and mutable accessors are exported. | Store protocol library over a normative artifact transition. |
| Receipt content is checked with a digest. | `receive`. | P2; MD5 is integrity-shaped, not attacker-resistant. | Codec/integrity layer, not a truth law. |
| Failures signal errors. | `ensure`. | P1; generic host errors, not a complete language failure algebra. | Structured condition semantics. |

**Conclusion for v0:** it is an executable model of the intended route and a useful teaching kernel. It is not an authority-bearing runtime, because all privileged states are ordinary exported Common Lisp structs.

### 3.2 v1 `latent-mvp/kernel-hardened.lisp`

| Current commitment | Enforcement point | Present status | Proper destination |
|---|---|---:|---|
| Implementation constructors are not exported. | Empty-export `mneme` package; façade packages. | P3 against a voluntarily restricted client; P1 in the same image. | Sealed runtime types/module isolation. |
| Client readers are not `setf`-able. | Plain reader functions. | P3 for direct slot mutation. | Immutable abstract values. |
| Claim propositions are copied on ingress and egress. | `%canonicalize-proposition`, `claim-proposition`, both using `copy-tree`. | **Unsound P2/P3:** mutable strings are shared. | Deep immutable datum representation. |
| Claims start unauthenticated. | `assert-claim`; private `%make-claim`. | P3 except for same-image internals and mutable-leaf substitution. | Core claim-construction rule. |
| Only registered procedure IDs may be verified. | `*procedure-registry*`, `register-procedure`, `verify-proposition`. | P3 against caller-supplied `fdefinition`. | Module/linker procedure table. |
| Procedure implementation, version, and effect are registered together. | `procrec`. | P1/P2; version/effect are declarations only, and ID may be overwritten. | Compiler-produced code ID and checked effect row. |
| Authority is represented by an opaque bearer capability. | `%make-cap`, `*capability-tokens*`. | P3 on the client façade; custody and operator access remain host conventions. | Runtime capability value and module grant. |
| Capability scopes cannot be widened by mutating the input lists. | `grant-authority` shallow-copies lists of symbols. | P3 for those two lists. | Capability construction semantics. |
| Capability validity requires registry membership, object identity, valid status, event kind, and procedure ID. | `%cap-live-p`. | P3 in one process image. | Authority-store transition. |
| Proposition grammar is `(:equals (:call PROC-ID INPUT) EXPECTED)`. | `%canonicalize-proposition`. | P2/P3; an accidental MVP grammar unless constitutionalized. | Mneme profile library or tiny core proposition AST. |
| Serialized/claim data is restricted to recursive inert CL data at depth ≤32. | `%safe-data-p`. | P2/P3; still inherits CL numeric, symbol, string, and package semantics. | Normative datum grammar and resource limits. |
| Verification re-runs the registered implementation. | `verify-proposition`. | P3, but arbitrary host closures and host errors remain. | Evaluator-controlled effect execution. |
| A minted attestation records principal, event kind, procedure ID/version, target fingerprint, scope, verdict, validity, and issue time. | `%make-att` inside `verify-proposition`. | P3 in one image. | Opaque `Warrant` value. |
| Attestation genuineness is mint-registry membership, not struct shape. | `*attestation-mint*`, `raise-claim`. | P3; genuinely generative within the façade. | Core mint-provenance law. |
| A warrant must target the claim fingerprint. | `raise-claim`. | P3 only for the stored fingerprint; fingerprint excludes `as-of`, lineage, and scope and can go stale after string mutation. | Exact located-claim identity. |
| A warrant must support rather than refute. | `raise-claim`. | P3. | Warrant-admissibility rule. |
| A warrant must be currently valid and not revoked. | `raise-claim`. | P3 at raise time. | Dynamic standing/revocation semantics. |
| Warrant scope must be the same object as supplied to `raise-claim`. | `eq` scope check. | P2/P3; arbitrary mutable host objects and object identity define scope. | Canonical, structural scope relation. |
| Raising creates a new claim with the attestation added. | `raise-claim`. | P3; duplicate reuse is allowed and no claim registry exists. | Immutable claim transition with set semantics. |
| Revoking a capability blocks future verification. | `revoke-authority`. | P3 in one image. | Prospective revocation transition. |
| Capability revocation cascades to warrants it minted. | `*mint-by-token*`, `*attestation-revoked*`. | P3 at subsequent raise. | Defined warrant-revocation rule. |
| A single warrant can be revoked. | `revoke-attestation`. | P3 at subsequent raise. | Warrant revocation. |
| Claims already raised remain “authenticated” after revocation. | `claim-authenticated-p` checks only non-empty list. | Explicitly unresolved; current behavior is accidental policy. | `standing` must consult current revocation state. |
| Freeze turns live warrants into inert predecessor records. | `%warrant->data`, `freeze`. | P3 for live-authority stripping. | Artifact serialization law. |
| Freeze preserves only currently authenticated warrants. | `freeze` ignores existing predecessor warrants. | Current multi-hop lineage loss. | Loss-preserving transitive lineage. |
| Hostile input disables `#.` and `#S`, disables `*read-eval*`, requires one form, checks size/schema/inertness. | `%safe-readtable*`, `%safe-decode`. | Strong P3 decoder discipline. | Normative reader/codec. |
| Prepare emits text plus a private receipt. | `prepare`. | P3 for receipt construction. | Store library. |
| Commit writes temp then renames. | `commit`. | P2; no guard that receipt is `:prepared`, so state can rewind. | Store implementation, not language law. |
| Receive requires `:committed` and checks digest. | `receive`. | P3 on that path. | Store library plus artifact integrity. |
| Revive from a receipt internally performs receive, marks `:revived`, and cannot immediately repeat. | `revive`. | P3 for the direct test; recommitting the same prepared object can reset it. | Monotone handoff transition. |
| Revive also accepts raw text. | `revive` branch. | P2; bypasses receipt chronology and custody. | Separate `decode-artifact` operation, explicitly not a receipt transition. |
| Revival grants no live authenticated warrants. | `revive`: authenticated list is empty. | Strong P3. | Core no-authority-laundering law. |
| Predecessor warrants survive as inert testimony. | `revive`. | P2/P3 for one hop; records are freely forgeable raw data and dropped on the next freeze. | Signed/identified lineage plus represented loss. |
| Reauthentication requires explicit replay. | `replay-and-attest`. | P3 on current client route. | Library composition over core verify/raise operations. |
| Failures use typed Mneme conditions. | six condition classes and `ensure`. | P2/P3 for checks inside the kernel; registered host procedures can signal arbitrary host conditions. | Normative failure algebra and FFI wrapping. |

**Conclusion for v1:** this is the strongest language-like nucleus in the repository. Its mint registry and inert revival are genuine runtime semantics. Yet it remains a one-image Common Lisp service with a façade threat model, not a language-closed evaluator.

### 3.3 Language A `language-a/validator.lisp`

Each check is enforceable only when `validate-judgment` is called. The validator returns `:valid` but does not seal or type the mutable record, so post-validation mutation remains possible.

| Commitment | Enforcement point | Present status | Proper destination |
|---|---|---:|---|
| The top-level record begins with the package-specific symbol `judgment`. | Check 00 in `validate-judgment`. | P2; host package identity leaks into grammar. | Reader-level grammar with package-independent tags. |
| Claim IDs are unique. | Check 01. | P2. | Profile schema validator. |
| `derived-from` references resolve. | Check 02. | P2. | Profile schema/type checker. |
| Judgment status is answer/uncertain/refusal. | Check 03. | P2. | Mneme profile vocabulary. |
| Confidence, when present, lies in `[0,1]`. | Check 04. | P2; confidence semantics are otherwise unspecified. | Profile policy/type. |
| A support edge faces an existing claim. | Check 05. | P2; existence is not evidential authenticity. | Typed evidence graph. |
| A cited artifact appears in the record’s own manifest. | Check 06. | P2; manifest membership is self-reported. | Artifact resolver plus profile validation. |
| Observed/bounded-absence claims contain corpus, procedure, and as-of. | Check 07. | P2; field presence, not truth. | Located-claim schema. |
| Bounded absence also says `scope-complete t`. | Check 07. | P1/P2; completeness is asserted, not proven. | Completion warrant type. |
| A bounded claim is not widened across corpus/version. | Check 08. | P2. | Scope-subsumption semantics. |
| Previously unresolved fields are preserved unless explicitly resolved. | Check 09. | P2 and cooperative; erased history cannot be reconstructed. | Represented-loss/lineage rule. |
| A definite answer has at least one claim. | Check 10, gated by mutable `*definite-answers-need-claims*`. | P1/P2. | Mneme profile policy. |
| `:externally-verified` names a non-model certificate issuer. | Check 11. | P1/P2; issuer is an ordinary record field. | Integration with generative v1 warrants. |
| Evidential procedures are named rather than hidden. | Check 12. | P2; naming does not enforce code/effect identity. | Procedure reference/effect metadata. |
| Validation signals the first typed violation in deterministic check order. | `*checks*`, `validate-judgment`. | P2; `*checks*` and function definitions are mutable host state. | Normative validation result set/order if order matters. |
| The validator refuses to claim truth or hidden-cognition fidelity. | Printed refusals and comments. | P0/P1 epistemic discipline. | Profile documentation, not evaluator semantics. |

**Conclusion for Language A:** it is a coherent linter for depositions. It is not a proof-producing subsystem until its records refer to runtime-minted warrants, stable artifacts, and code IDs, and until validated values cannot be altered without invalidating their status.

### 3.4 `canon/canonical.lisp`

| Commitment | Enforcement point | Present status | Proper destination |
|---|---|---:|---|
| Canon version is `mneme-canon/0`. | `*canon-version*`. | P1/P2 draft. | Versioned normative codec. |
| Scope is Language-A judgment records only. | `canon` grammar/comments. | P2. | Profile codec, not whole-language core ID. |
| Record clause order is non-semantic and sorted. | record detection and `stable-sort`. | P2. | Grammar-specific canonicalization. |
| Data-list order is semantic and preserved. | `canon`. | P2. | Grammar-specific canonicalization. |
| Cycles, improper lists, and unreadable atoms are refused. | `list-elements`, `canon-atom`. | P2. | Normative decoder/encoder behavior. |
| Symbols are downcased and package-stripped. | `safe-sym-name`, `canon-atom`. | P2 but collision-prone. | Replace with lexical/module-qualified identifiers or explicit strings. |
| Integers are decimal. | `canon-atom`. | P2 and portable. | Normative numeric encoding. |
| Floats use SBCL 2.4.6’s printer. | `canon-float`. | P1/P2, explicitly implementation-pinned. | IEEE bit-pattern, decimal spec, or exclusion from canonical core. |
| Strings are escaped and described as UTF-8. | `canon-string`; MD5 helper uses `sb-ext:string-to-octets`. | P2 on SBCL. | Normative Unicode and byte encoding. |
| `canonical-bytes` returns the canonical string. | `canonical-bytes`. | Naming/type mismatch. | Return an octet vector; expose text separately. |
| Reader disables read-eval and fixes package/float defaults. | `canonical-read`. | P2. | Normative parser. |
| Reader accepts only the first form it reads. | `canonical-read` ignores the returned index. | Defect: trailing data accepted. | One-form decoder with full-consumption check. |
| Canonicalization is not integrity or truth. | explicit comments. | Correct scope statement. | Keep this distinction. |
| MD5 content address is pedagogical. | `md5-hex`. | P1/P2, not cryptographic. | SHA-256 or stronger after canonical bytes. |
| Canon tests demonstrate fixpoint and ambient-printer resistance. | script body. | P1; not in `verify-all.sh`. | Cross-implementation golden vectors. |

### 3.5 CI and conformance topology

`mneme/verify-all.sh` calls five floors:

1. v0 seven-law conformance walk;
2. v1 adversarial façade suite;
3. v1 two-process boundary suite;
4. atelier specimens;
5. Language-A fixtures.

This is good project hygiene, but it is not one language conformance suite. The script does not execute the canonicalization prototype. The top-level README also says 13 forgeries + 3 lawful checks = 16, while the latent-MVP README and harness expect 15 + 3 = 18. That discrepancy is documentation drift, not semantics, but it is exactly the sort of drift a machine-readable language spec should prevent.

---

## 4. Classification requested by the audit

## 4.1 Ordinary Common Lisp library abstractions

The following are presently ordinary host-library machinery. That is not an insult; every language implementation contains library machinery. The boundary issue is that these mechanisms currently *define* behavior without a host-independent specification.

- `defstruct` representations for claims, witnesses, certificates, judgments, capabilities, attestations, procedure records, and receipts.
- Plain functions for construction, querying, validation, serialization, and replay.
- Common Lisp conditions and `handler-case`-style tests.
- Alists and hash tables used as authority, procedure, mint, and revocation registries.
- Package export lists used to describe client/operator APIs.
- `copy-tree` and `copy-list` used as immutability surrogates.
- Dynamic variables such as `*clock*`, `*authority*`, `*checks*`, printer variables, package variables, and validator policy switches.
- Host filesystem operations, pathnames, temp files, and `rename-file` for handoff persistence.
- Shell and grep-based conformance counting.
- SBCL contribs and extensions (`sb-md5`, `sb-ext:string-to-octets`).
- `funcall` of host closures as the meaning of registered Lisp+ procedures.

These become an implementation of a language only after their observable behavior is specified independently and inaccessible host operations cannot mint or mutate abstract language values.

## 4.2 Enforceable runtime semantics presently achieved

Within the bounded v1 client façade, the following are real and valuable runtime rules:

- `assert-claim` creates a claim with no authenticated warrants.
- There is no exported authenticated-claim or attestation constructor in `mneme.client`.
- A warrant must have been minted by the current runtime, not merely shaped like an attestation.
- Verification dispatches through a registered procedure ID rather than caller-selected `fdefinition`.
- A live capability must authorize the event kind and procedure ID.
- Verification re-runs the registered implementation and records support/refutation.
- Raising checks mint provenance, revocation, target fingerprint, support verdict, validity, and scope.
- Capability revocation blocks future verification and marks its prior warrants revoked for future raises.
- Serialized warrants revive as inert predecessor data, never live authority.
- The v1 hostile decoder disables read-time evaluation and struct literals, rejects trailing forms, bounds input size/depth, and checks schema/inertness.
- Several failure classes are typed.

These are the parts to preserve as the seed of a reference operational semantics. They should not be discarded merely because the current host boundary is incomplete.

## 4.3 Host-language conventions currently masquerading as semantics

The following are not presently language laws; they are conventions about how trusted Common Lisp code behaves:

- “Untrusted code uses only `mneme.client`.” Any same-image code can name `mneme.operator:grant-authority`, and any code can access `mneme::` symbols.
- “The operator is trusted.” Common Lisp packages do not authenticate callers or restrict imports.
- “Registered procedures are preferably pure.” The `effect` field is never checked.
- “Procedure version names code identity.” The version is caller-declared and the same ID may be rebound to a different closure.
- “A copied tree is immutable.” Mutable non-cons leaves, notably strings, remain shared.
- “Scope equality is object identity.” `eq` over arbitrary host objects is the current rule only because no scope calculus exists.
- “Printed representation identifies a proposition.” `%fingerprint` uses ambient `prin1-to-string` and CL package/printer behavior.
- “A principal symbol identifies an authority.” No identity or caller binding exists.
- “Time is a monotone logical event.” It is a mutable global integer initialized to 9000.
- “Global registries are atomic.” No concurrency semantics or synchronization is specified.
- “Host errors are acceptable verifier failures.” Registered procedures can signal arbitrary conditions outside Mneme’s typed failure vocabulary.
- “File rename supplies commit semantics.” Atomicity and crash behavior depend on host filesystem and implementation.

## 4.4 Profile-specific Mneme mechanisms

These should not automatically become universal Lisp+ syntax or neutral constitutional law:

- Language A’s `judgment` record and twelve coherence checks.
- Status vocabulary `:answer`, `:uncertain`, `:refusal`.
- Grade/warrant vocabulary such as `:observed`, `:executed`, `:tested`, `:derived`, and `:bounded-absence`.
- The current unary `:equals` / `:call` proposition grammar.
- The rule that model inference returns a `judgment` rather than a bare value.
- Latent-reader versus structural-reader duality.
- Context mortality, succession/deposit, noema, vestigium, scar, loss-report, and retrieval-as-ranked-traces.
- Mneme-specific policies for confidence, bounded absence, unresolved fields, and deposition.
- Provider adapters and model-specific inference normalization.

Several of these are excellent profile laws. They should be implemented as a **Mneme standard profile over Lisp+ Core**, rather than smuggled into the neutral evaluator merely because the first implementation needs them.

## 4.5 Candidate Lisp+ constitutional laws

The following survive the profile-neutrality test and deserve consideration as Lisp+ constitutional law:

1. **Assertion is not authentication.** Constructing or reporting a claim cannot create authenticated standing.
2. **Authentication is generative, not structural.** A warrant is genuine because a privileged transition minted it, not because a record has the right fields.
3. **Authority is explicit and ambient authority is forbidden.** Every authority-bearing transition consumes an inspectable grant or capability.
4. **Evidence is located.** A warrant binds to a canonical claim identity including proposition, scope, temporal boundary, code/policy identity, and any other dimension that changes admissibility.
5. **Production is not truth.** Effects may establish that an invocation occurred and what it returned; they do not thereby establish the world-claim represented by the output.
6. **Effectful epistemic operations are named and enforced.** Verification, inference, retrieval, observation, persistence, and external calls cannot hide beneath an ordinary “pure” value.
7. **Revival never launders authority.** Serialization transfers data and lineage; live authority must be re-granted or re-earned.
8. **Lineage is not identity.** A revived or translated value is a successor related to its predecessor, not the same live object.
9. **Loss must be represented.** Any lossy summary, translation, handoff, compaction, or policy projection carries a machine-readable loss report.
10. **Evidence relations are typed.** `supports`, `refutes`, `produced-by`, `derived-from`, `reported-by`, and `adjacent-to` are not silently interchangeable.
11. **Canonical identity is versioned and host-independent.** Code, claims, modules, and artifacts use specified bytes independent of printer, package, process, and implementation.
12. **Failures are structured.** Language-level failure has typed data and cause relations; host prose errors are wrapped at the FFI boundary.
13. **Expansion is inspectable.** Macros and compiler lowering preserve source maps, effect attribution, authority requirements, and normalized core identity.
14. **Standing is a query over current state.** Revocation policy is explicit; a stale list field cannot permanently certify a claim.
15. **Unsafe host escape cannot mint privileged values.** The FFI may return ordinary data or explicitly untrusted claims, never a genuine capability or warrant.

Book 0’s `canonical-core`, `authority-is-explicit`, `no-time-travel`, `laundering-prohibited`, `uncertainty-does-not-coerce`, `provenance-at-ingress`, `conservation-of-represented-loss`, `expansion-is-inspectable`, and `failure-is-structured` are close ancestors of this set. Its broader `plan-commit-seam` and resource-accounting laws are also defensible, but require a real effect system before they can be called implemented.

## 4.6 Accidental properties of the current prototype

These should not become normative merely because tests currently expect them:

- SBCL 2.4.6 as the only implementation target.
- MD5 as digest/content-address mechanism.
- `*clock*` beginning at 9000.
- `gensym` as capability and attestation identity.
- Schema numbers 1 and 2.
- Maximum serialized length 100,000 characters and datum depth 32.
- `:execution` and `:default` as default event/scope names.
- The exact `(:equals (:call PROC-ID INPUT) EXPECTED)` proposition grammar.
- Common Lisp `equal` as result equality and `eq` as scope equality.
- Symbols, including package identity, as procedure IDs.
- Hash-table identity and one-process registry membership as authenticity.
- Mutable global registries and absence of thread semantics.
- Temp-file suffix `.tmp`, digest-derived filenames, and `rename-file` as persistence protocol.
- The package names `mneme`, `mneme.client`, and `mneme.operator`.
- `prepare`, `commit`, `receive`, `revive` as the exact API shape.
- The current behavior that a raised claim remains authenticated after warrant revocation.
- The current behavior that a raw string may be revived without a receipt.
- The current behavior that recommit can rewind a receipt.
- The current behavior that a second freeze drops inherited predecessor warrants.
- Package-stripping and downcasing in `mneme-canon/0`.
- SBCL-printer-dependent single-float text.
- The stale README count of 16 checks versus the current 18-check adversarial floor.
- The fact that `verify-all.sh` aggregates five separate floors and omits the canonical codec.

---

## 5. Host Common Lisp bypasses and semantic obscurities

The request asked for at least five. There are substantially more. The first two are especially important because they remain inside the public v1 API rather than relying on `mneme::`.

### 5.1 Critical: mutable string leaves defeat v1 target immutability

`%safe-data-p` admits strings. `%canonicalize-proposition` and `claim-proposition` call `copy-tree`. Common Lisp `copy-tree` copies cons cells, but returns non-cons leaves unchanged. Strings are mutable vectors, so the internal claim and the caller can share the same string.

A static exploit sketch is:

```lisp
(let* ((s (copy-seq "A"))
       (p (list :equals (list :call 'check-input s) t))
       (c (mneme.client:assert-claim p))
       (a (mneme.client:verify-proposition
           (mneme.client:claim-proposition c)
           cap)))
  ;; Verification and the attestation fingerprint concerned "A".
  (setf (char s 0) #\B)
  ;; The claim's stored canonical tree now says "B", but its stored
  ;; fingerprint is still the fingerprint of "A".  raise-claim compares
  ;; stored fingerprints, so the stale attestation can still raise it.
  (mneme.client:raise-claim c a))
```

The mutation can also be reached through the exported `claim-proposition` reader, because its `copy-tree` shares the string leaf. This is a direct counterexample to “private immutable copy” and “attestation faces the exact claim.”

**Repair:** represent canonical data in truly immutable runtime values; deep-copy mutable atoms; freeze strings into immutable byte strings; or re-fingerprint and compare a sealed canonical byte vector at every transition. Add adversarial tests for mutable strings, bit-vectors if admitted later, displaced arrays, and shared substructure.

### 5.2 High: receipt state can be rewound and double revival restored

`commit` does not require the receipt to be `:prepared`. It unconditionally writes and sets the receipt status to `:committed`. Therefore the same prepared object can be recommitted after revival:

```lisp
(let* ((prepared (mneme.client:prepare claim))
       (receipt (mneme.client:commit prepared store)))
  (mneme.client:revive receipt)      ; status -> :revived
  (mneme.client:commit prepared store) ; status -> :committed again
  (mneme.client:revive receipt))     ; a second revival is possible
```

The adversarial “double revival” gate only proves that two consecutive `revive` calls fail. It does not prove monotonicity of the state machine under all exported transitions.

**Repair:** specify legal transitions and guard every transition; make receipts immutable state-indexed values (`PreparedReceipt`, `CommittedReceipt`, etc.) rather than one mutable struct; consume or rotate receipt IDs at each step.

### 5.3 Critical in v0: exported constructors mint semantic standing

`kernel.lisp` exports `make-claim`, `make-certificate`, `make-receipt`, mutable accessors, and `*authority*`. A caller can construct a claim with `:grade :executed`, fabricate an authorized supporting certificate, or set receipt status directly.

The conformance walk’s L1 negative test shows that a `witness` object is not accepted where a `certificate` object is expected. It does not show that the caller cannot call `make-certificate`. Nominal type separation is not authentication.

**Repair:** retire v0 from the claimed current semantics; preserve it only as museum/provenance. Port every seven-law test to one hardened v2 kernel.

### 5.4 High: `mneme.operator` is not an access-control boundary

`mneme.operator:grant-authority` is an exported Common Lisp function. Any code in the image can name it. Common Lisp packages organize names; they do not authenticate callers, limit imports, or establish process custody. Even without `mneme::`, an “attacker” can become its own operator unless deployment code withholds or isolates the operator package by convention.

The adversarial suite’s setup treats operator calls as trusted and tests absence of those names from `mneme.client`. That proves API partition, not authority isolation.

**Repair:** move authority minting behind a sealed module loader or separate process/service. Untrusted modules receive only explicit capability values. The evaluator must make privileged constructors unnameable and uncallable, not merely unexported.

### 5.5 High: same-image `mneme::` access bypasses every v1 opacity claim

The source states this caveat honestly. Same-image code can call `%make-att`, mutate registries, replace function definitions, inspect lexical/runtime state, or change private slots. Package locks would be diagnostics, not a security model.

**Repair:** define language modules separately from host packages and isolate the runtime state. A CL reference evaluator can keep its implementation in a process that evaluates untrusted Lisp+ ASTs rather than arbitrary Common Lisp forms.

### 5.6 High: target identity excludes `as-of`, lineage, and scope

A claim stores a fingerprint of the canonical proposition only. `as-of` is a separate slot. Predecessor lineage is also separate. Scope is carried by the attestation and compared separately with `eq`.

Two claims with the same proposition but different temporal boundaries therefore have the same target fingerprint. An attestation generated for one can raise the other. That is incompatible with the repository’s own language of a “located claim.”

**Repair:** define a normative `claim-id` over all semantically locating fields: proposition bytes, subject, scope, as-of interval, corpus/version, policy ID, and perhaps procedure/code identity. Do not call a proposition-only hash a located-claim fingerprint.

### 5.7 High: scope is an arbitrary mutable host object compared by `eq`

`verify-proposition` stores `scope` without validation or copying. `attestation-scope` returns it directly. `raise-claim` requires the identical object, not an equivalent canonical scope. A list or string can be mutated after minting while preserving `eq`, changing the scope’s apparent meaning without invalidating the warrant.

Across processes, no independent implementation can reproduce `eq` identity. Across serialization, the scope becomes ordinary data and no longer carries the same identity relation.

**Repair:** define a scope grammar, canonical bytes, equality/subsumption relation, and immutable representation. Scope should participate in claim identity and warrant targeting.

### 5.8 High: registered procedures are arbitrary Common Lisp closures

`register-procedure` accepts any host function. The `effect` label is stored but never consulted. The version is caller-supplied. A closure may read the clock, filesystem, network, mutable globals, random state, or capability-bearing data while labeled `:pure`. It may also be replaced under the same procedure ID and version.

Verification therefore means “the current host closure returned a value under current host conditions,” not “the implementation-independent Lisp+ procedure with code ID X evaluated under effect row E.”

**Repair:** register compiled Lisp+ modules, not raw closures. Derive code IDs from normalized core plus dependency IDs and semantics version. Enforce effect rows. Treat host functions as explicit FFI procedures whose results are untrusted until wrapped by specified adapters.

### 5.9 High: proposition fingerprints depend on ambient Common Lisp printing

`%fingerprint` calls `digest` on `(prin1-to-string canonical)` without `with-standard-io-syntax`. `*package*`, `*print-base*`, `*print-case*`, symbol package visibility, and other printer state can change the text. The same proposition can acquire different identities depending on call context or implementation.

The separate canonical prototype recognizes this problem but is not used here.

**Repair:** one normative canonical byte encoder must serve claim IDs, procedure/module IDs, artifacts, and test vectors. Never derive semantic identity from a host printer.

### 5.10 High: revocation does not change existing claim standing

`claim-authenticated-p` checks whether the claim’s authenticated-warrant list is non-empty. It does not consult the revocation registry. Revoking a warrant prevents future calls to `raise-claim`, but a claim already raised continues to report authenticated.

This is documented, but the unresolved choice is constitutional: is revocation prospective, warrant-retrospective, claim-retrospective, or policy-relative?

**Repair:** make standing a query `standing(Σ, claim)` over current warrant and revocation state, or define immutable historical standing and a separate current-admissibility query. Do not conflate them.

### 5.11 Medium/high: raw `revive` bypasses the receipt protocol

`revive` accepts either a private receipt or an arbitrary text string. The text branch bypasses prepared/committed/received status and receipt digest. A caller may receive and verify text, mutate it, then revive the raw mutated string instead of the receipt.

The result has no live authority, which limits the damage, but chronology, custody, and predecessor testimony can be fabricated or obscured.

**Repair:** separate operations and names: `decode-untrusted-artifact` for raw bytes and `revive-receipt` for the custody transition. Never let a raw decoder implicitly claim receipt continuity.

### 5.12 Medium/high: predecessor testimony is forgeable and lost on the second hop

A hostile raw payload may contain any safe `:predecessor-warrants` data. Revival labels it predecessor testimony without cryptographic or registry validation. Conversely, freezing a revived claim serializes only its *current authenticated warrants*, not its existing predecessor warrants. A second handoff can therefore erase all inherited testimony.

This undercuts “testimony survives its death” across more than one succession.

**Repair:** distinguish `reported-predecessor` from `verified-lineage`; preserve transitive lineage or an explicit compaction/loss record; sign or content-address artifact links; test N-hop handoffs.

### 5.13 Medium: one attestation can be reused and duplicated indefinitely

`raise-claim` does not consume a warrant or deduplicate it. The same attestation can raise multiple claims sharing a fingerprint and can be consed repeatedly onto one claim. Perhaps warrants are intentionally reusable, but the policy is not stated.

**Repair:** define warrants as reusable, affine, linear, or bounded-use; enforce set/multiset semantics explicitly.

### 5.14 Medium: Language A validates a mutable, self-authored record

A caller can validate a record, receive `:valid`, then mutate the cons tree. Check 11 accepts a certificate record whose issuer field merely says it is non-model. Check 07 accepts `:scope-complete t` as a statement. Check 09 can preserve only unresolved fields the record admits existed.

**Repair:** validation should return a sealed `ValidatedJudgment` tied to canonical bytes. External verification fields should contain references to genuine runtime warrants, not descriptive plists.

### 5.15 Medium: Language A’s grammar depends on the current package

`validate-judgment` requires `(eq (first j) 'judgment)`. A structurally identical record read in another package has a different symbol and can fail. The canonical reader interns into `mneme.language-a`, hiding rather than specifying the dependency.

**Repair:** use package-independent tagged data or a specified lexical module identifier.

### 5.16 Medium: `mneme-canon/0` collapses distinct symbols

Canonical symbols are downcased and package-stripped. `FOO:A` and `BAR:A` can encode identically. This is unacceptable for code, module, procedure, or claim identity when namespaces matter.

**Repair:** include lexical/module identity in canonical identifiers, or encode identifiers as explicit strings plus module IDs.

### 5.17 Medium: the canonical reader accepts trailing forms

`canonical-read` returns the first value of `read-from-string` and ignores the index. Thus a canonical record followed by extra forms is accepted. It also does not check that the supplied spelling is canonical, bound size/depth, or disable all noncanonical reader constructs.

**Repair:** consume the entire byte stream, parse a dedicated grammar, reject noncanonical encodings when verification requires canonical input, and apply resource limits before allocation.

### 5.18 Medium: concurrency and image history are unspecified

Registries and the clock are mutable globals with no synchronization. `defvar *clock* 9000` preserves an old value when reloaded. Thread scheduling can affect issue times and registry operations.

**Repair:** define atomic transitions and deterministic traces, or explicitly declare the reference semantics single-threaded and put concurrency in a later profile.

---

## 6. Minimal Lisp+ primitive forms

Ornamental syntax is not a cure for any defect above. A macro that expands to a forgeable constructor remains forgeable, only with better tailoring.

The proposal below distinguishes **special forms**—which alter evaluation, binding, or authority—from **privileged primitive procedures**, which may retain ordinary call syntax but cannot be implemented by user code.

### 6.1 New special forms: two in Lisp+ Core

#### 1. `module`

Schematic surface:

```lisp
(module statistics-checker
  (imports (data.read read-cap)
           (mneme.verify verifier-cap))
  (exports median-check)
  (effects (median-check ()))
  (define (median-check xs) ...))
```

`module` is justified as primitive because it must establish:

- lexical name identity independent of Common Lisp packages;
- sealed private bindings;
- explicit capability imports;
- export rights;
- procedure and dependency code IDs;
- effect declarations checked against bodies;
- the boundary at which host FFI is admitted.

A Common Lisp macro cannot provide those guarantees while arbitrary host code can still name packages and functions behind its expansion.

#### 2. `commit`

Schematic surface:

```lisp
(commit plan using capability)
```

or, if body syntax is preferred:

```lisp
(commit using capability
  (effectful-operation ...))
```

`commit` is justified only if Book 0’s plan/commit seam remains constitutional. It must delay effectful evaluation, compare predicted and actual effects/resources, validate authority and consent policy, and make the transition conspicuous in the operational trace. An ordinary eager function receives its arguments after their effects have already happened. A macro can package a thunk, but only the evaluator can ensure that effectful operations are impossible outside the delimiter.

### 6.2 Mneme-profile special form: at most one

#### `infer` — profile-specific, not neutral core

```lisp
(infer model-ref prompt
  :schema judgment-schema
  :budget budget
  :scope scope)
```

This should be a recognized effect operation only if the Mneme profile constitution requires that every model invocation returns a `Judgment` plus invocation receipt and cannot masquerade as an ordinary pure value. Other Lisp+ profiles need not have models, so `infer` should not enter the neutral core.

### 6.3 Forms that should **not** be primitive syntax

- `claim` or `assert-claim`: use a macro over quote/source metadata or a primitive procedure over explicit data. It needs special syntax only if automatic source-location capture becomes constitutional.
- `verify`: privileged primitive procedure/effect operation. Its arguments can be evaluated ordinarily; the runtime privilege is minting, not evaluation syntax.
- `raise-claim`: primitive procedure.
- `revoke-authority` / `revoke-attestation`: privileged service procedures.
- `freeze`, `revive`, `canonical-bytes`: codec procedures.
- `prepare`, `receive`, filesystem `commit`: store library operations. Do not confuse the current persistence function named `commit` with the proposed evaluator-level effect delimiter; rename the former.
- grade and warrant queries: ordinary profile functions.
- validators and pretty-printers: libraries.

### 6.4 Required privileged runtime operations

These operations are semantically primitive even though they need no special surface syntax:

```text
assert-claim(datum, location)                    -> Claim
verify(claim, capability, procedure-ref, scope) -> Warrant
raise(claim, warrant)                           -> Claim
standing(claim)                                 -> Standing
revoke(authority-or-warrant)                    -> Unit
seal(claim, codec-version)                      -> Artifact
revive(artifact)                                -> Claim
```

User code may call them. User code may not redefine their minting semantics or construct their result types.

---

## 7. Existing APIs that should remain libraries rather than syntax

| Existing operation/API | Recommended status | Reason |
|---|---|---|
| `claim-proposition`, warrant readers, provenance readers, receipt readers | Ordinary library queries over abstract values. | No evaluation-rule change. |
| `claim-authenticated-p` | Replace with runtime-backed `standing`; keep call syntax. | A query, not syntax. |
| `grade-for` and grade vocabulary | Mneme profile policy library. | Profiles may use lattices, sets, or other standing systems. |
| `witness-supports-p` | Mneme evidence-policy function over typed edges. | Extensible relation policy; no syntax needed. |
| `replay-and-attest` | Library composition of `verify` and `raise`. | Convenience composition is exactly what libraries are for. |
| `prepare`, current filesystem `commit`, `receive` | Artifact-store library. | Filesystem and custody protocol are deployment concerns. |
| `freeze` / `revive` | Normative codec/runtime procedures, not syntax. | Privileged behavior does not require a new reader form. |
| `register-procedure` | Module linker/loader API, eventually generated from module declarations. | Runtime registration syntax would invite dynamic code-identity drift. |
| `grant-authority` | Loader/operator service API. | Authority comes from deployment policy, not decorative source forms. |
| `revoke-authority`, `revoke-attestation` | Privileged runtime service calls. | Their semantics are state transitions, not binding constructs. |
| `validate-judgment`, `valid-p` | Mneme profile library/type checker. | Other profiles may validate different deposition grammars. |
| Language-A accessors (`clause`, `val`, claim/support selectors) | Library. | Pure data navigation. |
| `canonical-bytes`, `canonical-read` | Standard codec library with normative spec. | Reader API, not surface punctuation. |
| Digest helpers and content-address utilities | Library/runtime service. | Choice of hash is representation policy. |
| Model/provider adapters and normalizers | Mneme profile libraries/FFI adapters. | Provider-specific and replaceable. |
| Noema, vestigium, scar, deposit, retrieval combinators | Profile libraries unless later operational evidence proves a primitive need. | Rich ontology is not, by itself, evaluation semantics. |

The severe rule is simple: **if an operation can receive already-evaluated explicit values and return an abstract value without changing lexical binding, evaluation order, or authority context, it should remain a function.**

---

## 8. What must move into each language subsystem

## 8.1 Evaluator

The evaluator must own the distinctions that cannot be delegated to cooperative library calls:

1. **Opaque value brands.** `Claim`, `Warrant`, `Capability`, `Artifact`, and validated profile values must have constructors unavailable to ordinary code. Their immutable fields must not share mutable host leaves.
2. **Privileged state.** Mint, revocation, authority, module, and code registries are evaluator state, not accessible hash tables.
3. **Effect discipline.** Verification, inference, observation, retrieval, persistence, time, randomness, I/O, and FFI calls have declared effects. A procedure labeled pure cannot perform them.
4. **Restricted procedure execution.** Verification runs a Lisp+ procedure reference with a stable code ID under a specified environment, not an arbitrary host closure.
5. **Located claim identity.** Claim identity includes every semantically relevant boundary. The evaluator refuses a warrant whose target differs in any such dimension.
6. **Standing as a live judgment.** Current standing consults warrant genuineness, validity, revocation, policy, and time.
7. **Mutation semantics.** Canonical data is immutable, or mutation creates a fresh identity and invalidates dependent warrants.
8. **Failure wrapping.** Host exceptions crossing the FFI become structured Lisp+ failures with explicit provenance.
9. **Atomic transitions.** Minting and revocation are atomic in the reference semantics.
10. **No authority from deserialization.** The evaluator’s reader can create inert descriptions but never live capabilities or warrants.

A Common Lisp implementation may implement these rules. It must evaluate Lisp+ programs as data under this machine rather than loading them as unrestricted Common Lisp into the same authority-bearing image.

## 8.2 Compiler and macro expander

The compiler must preserve semantic distinctions rather than optimizing them into folklore:

- Lower surface forms to one versioned normalized core.
- Produce `code-id = H(semantics-version, normalized-core, dependency-code-ids)`; never accept a hand-written version string as identity.
- Type/effect-check every procedure and module import.
- Prevent inlining, common-subexpression elimination, duplication, or dead-code elimination from changing the number/order of authority-bearing transitions unless the semantics explicitly permits it.
- Preserve source maps and binding attribution through macro expansion.
- Make expansion inspectable and hash the expanded core, not ornamental surface spelling.
- Reject or quarantine host FFI calls not declared in a module effect manifest.
- Ensure macros cannot expand to privileged constructors or hidden capability acquisition.
- Generate module registration metadata; do not let runtime code silently overwrite a procedure ID.
- Specify evaluation order, multiple values, tail calls, dynamic variables, conditions, and mutation for the chosen Lisp core—or explicitly inherit a precise Common Lisp portability profile.

## 8.3 Reader and canonical codec

A language reader is needed not because parentheses are inadequate, but because host `read` currently determines identity and attack surface.

The reader/codec must specify:

- one grammar for source core forms and a separate inert artifact grammar if necessary;
- full input consumption—exactly one form where one is expected;
- no read-time evaluation or live-object construction;
- package-independent lexical identifiers tied to module IDs;
- exact integer, rational, decimal/float, character, string, and byte-vector encodings;
- Unicode policy and UTF-8 bytes;
- canonical map/record ordering and duplicate-key behavior;
- graph/cycle policy;
- maximum depth, size, and allocation behavior before hostile inputs can exhaust resources;
- schema and semantics versions;
- immutable decoded data;
- canonical bytes as octets, not a host string;
- golden vectors shared by every implementation.

For floats, use IEEE-754 bit encodings or exclude floats from identity-bearing core data. “Whatever SBCL 2.4.6 prints” is a profile fixture, not an independent language law.

## 8.4 Module and authority system

This is the largest missing organ.

The module system must:

- make private bindings actually unreachable to untrusted language code;
- grant capabilities explicitly at load/link time;
- separate trusted runtime/operator modules from ordinary modules;
- bind principals to loader identities or authenticated service identities, not arbitrary symbols;
- namespace procedure references by module/code ID;
- make dependency IDs part of code identity;
- prohibit dynamic overwrite of a registered code ID;
- declare FFI imports and effects;
- decide whether capabilities are copyable bearer values, affine, linear, delegable, or non-transferable;
- define custody across threads, processes, and serialization;
- permit process isolation or remote verifier services without changing language-visible semantics.

A package export list is not enough. A module is language semantics when the evaluator and loader refuse access, not when a comment asks callers to be polite.

## 8.5 Operational semantics

The reference specification should define a machine state such as:

```text
Σ = ⟨Modules, Procedures, LiveCaps, MintedWarrants,
     Revocations, ArtifactStore, LogicalTime⟩
```

and explicit transitions. A minimal sketch:

```text
ASSERT
  canonical(P, L) = bytes
  id = H(semver, bytes)
  --------------------------------------------
  Σ ⊢ assert(P, L) ⇓ Claim(id, P, L, ∅), Σ

VERIFY
  cap ∈ LiveCaps(Σ)
  permits(cap, procedure, event, scope)
  Procedures(Σ, procedure) = ⟨code-id, body, effects⟩
  effects ⊆ permitted-effects(cap)
  evalΣ(body, input) ⇓ result, trace, Σ′
  w = fresh-warrant(target = claim.id, code-id, scope, verdict, trace-id)
  ----------------------------------------------------------------------
  Σ ⊢ verify(claim, cap, procedure, scope) ⇓ w, mint(Σ′, w)

RAISE
  mintedΣ(w) ∧ ¬revokedΣ(w)
  w.target = claim.id ∧ w.verdict = supports
  admissible(policy, w, claim)
  ------------------------------------------------
  Σ ⊢ raise(claim, w) ⇓ claim ⊕ w, Σ

STANDING
  live-warrants = {w ∈ claim.warrants | mintedΣ(w) ∧ ¬revokedΣ(w)}
  standing = policy-join(live-warrants)
  ------------------------------------------------
  Σ ⊢ standing(claim) ⇓ standing, Σ

REVIVE
  decode(bytes) = inert-record
  fresh-id ≠ predecessor-id
  ------------------------------------------------
  Σ ⊢ revive(bytes) ⇓ Claim(fresh-id, proposition,
                            lineage = inert-record.lineage,
                            live-warrants = ∅), Σ
```

The final specification must settle:

- whether warrant use is reusable or consuming;
- whether revocation affects historical status, current admissibility, or both;
- whether time is logical, wall-clock, signed external time, or profile-defined;
- what equality means for results and scopes;
- how nontermination and verifier failure are represented;
- concurrency and transaction ordering;
- how multi-hop lineage and represented loss compose;
- what parts of traces are observable.

## 8.6 Conformance

A language conformance suite must run the **same core programs** against at least two independent implementations and compare structured traces and canonical bytes. It should not merely count banners from separate subsystems.

Minimum cross-implementation vectors should include:

- mutable-input attacks;
- package/namespace collisions;
- ambient-printer attacks;
- code-ID stability;
- capability grant/revocation traces;
- target mismatch over scope/as-of/corpus;
- N-hop seal/revive lineage;
- trailing-form and reader-macro attacks;
- effect-label violations;
- procedure redefinition attempts;
- concurrent mint/revoke ordering if concurrency is admitted;
- Language-A judgments backed by genuine warrants.

---

## 9. Migration path: embedded runtime to reference language

### Phase 0 — Name the current jurisdictions

- Rename or clearly label `kernel.lisp` as `kernel-v0-route-museum.lisp`.
- Make `kernel-hardened.lisp` the only candidate runtime nucleus.
- State that Language A, canon, atelier, and Book 0 are separate profile/spec layers until integrated.
- Correct the 16-versus-18 documentation drift.

**Exit criterion:** no document calls the forgeable v0 kernel the current shared semantic root.

### Phase 1 — Repair the current v1 façade before adding syntax

Patch and test:

- deep immutability of strings and all admitted data;
- claim IDs including scope, as-of, corpus/version, and policy-relevant fields;
- canonical scope representation and equality;
- monotone receipt transitions, including recommit attacks;
- separation of raw decoding from receipt revival;
- transitive predecessor preservation and loss reports;
- dynamic standing after revocation;
- duplicate/reuse policy for warrants;
- full-consumption canonical reader;
- module-qualified canonical symbols.

**Exit criterion:** the adversarial suite includes these attacks and no counterexample uses only `mneme.client`.

### Phase 2 — Unify the semantic object model

Port L1–L7 and the relevant Language-A checks onto one v2 runtime:

- replace v0 certificates with v2 warrants;
- replace scalar mutable grades with a policy-defined warrant set/lattice;
- give evidence edges explicit kinds;
- make judgments refer to actual claim and warrant IDs;
- make bounded absence require a completion warrant, not merely `:scope-complete t`;
- preserve source, lineage, and represented loss in the same artifact model.

**Exit criterion:** one test program exercises all seven laws through the hardened runtime; no v0 structs participate.

### Phase 3 — Publish Lisp+ Core semantics before a compiler

Write a compact normative specification containing:

- core AST and values;
- evaluation order and binding;
- module declarations;
- effect rows and `commit`;
- claim/warrant/capability/artifact abstract types;
- state transition rules;
- equality, identity, time, failure, and revocation;
- artifact grammar and canonical bytes;
- explicit unsafe FFI semantics.

Use executable reference rules or a small-step interpreter as the specification’s companion.

**Exit criterion:** a clean-room implementer can answer every observable question without reading the Common Lisp source.

### Phase 4 — Build a reference evaluator in Common Lisp

Common Lisp remains a perfectly good implementation language. The crucial change is architectural:

- Lisp+ source is read into a dedicated AST;
- the evaluator interprets/compiles only that AST;
- untrusted Lisp+ code is never `load`ed as arbitrary CL into the runtime image;
- privileged values are evaluator-owned handles;
- FFI calls return inert/untrusted values;
- module loading grants capabilities explicitly.

**Exit criterion:** `mneme::` is unreachable because Lisp+ programs do not execute as host Common Lisp forms.

### Phase 5 — Integrate canonical code and artifact identity

- Replace `%fingerprint` and `mneme-canon/0` fragmentation with one versioned codec family.
- Return octet vectors.
- Define code IDs over normalized expanded core and dependency IDs.
- Use SHA-256 for content identity and HMAC/signatures where authenticity is required.
- Preserve the repository’s correct priority: cryptography after semantic unforgeability, not instead of it.

**Exit criterion:** identical modules/claims/artifacts produce identical bytes and IDs on two implementations.

### Phase 6 — Implement modules, effects, and operator isolation

- Introduce the primitive `module` and evaluator-level effect boundary.
- Move verifier registration and authority minting into the loader/operator service.
- Enforce effect declarations rather than storing `:pure` as prose.
- Define capability transfer and custody.
- Wrap host procedures as explicit FFI modules.

**Exit criterion:** an untrusted module cannot acquire operator authority by naming a package or function, and a “pure” verifier cannot perform undeclared effects.

### Phase 7 — Layer Mneme as the first standard profile

Implement profile-level:

- `infer` returning `Judgment` plus invocation receipt;
- Language-A deposition schema over genuine core IDs;
- bounded-absence completion warrants;
- typed evidence relations;
- retrieval as ranked traces;
- context succession/deposits/loss reports;
- noema/vestigium vocabulary where it proves useful.

**Exit criterion:** profile records are generated and validated from evaluator events, not merely authored plists.

### Phase 8 — Independent implementation and differential conformance

Build a second implementation in another Lisp or a small systems language. Run identical source programs and artifact vectors through both.

**Exit criterion:** the project can reject an implementation for violating the written semantics even when that implementation passes no SBCL-specific tests. At that point “Lisp+ language” is an honest, independently checkable claim.

---

## 10. Immediate practical patch queue

Before designing a single new sigil, add these regression tests:

1. Mutate a string leaf obtained from `claim-proposition` after verification; raising must fail or the mutation must be impossible.
2. Create same-proposition claims with different `as-of`, scope, corpus, and policy; a warrant for one must not raise the others.
3. Mutate an attestation scope object after minting; identity/admissibility must not change.
4. Recommit a revived receipt; the transition must fail.
5. Call raw decode after receiving and mutating text; it must not claim receipt continuity.
6. Freeze → revive → freeze → revive; predecessor lineage and represented loss must remain correct.
7. Revoke a warrant after raising; `standing` must follow the chosen constitutional policy.
8. Raise twice with the same warrant and define whether that is legal.
9. Dynamically bind `*package*`, `*print-base*`, and other printer state around claim/verify; identity must be invariant.
10. Re-register a procedure ID with different code and the same version; the loader must reject it or issue a new code ID.
11. From an untrusted module, attempt to call the operator service; the evaluator/module system must refuse it.
12. Feed the canonical reader trailing forms, package-colliding symbols, duplicate clauses, deep data, and noncanonical float spellings.
13. Validate a Language-A judgment, mutate it, and ensure the validated handle no longer applies.
14. Supply an `:externally-verified` record with a merely self-described issuer; it must not gain verified standing without a genuine warrant.
15. Run every vector against two implementations or, before the second implementation exists, against two independently written codecs/evaluators inside the repository.

Practical repository restructuring would help immediately:

```text
mneme/
  spec/
    LISP-PLUS-CORE.md
    OPERATIONAL-SEMANTICS.md
    CANONICAL-CODEC.md
    EFFECTS-AND-MODULES.md
  reference/
    evaluator/
    codec/
    runtime/
  profiles/
    mneme/
      language-a/
      infer/
  museum/
    latent-mvp-v0/
  conformance/
    core/
    profile-mneme/
    cross-implementation/
```

This structure would stop provenance, prototype, profile, and current normative runtime from sharing one visual shelf and quietly borrowing each other’s authority.

---

## 11. Binary ruling under three definitions

### Lisp+ as an embedded language — **YES**

Under the broad EDSL definition, v1 supplies abstract-ish domain values, privileged runtime operations, typed failures, and nontrivial evaluation/authority behavior embedded in Common Lisp. The answer remains yes despite implementation defects. The qualification is severe: it is a **bounded, currently unsound EDSL**, not a host-closed authority system. The mutable-string counterexample defeats one advertised v1 invariant through the exported client API.

### Lisp+ as an executable semantic profile — **YES**

The repository has executable laws, validators, adversarial fixtures, process-boundary tests, and explicit refusals. It therefore qualifies as an executable semantic profile or family of profiles. The qualification is that the profile is **fragmented**: the seven-law v0 walk, v1 hardening, Language A, canon, and atelier do not yet share one semantic machine.

### Lisp+ as an independently implementable programming language — **NO**

A clean-room implementation cannot currently determine the language from a normative evaluator/compiler/reader/module/operational specification. Too many observables are inherited from SBCL and Common Lisp: package identity, `eq`/`equal`, mutable strings, printer state, `gensym`, global registries, arbitrary host closures, filesystem behavior, and process-local mint provenance. There is also no second implementation demonstrating semantic invariance.

---

## Final practical judgment

Do not add ornamental syntax now. The project has already found the important material: generative warrants, explicit authority, inert revival, exact-facing evidence, typed failure, and represented epistemic boundaries. The next advance is not a prettier way to spell `verify`. It is to make those distinctions survive hostile mutation, module boundaries, code replacement, serialization, process restart, and a second implementation.

The most leverage-rich next milestone is a **small Lisp+ Core evaluator in Common Lisp** with sealed modules, immutable canonical data, code/effect identity, and an explicit state-transition model. Port the seven laws and Language A onto that one evaluator. Then build a second tiny implementation of the same core and let the two disagree in public until the specification becomes sharp enough that they cannot.

That is the moment the parentheses stop being a Common Lisp costume and become a constitution.
