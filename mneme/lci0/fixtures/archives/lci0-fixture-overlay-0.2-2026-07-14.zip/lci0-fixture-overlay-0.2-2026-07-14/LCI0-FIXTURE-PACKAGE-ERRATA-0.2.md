# LCI/0 Fixture Package Errata 0.2

Status: additive fixture authority overlay. The frozen 0.1 registry, vectors, and package specification remain byte-for-byte evidence. This errata supplies a deterministic supersession layer; it does not silently rewrite them.

## F0.2-1 — Authority and supersession

For the ten closure IDs in `LCI0-AUTHORIAL-CLOSURE-REGISTER.json`, the register and `LCI0-AUTHORIAL-CLOSURE-VECTORS.jsonl` supersede only the conflicting or absent 0.1 expectation named by each record. Every other 0.1 entry remains authoritative and unchanged.

## F0.2-2 — Policy consultation order

Where a closure vector requires both fixture policies, consult Policy-A before Policy-B. Record both consultation booleans and the actual order. Short-circuiting is permitted only when the frozen relation table already yields a determinate result; it may not erase an independently required failure coordinate.

## F0.2-3 — Diagnostic schema overlay

Closure-vector failures carry exact `category`, `code`, `stage`, and semantic `path`. Adapters must suppress host exception text from normative comparison. Multiple causes may be retained as non-normative evidence, but the expected tuple is the single precedence-selected constitutional failure.

## F0.2-4 — Inert defensive reconstruction

A /0 fixture revival/reconstruction operation may emit only an inert defensive record derived from supplied fields. Missing claimant, assertion time, provenance edge, standing, warrant effect, authority, or custody data are never synthesized. Active production revival is unsupported by /0 and deferred to a future schema/version that binds those values.

## F0.2-5 — Source preservation

Where a vector supplies a source artifact, the expected source member is exactly the supplied artifact. Registry indirection, adapter decoding, or migration scaffolding may not substitute a normalized, regenerated, or implementation-chosen document unless the frozen operation expressly authorizes that transformation.

## F0.2-6 — Permanent regression coverage

The closure JSONL is normative fixture evidence for exactly four blocked original vectors, 38 blocked relation paths, and eight blocked hostile tuples. Each coverage object binds a witness ID to its source locator and ruling section. No prose-only expectation is conforming.

## F0.2-7 — Non-effect

Fixture revision 0.2 changes no LCI envelope, identity-policy, claim-profile, target-schema, accepted ClaimId/target, canonical octet, existing determinate relation value, or v1 migration posture.
