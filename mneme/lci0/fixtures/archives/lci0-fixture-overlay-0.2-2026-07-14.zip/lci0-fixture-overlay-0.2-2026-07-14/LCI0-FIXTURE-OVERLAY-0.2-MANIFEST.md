# LCI/0 FIXTURE PACKAGE 0.2 OVERLAY — MANIFEST

**Overlay package root:** `lci0-fixture-overlay-0.2-2026-07-14/`  
**Revision:** `0.2` (additive fixture-authority overlay)  
**Build date:** `2026-07-14`  
**Base fixture package:** `lci0-errata-0.1-fixture-package-2026-07-14` (frozen, unchanged, historically reachable)  
**Base package ZIP SHA-256:** `36cc71ccf3c310a055199c54e84bf436c4505d92a6378f22e8b1d932f02e987d`  
**Closure-vectors source SHA-256:** `14db4a8400714b669eee781dedfc92d7a1f7af6c77a01eef23f83c30270f1582` (50 vectors)  
**Closure-register source SHA-256:** `5d4fcc279f6333fe7492fa4d2ffd38a40a40e6243ce3cbe8973631c68ee8f909` (10 records)  

## Status

This is an **additive-only** supersession overlay. It changes no LCI envelope, identity-policy, claim-profile, target-schema, accepted ClaimId/target, canonical octet, existing determinate relation value, or v1 migration posture (Errata F0.2-7). Fixture 0.1 remains byte-for-byte evidence and is unchanged and historically reachable.

## Lookup precedence

For the four superseded 0.1 vector keys, the 0.2 overlay is consulted **first**; for every other key, resolution falls through to the frozen 0.1 package. The overlay never shadows any determinate 0.1 result beyond the four supersession keys.

**Supersession keys (exactly four):** `LCI0-N012`, `LCI0-E5-COVERAGE-INSUFFICIENT`, `LCI0-P029`, `LCI0-P024`

## Coverage arithmetic (Errata F0.2-6)

- 4 blocked original vectors superseded
- 38 blocked relation paths given companion failure documents
- 8 blocked hostile tuples given exact expectations
- 4 register-only closure records (AC-005/006/008/009) instantiated as exact tuples/deferral

## Closure coverage (all ten closure IDs; every member maps to one)

| Closure ID | Overlay members |
| --- | --- |
| LCI0-AC-001-N012-MATCHER | supersessions/LCI0-ACV-ORIG-001-LCI0-N012.json |
| LCI0-AC-002-RELATION-FAILURE-PATHS | relation-failures/LCI0-ACV-REL-001.json … relation-failures/LCI0-ACV-REL-038.json (38 members) |
| LCI0-AC-003-E5-COVERAGE-CONTEXT | supersessions/LCI0-ACV-ORIG-002-LCI0-E5-COVERAGE-INSUFFICIENT.json |
| LCI0-AC-004-P029-SOURCE-PRESERVATION | supersessions/LCI0-ACV-ORIG-003-LCI0-P029.json |
| LCI0-AC-005-POLICY-EVALUATION-ORDER | hostile/LCI0-ACV-HOSTILE-008.json<br>closure-records/LCI0-AC-005-POLICY-EVALUATION-ORDER.json |
| LCI0-AC-006-CORPUS-BASIS-COHERENCE | closure-records/LCI0-AC-006-CORPUS-BASIS-COHERENCE.json |
| LCI0-AC-007-OPERATION-PAYLOAD-FAILURES | hostile/LCI0-ACV-HOSTILE-001.json … hostile/LCI0-ACV-HOSTILE-007.json (7 members) |
| LCI0-AC-008-MIGRATION-CLASSIFICATION | closure-records/LCI0-AC-008-MIGRATION-CLASSIFICATION.json |
| LCI0-AC-009-TARGET-BOUNDARY-COHERENCE | closure-records/LCI0-AC-009-TARGET-BOUNDARY-COHERENCE.json |
| LCI0-AC-010-P024-INERT-REVIVAL | supersessions/LCI0-ACV-ORIG-004-LCI0-P024.json |

## Overlay infrastructure members (not closure-scoped)

These four members carry the overlay's rules and bookkeeping; they are not closure expectations and therefore map to no single closure ID:

- `LCI0-FIXTURE-PACKAGE-ERRATA-0.2.md` — the normative rules F0.2-1…F0.2-7 (byte-identical copy of the closure-packet errata; governs all ten closures)
- `LCI0-FIXTURE-OVERLAY-0.2-INDEX.json` — machine-readable loader index
- `LCI0-FIXTURE-OVERLAY-0.2-MANIFEST.md` — this manifest (bookkeeping)
- `LCI0-FIXTURE-OVERLAY-0.2-SHA256SUMS.txt` — checksum receipt (bookkeeping)

Every one of the 54 **payload** members above maps to exactly one closure ID.

## Payload integrity table

| Logical member path | Bytes | SHA-256 |
| --- | --- | --- |
| LCI0-FIXTURE-OVERLAY-0.2-INDEX.json | 439693 | 949d0c802ea02903b858aa692ee5b846220a2442c3f481b397b4171a3b4a44ff |
| LCI0-FIXTURE-PACKAGE-ERRATA-0.2.md | 2560 | 18d4f18ee4d211234a9281da3421e44b5cda534c9dfaad7af07c1f99e13b19ec |
| closure-records/LCI0-AC-005-POLICY-EVALUATION-ORDER.json | 2584 | aeefa1005bebf77739c0ebb1754a79d8f4a93170e8121b6b25167a3314bc691c |
| closure-records/LCI0-AC-006-CORPUS-BASIS-COHERENCE.json | 2110 | 24df075f499625cda433add76eba9c1fcf31588ee14b541aac6e58b995af8c40 |
| closure-records/LCI0-AC-008-MIGRATION-CLASSIFICATION.json | 2048 | 539a2fac21cb4712d365d1dd8d511c872e46b3e24d71bebc6ec23e94b9036bc5 |
| closure-records/LCI0-AC-009-TARGET-BOUNDARY-COHERENCE.json | 2323 | 2db0d3e36e52338a016ebfa31fcc27c9ef7fcb904f9dc7aee518462c16f10b12 |
| hostile/LCI0-ACV-HOSTILE-001.json | 2449 | adec868203f469c0d2a3c4641390829de3a6e5bfedeaa84f8ec884764393e6df |
| hostile/LCI0-ACV-HOSTILE-002.json | 27996 | 816ff4b69ac63fbc9c2c27379c46616301341e8e28e0496e46bef2dc7b7da2a9 |
| hostile/LCI0-ACV-HOSTILE-003.json | 32018 | 3f5557183bf475ebd8a3816414e66526a9d64813271b6aee083050da489a2a4c |
| hostile/LCI0-ACV-HOSTILE-004.json | 28129 | e0b275ba10b5a72d9377c55a017a62e738bc5e99cf47073ad0acfd1752a122a6 |
| hostile/LCI0-ACV-HOSTILE-005.json | 12421 | 79974783e7e9d6ba7d30663ab998322f7e73cf92a48997eb3b0e1a400e062f78 |
| hostile/LCI0-ACV-HOSTILE-006.json | 16656 | 90f0b8a2e7d9f2ab08aa11c390e474d36a1b2ddb5922471fb6b84063d6c0beda |
| hostile/LCI0-ACV-HOSTILE-007.json | 7868 | 68957db485c485546571949ba01418f4f167d7e73009db6e66b56815991967ef |
| hostile/LCI0-ACV-HOSTILE-008.json | 5224569 | 1e755bd268be6d5d8dabbb3998bbdad642ce6f2d21910ab76d7e94c1205199c1 |
| relation-failures/LCI0-ACV-REL-001.json | 6119 | 1149cb76c8abe95f5b0bcbb458904dd126b23e3135d82168409369449c99782b |
| relation-failures/LCI0-ACV-REL-002.json | 6333 | 56a79b4563b284e57a67a6cd902f3e99455a732137054907d0af9ac8069bde47 |
| relation-failures/LCI0-ACV-REL-003.json | 6537 | 3e97eab8f389412d793bc1cd80af0dcf759bbc3e0b00925fd29987442ad738f8 |
| relation-failures/LCI0-ACV-REL-004.json | 6541 | 8335d509e59c120eb1c3f3650df7c812330851e124b78e8ec6bb9f515da0b435 |
| relation-failures/LCI0-ACV-REL-005.json | 6499 | c4a98409854bcf32e05bacdd0a2a14d99f6c177166ef1feccc3facf28bcc7a08 |
| relation-failures/LCI0-ACV-REL-006.json | 6499 | 698dc21968dc350c0fd56fa3eb500a563fad7b0365d1f044e65b54204ee69500 |
| relation-failures/LCI0-ACV-REL-007.json | 6417 | dfb3ce591a1357ef8658e0cbafb2c1d393022fbbe0f7c153877c6724464f369c |
| relation-failures/LCI0-ACV-REL-008.json | 6418 | e27b68a60f0990d3ac62ec4732ea916339ce09ae95c148e88ee7cf1f363e7ec3 |
| relation-failures/LCI0-ACV-REL-009.json | 6312 | c640483a4d6839c13d8bd95042f51b38c36cbcfcb2dcf82d1557a8f902544d9d |
| relation-failures/LCI0-ACV-REL-010.json | 6314 | 38328dddb802a15974ed034a8ed54ec3a558c398e5b0adbf3abff342957e7be4 |
| relation-failures/LCI0-ACV-REL-011.json | 6314 | 7d58766d8680e53681f4c7d387993bf2933880908c33735a9c02d58f65ccd788 |
| relation-failures/LCI0-ACV-REL-012.json | 6456 | abc14409119e69c322f1b84dae90064a1859372300be34147cfb87d9b29e469b |
| relation-failures/LCI0-ACV-REL-013.json | 6120 | 969385f04a4b6133939da52b2aa509e41a9a23abd6f5d3a9dd2251289cd263aa |
| relation-failures/LCI0-ACV-REL-014.json | 6334 | e00d24bd36b32fb355cddaf9caac7cf71cb583fc77a0451748e15f425c0baca5 |
| relation-failures/LCI0-ACV-REL-015.json | 6538 | 855894c0c812b4ba194eac7f221ea52ab6eb38bee2673dc772fec403d67a352c |
| relation-failures/LCI0-ACV-REL-016.json | 6542 | fe5f176b5c998ae1dde0b15392cdbf27309bfc94b6152310138b087bfff4aff5 |
| relation-failures/LCI0-ACV-REL-017.json | 6500 | 8b67a701b3a342037b523aa29bd1f71462a9d5432c54a2f7d535e81e6cfd449e |
| relation-failures/LCI0-ACV-REL-018.json | 6500 | a4c9153a6c0543ca1f1af11b96f363bfd079e246a7b2e47282a5c24f03459bd6 |
| relation-failures/LCI0-ACV-REL-019.json | 6418 | 324510f5c073c732109ac0663d6cd72fc04b92f332044777e68959e5e8baa4c8 |
| relation-failures/LCI0-ACV-REL-020.json | 6418 | 0c453de4a2c58d341a99a9640e684e0ccdb7a9dd7a8110a75300e71b5956d9ce |
| relation-failures/LCI0-ACV-REL-021.json | 6312 | ec68dee847b51a8456efed6429e4c70216588d9a90cfc156af30bc5cfdd26fd6 |
| relation-failures/LCI0-ACV-REL-022.json | 6314 | 21eb3ec517d630600a3615cca8693ae54cea85d31781bb2775bff9161426f3b3 |
| relation-failures/LCI0-ACV-REL-023.json | 6314 | b5b0042e14795e384f91772702444f23732919c05914795425818d04e78e6e60 |
| relation-failures/LCI0-ACV-REL-024.json | 6456 | 58ef2324c018ca46a29d0e2e9f83fa5dec54171faf1f302237da37f1d9f1fec0 |
| relation-failures/LCI0-ACV-REL-025.json | 6182 | a1996aba0d7893a6143840f2e7aebaa4a05415e834e10a9b82138ba4ab67252d |
| relation-failures/LCI0-ACV-REL-026.json | 6184 | 732f1e60923acd3c89414b6a13c0004936f1c1b4f9cf97cc7dd33b39487f8b8e |
| relation-failures/LCI0-ACV-REL-027.json | 6184 | 5ec6e82be20f1dabc3dbe9c2b2f2f619cda06808cd0f2b732cf115710f00b374 |
| relation-failures/LCI0-ACV-REL-028.json | 6184 | a2b391e5279da62df931aed5784647e83581a241388ec44307d733c3ea5ddc7b |
| relation-failures/LCI0-ACV-REL-029.json | 6185 | 9f043b7e61669c913495403c4ae4c3c06ca6d8dcdd938c219d8a6d1e84ad07ba |
| relation-failures/LCI0-ACV-REL-030.json | 6185 | 09b5597067ebd4116b0107285e7a0156890aa24f82c471db62940ce165ce4d75 |
| relation-failures/LCI0-ACV-REL-031.json | 6453 | 6a5fc9d645e9cbeb455ccb3c24b19e8638b3e633e7077199bffd65352247bf5d |
| relation-failures/LCI0-ACV-REL-032.json | 6453 | c3b72e3cc983e3cf0082581473d92766d2ca436054d66f3739ae70bdbc408ba0 |
| relation-failures/LCI0-ACV-REL-033.json | 6453 | 7dc243d88bb86d28be0794e186a5e8b2448a3c54e765e62ac5dda0bebb720d44 |
| relation-failures/LCI0-ACV-REL-034.json | 6453 | 12f9e88a00413193fe1892320405fe34c080844707b15ea45ca476618c6f4954 |
| relation-failures/LCI0-ACV-REL-035.json | 6449 | d74d2ee593b7721343082ca1e78582d9b7ff234c59cc1bfabc2eba4f77a8823a |
| relation-failures/LCI0-ACV-REL-036.json | 6453 | c8bdd6a59026242ea159146383716a2bcdb758d72dac76c94a12013b96810f74 |
| relation-failures/LCI0-ACV-REL-037.json | 6289 | f5b7206b1354560a8a4f6ebcd340d00d825d18fbd405503b2e6ba3f3e123fb5e |
| relation-failures/LCI0-ACV-REL-038.json | 6289 | 70d4efb5ac9e0fc3e6ea183beabf47a0cf86baa9d2acacdde5eeb6e8a1f8027e |
| supersessions/LCI0-ACV-ORIG-001-LCI0-N012.json | 57289 | cd0ce03a8cc9e21a73bc6feb47169106aba2ce1cc1e02923066e69292dbd7b91 |
| supersessions/LCI0-ACV-ORIG-002-LCI0-E5-COVERAGE-INSUFFICIENT.json | 69109 | 4834f713dc0c723770e6bfc72143f6c0607ef67b7d076f73b68874e796c79e83 |
| supersessions/LCI0-ACV-ORIG-003-LCI0-P029.json | 1133215 | 9740034761e802eb3a868de898f5f7226795134d01358fcdb31b41a5b1eca86d |
| supersessions/LCI0-ACV-ORIG-004-LCI0-P024.json | 60515 | d0619f0fe733e3b615b722cdba4a7cb04a1240088d0746ad488d2526b684b427 |

`LCI0-FIXTURE-OVERLAY-0.2-MANIFEST.md` and `LCI0-FIXTURE-OVERLAY-0.2-SHA256SUMS.txt` are bookkeeping members. This manifest's table covers every immutable payload member but not the two bookkeeping files. The checksum file covers every payload member plus this manifest and omits only itself.

