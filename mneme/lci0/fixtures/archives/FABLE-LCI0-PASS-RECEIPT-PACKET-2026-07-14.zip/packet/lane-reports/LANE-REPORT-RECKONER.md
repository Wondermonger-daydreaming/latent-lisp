# LANE REPORT — RECKONER (registry/vector mechanical; ruling §10 item 2 + item 6 mechanical half)

> Provenance: the agent returned this report as final-message text (the harness blocks
> subagent-written report files); persisted verbatim by the chair (Fable 5), 2026-07-14.
> Agent model: Sonnet. Scripts and raw outputs in this directory.

**Mission:** Ruling §10 item 2 + mechanical halves of item 6 (completeness/well-formedness only —
the semantic "produce the exact typed result" half needs a live evaluator and is out of scope).

## Schema discovery (spec citations)
- Checksum algorithm: field `sha256_checksum_of_canonical_octets` = SHA-256 over the raw octets
  from hex-decoding `canonical_cd0_hex` — confirmed directly from JSON field names,
  cross-referenced with spec §13.1 ("Canonical octets are derived solely from frozen CD/0:
  document prefix `4c50434400`...").
- Document scope for "1105": spec §13.2 verbatim — "All 675 registry definitions plus the
  aggregate input and expected-output document for all 215 vectors—1,105 complete documents."
- Magic/version prefix taken live from the registry's own header
  (`cd0_dependency.document_magic_hex="4c504344"`, `version_uvar_hex="00"`), not hardcoded.

## Check 1 — Registry structure (script `01_load_and_structure.py`)
`len(definitions) == 675`, all 675 `fixture_id` unique, 106 item_class buckets sum to 675
exactly. Collections: `definitions` (675, the document carrier), `cd0_dependency`,
`closed_schemas` (schema metadata, no embedded documents), `normative_algorithms` (none),
`relation_and_mapping_tables` (contains 458 *extra* embedded per-pair CD/0 documents in
`scope_relation_table_0`/`temporal_relation_table_0` entries — outside the ruling's literal
"1105" scope per spec §13.2's explicit count, flagged for awareness, not a failure).

## Check 2 — Document enumeration (script `02_enumerate_and_verify_documents.py`)
```
registry docs (definitions[]) = 675
vector docs (215*2) = 430  (215 inputs + 215 expected)
TOTAL = 1105
TOTAL == 1105 ? True
```

## Check 3 — Well-formedness, all five sub-checks (a–e)
```
documents checked = 1105
documents PASS = 1105
documents FAIL = 0
```
Every hex re-decoded, every byte count and SHA-256 recomputed and diffed (not trusted from the
file); every decoded value present/non-empty; every hex starts with `4c50434400`. Bonus:
`checksum_is_semantic_identity` is uniformly `False` across all 1105.

## Check 4 — Vectors (script `03_vectors_id_census.py` + `03b`/`03c`)
215 lines, 215 valid JSON, 215 unique `vector_id`s, 0 parse errors, 62/62 core IDs present
(P001–P030, N001–N032). ID census by category (sums to 215): P-core 30, N-core 32, E1–E9
errata-witness 10/4/7/5/2/2/31/3/15, I12 3, TARGET-schema 22, TEMPORAL-relation 9,
SCOPE-relation 7, PLACEMENT-consistency 4, LOSS-ACCOUNT 14, RESOURCE 13, METADATA-neutrality 2.
Independent cross-tab on `vector_class`/`operation` fields reproduces spec §14's tables
entry-for-entry (e.g. errata-witness 52, negative 93, match-target 27).

## Check 5 — `doc-index.csv`
Written and verified to exist: 1106 lines (header + 1105 rows) — 675 `registry`, 215
`vector-input`, 215 `vector-expected`. IDs: `registry:<fixture_id>` / `<vector_id>:input` /
`<vector_id>:expected`. `sha256_of_octets`/`byte_count` columns are freshly computed, not
copied from the package.

## Check 6 — `frozen_packet_sha256` cross-check
Registry header value, ruling-required value (`bc54a23bb...81`), and the SHA-256 recomputed
directly from the on-disk frozen packet zip all match byte-for-byte.

## Bonus — whole-package `sha256sum --check LCI0-FIXTURE-SHA256SUMS.txt`: 20/20 OK.

## Out of scope (explicitly not checked here)
Semantic correctness of vector results (ruling §10 item 6's second half), item 4 (StableRef
closure behavior), item 5 (grammar/calculi executability) — all require a live CD/0/LCI
evaluator, not counting.

## LANE VERDICT: PASS
All six numbered checks PASS: 675 definitions exact; 1105 total documents exact (675 registry +
430 vector); 0/1105 well-formedness failures; 215/215 valid unique vectors with 62/62 core IDs
present; `doc-index.csv` written and verified (1105 rows); `frozen_packet_sha256` triangulated
match.

**Two counts for the chair: 675 registry definitions, 1105 total embedded CD/0 documents.
Verdict: PASS.**
