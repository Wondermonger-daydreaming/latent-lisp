# LAPIDARY — LCI/0 Errata 0.1 Verification Report

**Lane:** Ruling §10 items 1 and 10 (E1–E9 + I12 present without reopening the model; no placeholder/local-choice/silent-fallback/production-crypto/live-authority).
**Deliverable under test:** `LOCATED-CLAIM-IDENTITY-SPEC-ERRATA-0.1.md` (3,173 lines)
**Adjudication:** `LCI0-POST-REVIEW-RULING.md` §3 mapping (I01→E1, I02→E2, I03→E3, I04→E4, I05→fixture §1, I06→E5, I07→E6, I08→E7, I09→E8, I10+I11→E9(+fixture §9), I12→five clarifications)
**Source obligations:** `reviewed-inputs/review/FABLE-LCI0-ISSUE-REGISTER.md` (I01–I12)
**Method:** every hex extracted programmatically from the errata doc (no hand-transcription); every checksum recomputed; every hash checked against the real files on disk.

---

## CHECK 1 — E1–E9 present, discharge the mapped issue, stay within the adjudicated disposition

Presence confirmed by header grep: `## E1`…`## E9` all PRESENT.

### E1 (I01 — base references + five neutral expressions not byte-pinned) — **PASS**

- **Register obligation (I01 smallest repair):** *"name the four base references as §7.5 names scope's; pin the five neutral expressions as concrete records (in-spec, or by normative delegation to the fixture package with an exact-canonical-octets requirement); extend §11.7's shared-octets clause to all suites."*
- **Ruling disposition (§3.1):** *"E1 cures construction determinacy by pinning the complete abstract values and canonical octets; it does **not** alter the ClaimId projection."* Decision-4 / §10 item 3 fix the count at **ten** values.
- **Errata cure (E1.1):** *"For Mneme ClaimProfile/0 under this first-implementation profile, the five base StableRefs and five neutral values below are the only accepted values for their named roles. They are complete CD/0 values… A constructor MUST produce the exact abstract value and canonical octets stated here."* Shared-octet leg discharged at **E1.2**: *"The shared-octet obligation formerly stated for scope is extended to **all five base references and all five neutral expressions**."*
- **Fit:** All ten values carry both an *Exact abstract CD/0 value* (JSON) AND a *Complete canonical CD/0 document, lowercase hexadecimal*. The errata over-delivers relative to the register minimum (it re-pins scope *completely* rather than leaning on §7.5's partial material-name pin), which exactly matches the ruling's ten-value disposition. Projection untouched (E1 pins projection *inputs*, not the projection function). **DISCHARGED, within disposition.**

### E2 (I02 — admissibility floor / `relation-undetermined` door) — **PASS**

- **Register obligation:** *"positive restatement: admissible only if `match_target` returned `R("exact-target")` or `R("supports-by-scope-narrowing")`; enumerate `relation-undetermined` as hard-inadmissible."*
- **Ruling (§3.2):** *"only `R("exact-target")` and `R("supports-by-scope-narrowing")` can reach policy evaluation. A policy may still reject either success. It cannot resurrect an F-valued result."*
- **Errata cure (E2):** *"A warrant MAY proceed to admissibility-policy evaluation only when `match-target` returns `R("exact-target")` or `R("supports-by-scope-narrowing")`."* + *"Every F-valued target result is hard-inadmissible at this boundary. This includes `relation-undetermined`, `target-mismatch`, …"* + *"An admissibility policy MAY reject either successful R-valued relation. It MUST NOT convert, wrap, reinterpret, downgrade, or otherwise promote an F-valued result into support."*
- **Fit:** Exhaustive positive gate over exactly the two R-outcomes; `relation-undetermined` explicitly enumerated hard-inadmissible; policy may reject but cannot resurrect F. Wording seam, no prior-success reversal (consistent with ruling §7). **DISCHARGED.**

### E3 (I03 — version-bump governance) — **PASS (uses the ruling's narrower tie-break, not Fable's shorthand)**

- **Register obligation:** one tie-break sentence + require conformance evidence binding an immutable normalizer content identity and a mutation vector per revision.
- **Ruling's *narrower* tie-break (§3.3):** *"Identity-policy owns the field set, field ownership, projection role, and identity projection. Claim-profile and frame-schema versions own proposition grammar, normalization contract, semantic interpretation, and proposition/location consistency… A meaning-preserving implementation correction may keep both versions only when conformance evidence proves no accepted abstract input, normalized proposition, ClaimId, relation, or failure changed. The implementation binary is never placed in ClaimId."*
- **Errata cure (E3.1):** clause 1 → identity-policy version for *"the ClaimId field set, field ownership, projection role, or identity projection"*; clause 2 → claim-profile/frame-schema version for *"proposition grammar, normalization contract, semantic interpretation, interpretation-frame schema, or proposition/location consistency rules while the projection field set remains the same"*; clause 3 carve-out: *"need not change either version, but MUST carry conformance evidence proving preservation."* E3.2 binds `normalizer.conformance-binding.0` (immutable content identity), `normalizer.mutation-vector.0` (mutation witness per revision), `normalizer.semantic-projection-ledger.0`, and: *"The implementation binary, process image, compiler output, host path, deployment hash, or mutable package version MUST NOT be placed in ClaimId."*
- **Fit:** The ruling's four-owner narrower tie-break, **not** Fable's "normalization-contract change ⇒ profile version only" shorthand. Immutable content identity + per-revision mutation vector both bound. **DISCHARGED, within the narrower disposition.**

### E4 (I04 — pre-projection normalization discipline only for scope) — **PASS**

- **Register obligation:** *"replicate §11.4's discipline verbatim into §12/§13/§14.5; add an explicit MUST that a proposition with no meaning-bearing interpretation context uses the neutral self-describing frame."*
- **Ruling (§3.4):** *"E4 establishes a uniform pre-projection normalization contract."*
- **Errata cure (E4):** *"Every identity-bearing pre-projection normalizer for scope, subject-time, interpretation frame, dataset slice, and semantic boundary MUST be: total… deterministic… explicitly versioned and governed by E3… pure and independent of ambient state…; loss-reporting…; applied before ClaimId projection."* + *"A proposition with no meaning-bearing interpretation context MUST use the exact pinned `neutral.self-describing-frame`."*
- **Fit:** §11.4's discipline made uniform across all five coordinates; neutral-frame MUST pinned. **DISCHARGED.**

### E5 (I06 — scope-narrowing failure vocabulary) — **PASS**

- **Register obligation:** *"add `ScopeNarrowingNotDeclared` + a coverage-failure code, wire into §10.6/§18; require a negative vector: broad target + nonmonotone proposition form → refusal."*
- **Ruling (§3.5):** *"E5 creates `ScopeNarrowingNotDeclared` and `ScopeNarrowingCoverageInsufficient`; neither path may collapse into `ClaimTargetMismatch`, `ScopeWideningForbidden`, or an implementation-local result."*
- **Errata cure (E5):** both codes added; *"These paths MUST NOT return generic `ClaimTargetMismatch`, `ScopeWideningForbidden`, an implementation-local code, or a policy decision."* Witnesses `LCI0-E5-NONMONOTONE-NARROWING` (expected `ScopeNarrowingNotDeclared`) and `LCI0-E5-COVERAGE-INSUFFICIENT` (expected `ScopeNarrowingCoverageInsufficient`).
- **Fit:** Two typed failures + executable negative vectors. **DISCHARGED.**

### E6 (I07 — intra-rank multi-fault precedence; OPTION ONE) — **PASS**

- **Task-specified constraint:** implement **option-one deterministic schema-field order + depth-first recursion** (ruling §3 I07 "OPTION ONE SELECTED"; §3.5 "deterministic closed-schema field order and depth-first recursion").
- **Errata cure (E6):** *"LCI/0 selects deterministic schema-field order. For every closed record, failures are selected by this total procedure:"* — step 3 *"Within one rank, missing required fields are tested in the schema's declared field order."*; step 4 *"Present declared fields are recursively validated **depth-first** in that same field order."*; step 8 *"The first failure reached is returned with its exact category, code, stage, and structural path."* Record `algorithm.validation-precedence.0`.
- **Fit:** Option one + depth-first, exactly as adjudicated. The register's *alternative* ("or explicitly unspecified in /0 and excluded from conformance") was **not** taken — grep confirms no "unspecified/excluded from conformance" language in E6. **DISCHARGED.**

### E7 (I08 — StableRef scheme fragmentation) — **PASS**

- **Task-specified constraint:** namespace **all fourteen** schemes under `Id(["lisp-plus","lci","0","fixture"], …)` **without constitutionalizing production identity** (ruling §3.6).
- **Errata cure (E7.1):** *"For the first implementation profile, each domain below has exactly one canonical scheme."* Table enumerates **14 domains** — scope-calculus, temporal-model, dataset-slice-calculus, semantic-boundary-calculus, interpretation-frame-schema, logical-corpus, immutable-corpus-revision, module, procedure, model, prompt-invocation, artifact, principal, policy — every scheme Identifier of form `Id(["lisp-plus", "lci", "0", "fixture"], ["scheme", …, "structural", "0"])`. *"The first implementation MUST NOT choose among multiple schemes for the same fixture semantic object."* E7.2 supplies the future-bridge rule.
- **Fit:** 14 domains, one namespaced structural scheme each, no production-global identity claimed (consistent with ruling §6). **DISCHARGED.**

### E8 (I09 — digest-equality wording) — **PASS**

- **Task-specified constraint:** remove digest-equality-as-semantic-equality **unconditionally**.
- **Errata cure (E8):** *"Digest equality is never the definition of semantic ClaimId equality."* (no `when`-clause) + *"No collision rule, envelope-resolution rule, lookup convention, content-addressing convention, or successful digest verification may promote digest equality into semantic equality."* + *"A digest-only purported ClaimId is refused."*
- **Fit:** The old §20.11 conditional (*"…**when** the scheme's collision and envelope-resolution rules are not satisfied"*) is replaced by an unconditional prohibition closing the exact loophole (a scheme "resolves collisions operationally"). **DISCHARGED unconditionally.**

### E9 (I10 + I11 — migration reconciliation + adversarial witnesses) — **PASS**

- **Task-specified constraint:** **TOTAL** reconciliation of seven LCI migration classes to the five prior-ruling classes AND restore every migration vector category.
- **Errata cure (E9.1):** seven → five mapping — `exact→exact`, `exact-after-explicit-tagging→explicitly-tagged`, `new-identity-required→profile-adapted`, `lossy-with-represented-loss→lossy-with-represented-loss`, `rejected→rejected`, `deferred-to-named-calculus→profile-adapted` (gate), `privileged-runtime-relation-outside-claim-id→profile-adapted` (*"live authority is not migrated"*). All seven LCI terms mapped; all five prior terms are targets. Guard: *"Qualified many-to-one rows do not turn a gate, uncertainty, or privilege relation into a successful identity migration."*
- **Errata cure (E9.2):** required witnesses include Unicode non-normalization (NFC/NFD), ambient-printer/whitespace variation, hostile legacy payloads (read-eval/reader-macro), plausible-but-ambiguous `as-of`, near-miss package/symbol, syntactically-valid/semantically-wrong mappings, legacy fingerprints colliding across **scope / subject-time / immutable corpus revision** (three dimensions), inert predecessor warrants, attempted live-warrant restoration.
- **Fit:** Total 7→5 reconciliation; every §16.4 category restored (Unicode / printer / hostile payload) plus I11 middle-ground vectors. Guard: *"Migration MUST NOT invoke v1 code, host reader evaluation, current mutable registries, or live authority restoration. It creates zero live warrants."* **DISCHARGED (both I10 and I11).**

---

## CHECK 2 — All five I12 clarifications present — **PASS**

- **(1) reserved profile-location exception, still identity-bearing → I12(a):** *"Empty Mneme/0 `profile-location` is a reserved forward-compatibility slot and an explicit exception to the per-claim minimality test. It remains identity-bearing…; implementations may not omit it."* PASS
- **(2) policy meta-testimony marker; not direct support → I12(b):** *"A policy-evaluation WarrantTarget MUST record `inner-target-relation` and `testimony-mode`. The fixture mode is meta-testimony… It is not direct support for the embedded claim, and no consumer may erase that distinction."* PASS
- **(3) `PrivilegedRestorationAttempt` in LCI namespace, never reinterpreting a CD/0 category → I12(c):** *"`PrivilegedRestorationAttempt` in this packet is an LCI failure code. It does not replace, alias, broaden, narrow, or reinterpret any frozen CD/0 category or code bearing similar words."* PASS
- **(4) recursive nested-version fail-closed closure → I12(d):** *"Unsupported nested calculus, temporal-model, slice-calculus, boundary-calculus, frame-schema, StableRef scheme/material, target schema, represented-loss account schema, and closed record versions fail closed recursively. No enclosing supported version may legalize an unsupported nested version."* PASS
- **(5) inert/live separation = mandatory future debt; no improvised revival/standing/live authority → I12(e):** *"Inert/live warrant separation is a mandatory debt of the future warrant constitution… It MUST NOT invent issuance, standing, revocation, custody, revival, or live-authority transitions."* PASS

All five present and faithful to the adjudicated wording.

---

## CHECK 3 — NO MODEL REOPENING — **PASS**

**Change-boundary self-statement (§0 + "Change boundary" table):**
- §0: *"This errata closes E1–E9 and incorporates the five I12 clarifications **without changing the selected ClaimId or WarrantTarget model**."* / *"Nothing in this errata modifies frozen CD/0. No digest in this package is semantic identity."*
- Change-boundary table: ClaimId field set → No change · ClaimId field ownership/projection → No change · WarrantTarget field set → No change · Accepted previously determinate ClaimIds → No change · Already unambiguous canonical octets → No change · CD/0 → No change · versions all remain 0 / /0.

**Active hunt for smuggling (operative text vs. the boundary statements):**
- **ClaimId field additions:** none. E3.2 *actively forbids* one: *"The implementation binary… MUST NOT be placed in ClaimId."* E1 pins projection *inputs* (existing Scope/0, SubjectTime/0, StableRef/0 structures), not new fields.
- **Projection-semantics change:** none. E4 normalizers are *"applied before ClaimId projection"* and *"Implementations MUST NOT infer denotational equivalence after projection."* — projection function untouched; normalization strictly upstream.
- **I12(a) profile-location:** not a new field. The ruling's selected model already lists `profile-location` in `location{…}`; I12(a) confirms the existing empty field stays identity-bearing.
- **I12(b) — nearest-the-line item, verified benign.** It requires a policy-evaluation *boundary* to carry `inner-target-relation` + `testimony-mode`. Verified against the candidate: §4.7 (line 68) already enumerates *"policy evaluation… or other evidence-specific boundaries"* as a **kind-specific boundary record**, and §9.14 (line 1067) already defines the policy-evaluation target binding policy identity/version, evaluated warrant reference, state snapshot reference, query time. I12(b) refines the content of an **already-existing evidence-kind boundary** — squarely inside *"complete ClaimId plus typed evidence-kind-specific boundaries"* — and is explicitly authorized by ruling §3.9(2). It does **not** change the WarrantTarget field set. NOT a smuggle.
- **CD/0 touch:** none. E6 step 1 *references* CD/0 decode ordering without changing it; E8 keeps semantic equality as *"equality of validated ClaimId envelopes, witnessed by canonical CD/0 octets"*; E1.2: *"The existing octets never change in place."* Newly pinned octets are new LCI fixture values produced by applying the already-frozen CD/0 grammar (ruling §5).

No field smuggled, no projection semantics changed, no CD/0 surface touched.

---

## CHECK 4 — E1 pins exactly TEN complete values — **PASS**

Ten values = 5 base references + 5 neutral expressions, each with a full abstract CD/0 value AND a complete canonical octet string (lowercase hex). Extracted to `e1-values.json`. For every value: declared byte count == hex-string length / 2, and the declared *SHA-256 review checksum* recomputes exactly from the decoded bytes; every document begins with CD/0 magic `4c5043440031`.

| # | id / spec_reference | byte_count | hex len | bytecount==hex/2 | review-checksum recompute |
|---|---|---|---|---|---|
| 1 | stable-ref.scope-calculus.primary | 563 | 1126 | ✓ | ✓ |
| 2 | stable-ref.temporal-model.primary | 568 | 1136 | ✓ | ✓ |
| 3 | stable-ref.slice-calculus.primary | 593 | 1186 | ✓ | ✓ |
| 4 | stable-ref.boundary-calculus.primary | 608 | 1216 | ✓ | ✓ |
| 5 | stable-ref.frame-schema.primary | 608 | 1216 | ✓ | ✓ |
| 6 | neutral.universal-scope | 936 | 1872 | ✓ | ✓ |
| 7 | neutral.atemporal-subject-time | 960 | 1920 | ✓ | ✓ |
| 8 | neutral.all-members-slice | 984 | 1968 | ✓ | ✓ |
| 9 | neutral.not-applicable-boundary | 1013 | 2026 | ✓ | ✓ |
| 10 | neutral.self-describing-frame | 778 | 1556 | ✓ | ✓ |

**Extraction is the cross-check leg** for the independent recompute agent — hex copied byte-for-byte via script (no hand transcription). Full hex in `e1-values.json`; verification detail in `_e1_verified.json`.

---

## CHECK 5 — Ruling §10 item 10 scan (placeholder / local choice / silent fallback / production crypto / live authority) — **PASS, zero real violations**

Whole-document greps. Every hit adjudicated:

- `TBD` / `TODO` / `to be determined`: **none** — clean.
- `for example` / `e.g.` / `for instance` doing normative work: **none** — clean.
- `silent` / `fallback` / `fall back` / `default`: **none** — **no silent version fallback** (I12(d) mandates the opposite: recursive fail-closed).
- `unspecified` / `undefined` / `excluded from conformance` / `arbitrary` / `at discretion` as escape hatch: **none** — confirms E6 took option one.
- implementer choice (1 hit, line 3080): **BENIGN — a prohibition:** *"The first implementation MUST NOT choose among multiple schemes for the same fixture semantic object."*
- `where applicable` (1 hit, line 3006): **BENIGN** — qualifies which surfaces a *pinned* mutation-vector record (1665 bytes, checksum given) covers; not a normative gap.
- production crypto / `sha-256` / cryptographic: the `sha-256` hits are review checksums explicitly labeled *"(not semantic identity)"*; line 3096 *defers* crypto — *"A later digest MAY be an operational reference only under its own named cryptographic scheme"* — selecting **no** production algorithm (consistent with ruling §6; StableRef material is structural `FixtureStableMaterial/0`, not a hash). **BENIGN.**
- issuance / standing / revocation / revival / live authority / custody (lines 3114, 3132, 3154): **every hit is a prohibition or deferral, never an invention** — *"live authority is not migrated"*; *"Migration MUST NOT invoke… live authority restoration. It creates zero live warrants."*; *"It MUST NOT invent issuance, standing, revocation, custody, revival, or live-authority transitions."* **BENIGN.**

No placeholder, no local semantic choice, no silent version fallback, no production-crypto selection, no live-authority invention.

---

## CHECK 6 — Cross-consistency of cited hashes — **PASS**

- Candidate spec (`LOCATED-CLAIM-IDENTITY-SPEC.md`): errata cites `6fa2965ed727b4d89b09a3d9c171bcfa3aea8c23f486ef87dc33f85bcb9ae5ba`; on-disk `sha256sum` = `6fa2965ed727…ae5ba`; ruling states `6fa2965e…`. **MATCH.**
- Frozen CD/0 packet (`…-56f0ce55253e.zip`): errata cites `bc54a23bbd235fc0ee4d0485c2091585e506dbc7cf74b0e16318580465aa1f81`; on-disk `sha256sum` = `bc54a23bbd23…a1f81` (sidecar `.sha256` agrees); ruling states `bc54a23b…`. **MATCH.**

---

## LANE VERDICT: **PASS**

- **CHECK 1 (E1–E9 discharge + within disposition):** PASS — all nine present; each discharges its mapped register obligation with the ruling's adjudicated narrowing (E3 four-owner tie-break, E6 option-one + depth-first, E7 14 namespaced schemes, E8 unconditional, E9 total 7→5 + all vector categories).
- **CHECK 2 (five I12 clarifications):** PASS — I12(a)–(e) all present and faithful.
- **CHECK 3 (no model reopening):** PASS — no ClaimId field/projection change, no WarrantTarget field-set change, no CD/0 touch; I12(b) verified as content of an already-existing evidence-kind boundary (ruling-authorized), not a field-set change.
- **CHECK 4 (ten E1 values):** PASS — 5 base + 5 neutral, each with abstract value + lowercase-hex octets; byte counts and review checksums recompute exactly; extracted to `e1-values.json`.
- **CHECK 5 (§10 item 10 placeholder scan):** PASS — zero real violations; every keyword hit is a prohibition, a deferral, or a review artifact.
- **CHECK 6 (hash cross-consistency):** PASS — candidate `6fa2965e…` and frozen CD/0 `bc54a23b…` both match on disk and match the ruling.
