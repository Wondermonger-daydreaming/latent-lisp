# LANE REPORT — CODA (Leg D: frozen-Python codec verification of the 458 relation-table documents; supplementary)

> Provenance: the agent returned this report as final-message text (the harness blocks
> subagent-written report files); persisted verbatim by the chair (Fable 5), 2026-07-14.
> Agent model: Sonnet. Script (`leg_d_relation_tables.py`), raw log (`leg-d-python.log`), and
> machine summary (`leg-d-summary.json`) in this directory.

**Charge:** finish the differential over RELIQUARY's find — the 458 embedded documents in
`LCI0-FIXTURE-REGISTRY.json`'s `relation_and_mapping_tables` (169 in
`scope_relation_table_0.entries[]`, 289 in `temporal_relation_table_0.entries[]`) that SMITH's
Leg A never touched (Leg A enumerated only `definitions[]` (675) + vector inputs/expected
(215+215) = 1,105, per spec 13.2).

### What was verified before running
- Confirmed the 458-document shape matches `definitions[]` exactly for the codec-relevant keys
  (`abstract_cd0` with top-level `t`/`fields`, `canonical_cd0_hex`, `canonical_octets_byte_count`,
  `sha256_checksum_of_canonical_octets`, `expected_decoded_abstract_value`) — direct `json.load`
  inspection, not assumed.
- Confirmed RELIQUARY's CSV breaks down to exactly 169 + 289 = 458 registry rows (+ 30 separate
  `vectors.jsonl:...E1-...` rows, which are the already-closed E1-nested set — excluded by
  construction since my script only walks `relation_and_mapping_tables`, never `vectors.jsonl`).
- Reused SMITH's adapter **verbatim by import** (`import leg_a_python as smith`, then
  `smith.adapt`, `smith.cd0`, `smith.BUDGET`, `smith.first_divergence`) — no re-derivation.
  Caught and fixed one bug before trusting output: SMITH's `adapt()` writes string-consistency
  findings into a **module-level** list inside `leg_a_python.py`, so my script binds to
  `smith.string_consistency_failures` directly rather than a fresh local list (which would have
  silently under-reported).

### Commands run
```
cd .../scratch/coda
python3 leg_d_relation_tables.py > leg-d-python.log 2>&1
echo "REAL EXIT CODE: $?"   # → 0
```

### Result (pasted from leg-d-python.log)
```
per-source breakdown (n / encode / bytecount / checksum / decode):
  scope_relation_table_0       n= 169 enc= 169 bc= 169 cs= 169 dec= 169
  temporal_relation_table_0    n= 289 enc= 289 bc= 289 cs= 289 dec= 289

  total: 458
  encode_agree: 458
  bytecount_agree: 458
  checksum_agree: 458
  decode_agree: 458

string text<->utf8_hex consistency failures: 0
MISMATCHES: 0
LEG D VERDICT: PASS
```
458/458 encode-agree, 458/458 decode-agree, 458/458 bytecount, 458/458 checksum. Zero
mismatches on the first run — no divergent-byte-offset report needed.

### Extra sanity check (bonus, not strictly required)
Confirmed the 458 are genuinely additional, not double-counted: built the set of
`canonical_cd0_hex` values SMITH's 1,105 documents cover (1,076 distinct — some docs
legitimately share canonical bytes) and compared against the 458 relation-table hexes (458
distinct). **Overlap = 0.** RELIQUARY's find is real, uncovered territory.

### Frozen worktree git status — before/after
```
BEFORE: HEAD 56f0ce55253ef8dd4caaf80b03e49835c4087406, tree e73d50772b22651df4f9620cd971baaf4de74739, git status --porcelain empty
AFTER:  HEAD 56f0ce55253ef8dd4caaf80b03e49835c4087406, tree e73d50772b22651df4f9620cd971baaf4de74739, git status --porcelain empty
```
Unchanged. No tracked file in the frozen worktree was touched; all new code/logs live under
`scratch/coda/`.

### LANE VERDICT: PASS

Combined with SMITH's Leg A (1,105/1,105) and Leg B (same 1,105 via frozen Common Lisp), the
receipt can now say every embedded document the registry actually contains — 1,105
manifest-counted + 458 relation-table-embedded = 1,563 total — has been codec-verified against
the frozen Python implementation with 0 mismatches.
