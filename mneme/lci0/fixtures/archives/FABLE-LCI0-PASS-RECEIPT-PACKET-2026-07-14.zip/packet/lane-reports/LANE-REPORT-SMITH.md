# SMITH — LCI/0 Errata Differential Verification (Ruling §10 items 3, 7, 8)

**Role:** SMITH, forge-master of the differential.
**Charge:** Prove every one of the 1,105 CD/0 documents in the LCI/0 fixture package
byte-agrees across BOTH frozen codecs (Common Lisp + Python), and satisfy the
package manifest's open **FABLE GATE** (item 8: "No Common Lisp runtime in
authoring environment; Fable must rerun").
**Date:** 2026-07-14. **Producing model:** Claude Opus 4.8 (1M context).

## Environment
| Item | Value |
|---|---|
| SBCL | SBCL 2.4.6 (/home/gauss/.local/bin/sbcl) |
| Python | Python 3.11.14 (python3 == .venv/bin/python) |
| Frozen worktree | _staging/lci0-errata-verify/frozen-56f0ce55/ |
| Frozen commit | 56f0ce55253ef8dd4caaf80b03e49835c4087406 |
| Frozen tree | e73d50772b22651df4f9620cd971baaf4de74739 |
| Frozen Python codec sha256 | 4d251590e4957187552ee0a2c6dc4131348fec54be2bb424839ef8e61f880dbe (canonical-datum/python/cd0/__init__.py) |
| Frozen CL codec sha256 | ab9ec04db911222192ed99c413b580179f2cd0539c240f96f3ded933bfb921b7 (canonical-datum/common-lisp/cd0.lisp) |
| Package root | package/lci0-errata-0.1-fixture-package-2026-07-14/ |
| SMITH workspace | scratch/smith/ |

### Worktree git status — before/after (clean throughout)
BEFORE: HEAD 56f0ce55..., tree e73d5077..., `git status --porcelain` empty.
AFTER (post LEG0/A/B/C): `git status --porcelain` empty; HEAD/tree unchanged.
No tracked file modified. All new code/corpora/logs live only under scratch/smith/.
Package inputs treated as immutable.

### Package input integrity (pre-flight)
`sha256sum -c LCI0-FIXTURE-SHA256SUMS.txt` -> all 21 members OK.
Confirmed manifest counts: 675 registry definitions, 215 vectors, 1,105 documents.

## Adapter discipline & the one schema finding
The frozen codecs are reused EXACTLY as frozen. The only new code is a pure
structural adapter with no semantic choices.

FINDING (schema, non-ambiguous): the package `abstract_cd0` /
`expected_decoded_abstract_value` use a human-readable CD/0 serialization (plain
UTF-8 strings), a DIFFERENT schema from the one the frozen from_fixture_ast /
datum-from-fixture-ast import path consumes (hex-based fixture AST). The frozen
suites' own vectors (cd0-positive.jsonl) use the hex schema, confirming the
divergence is real. Adapter mapping (package -> codec fixture-AST):
- unit/bool/int/bytes/seq/record: pass-through (record field {key,value} wrappers identical)
- rat: {num,den} -> {p,q} (rename)
- string: {text,utf8_hex} -> {utf8_hex} (drop redundant `text`, keep authoritative utf8_hex)
- id: {namespace,path} plain -> {namespace_utf8_hex,path_utf8_hex} (UTF-8 -> lowercase hex per segment)

schema_scan.py proved the adapter TOTAL: every dict node across all 1,105 docs
carries exactly one of these 10 tags; the only untagged dict nodes are the
required record-field {key,value} wrappers. Redundant string.text was verified
byte-consistent with string.utf8_hex across the whole corpus (0 inconsistencies),
so dropping text is lossless. No ambiguity was left unresolved.

Budget: all legs use cd0-conformance-default (the frozen codec's own reference
budget; CL (default-resource-budget) is byte-identical, all 14 limits equal).
corpus_stats.py proves it covers the corpus with margin on every dimension
(NOT enlarged, so no legitimate refusal is masked):
corpus-max depth=11(<=128) nodes=21862(<=100000) seq=289 rec=16 idsegs=9
single-string=105B single-bytes=1013B aggregate=517939(<=1048576) reckey=309547.

Enumeration rule (exactly 1,105) per spec 13.2: 675 registry definitions + for
each of 215 vectors its inputs doc and expected doc (215x2=430). 675+430=1105.

## LEG 0 — frozen suites green, untouched
CL: `sbcl --noinform --disable-debugger --script canonical-datum/common-lisp/run-tests.lisp`
 -> "CD/0 Common Lisp seed conformance: PASS"; positives 25/25; negatives 71/71
 (68 executed, 0 failures, 0 skips, 3 N/A); total assertions 2633; EXIT 0.
Python: `PYTHONPATH=canonical-datum/python python3 -m unittest discover -s canonical-datum/python/tests -v`
 -> Ran 167 tests, OK; EXIT 0.
git status clean immediately after. LEG 0: PASS.

## LEG A — frozen Python codec over all 1,105 documents
Code: leg_a_python.py -> leg-a-python.log, leg-a-summary.json.
per-source (n/encode/bytecount/checksum/decode):
  registry-definition 675/675/675/675/675
  vector-input        215/215/215/215/215
  vector-expected     215/215/215/215/215
totals: encode_agree 1105, bytecount_agree 1105, checksum_agree 1105,
decode_agree 1105; string text<->utf8_hex consistency failures 0; MISMATCHES 0.
LEG A: PASS.

## LEG B — frozen Common Lisp codec over all 1,105 documents (FABLE GATE)
frozen run_differential.py targets integration/cases/, not this corpus, so SMITH
generated a CL-read-able s-expression corpus (Python emits; leg_b_gen.py) and a
minimal runner (leg_b_runner.lisp) that LOADS the frozen system unmodified and
uses the native CL reader — no hand-written JSON parser on the CL side; corpus is
pure ASCII (Unicode carried as utf8_hex). Per doc: datum-from-fixture-ast ->
encode-exact -> octets-to-hex vs canonical_cd0_hex; then hex-to-octets ->
decode-exact -> equal-datum(decoded, datum-from-fixture-ast(expected)).
Budget (default-resource-budget) == cd0-conformance-default.
Corpus leg-b-corpus.lisp-data: 1,105 forms, 69,528,335 bytes. Log leg-b-cl.log.
`sbcl --dynamic-space-size 4096 --noinform --disable-debugger --script leg_b_runner.lisp`
 -> total 1105, encode_agree 1105, decode_agree 1105, encode_fail 0, decode_fail 0,
 errors 0; LEG B VERDICT PASS; EXIT 0.
(--dynamic-space-size must PRECEDE toplevel options; heap flag only, no codec change.)
FABLE GATE satisfied. LEG B: PASS.

## LEG C — the TEN E1-pinned values, three-way agreement
Extractor+Python leg_c_extract_verify.py (leg-c-python.log); CL third leg
leg_c_gen.py + leg_c_runner.lisp (leg-c-cl.log); merged e1-recompute.json.
Ten values parsed verbatim from errata E1 "Base reference N"/"Neutral expression
N" blocks (exact abstract json + pinned canonical hex). Each recomputed with
frozen Python AND frozen CL; both byte-equal the errata hex. Also checked byte
count, errata review checksum vs sha256(octets), Python decode round-trip, and
registry entry (by fixture_id) octets.

fixture_id | errata=Py | errata=CL | bytecount | review-cksum | decode-rt | registry
1 stable-ref.scope-calculus.primary     | ok ok ok ok ok ok
2 stable-ref.temporal-model.primary     | ok ok ok ok ok ok
3 stable-ref.slice-calculus.primary     | ok ok ok ok ok ok
4 stable-ref.boundary-calculus.primary  | ok ok ok ok ok ok
5 stable-ref.frame-schema.primary       | ok ok ok ok ok ok
6 neutral.universal-scope               | ok ok ok ok ok ok
7 neutral.atemporal-subject-time        | ok ok ok ok ok ok
8 neutral.all-members-slice             | ok ok ok ok ok ok
9 neutral.not-applicable-boundary       | ok ok ok ok ok ok
10 neutral.self-describing-frame        | ok ok ok ok ok ok
Python all_ok True; CL total 10 / cl_matches_errata 10 / fails 0; three_way_all_agree True;
registry octets match errata 10/10. LEG C: PASS.

## Artifacts (scratch/smith/)
schema_scan.py, corpus_stats.py, leg0-cl-tests.log, leg0-py-tests.log,
leg_a_python.py, leg-a-python.log, leg-a-summary.json,
leg_b_gen.py, leg_b_runner.lisp, leg-b-corpus.lisp-data, leg-b-cl.log,
leg_c_extract_verify.py, leg_c_gen.py, leg_c_runner.lisp, e1-values.jsonl,
e1-corpus.lisp-data, leg-c-python.log, leg-c-cl.log, e1-recompute.json.

## LANE VERDICT: PASS
- LEG0: PASS — frozen CL suite exit 0 (2633 assertions, 0 failures); frozen Python suite exit 0 (167 tests OK); worktree clean.
- LEG A: PASS — frozen Python over 1105 docs: 1105/1105 encode-agree, 1105/1105 decode-agree, 1105/1105 byte-count, 1105/1105 checksum, 0 mismatches.
- LEG B: PASS — frozen Common Lisp over 1105 docs (FABLE GATE rerun): 1105/1105 encode-agree, 1105/1105 decode-agree, 0 errors.
- LEG C: PASS — ten E1-pinned values in three-way byte agreement (errata=Python=CL), all present in the registry with identical octets.

Frozen worktree unchanged throughout (HEAD 56f0ce55..., tree e73d5077..., git status clean before/after). One documented schema finding required a pure, total, semantic-choice-free adapter; no ambiguity left unresolved.
