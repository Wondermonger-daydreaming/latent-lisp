# CLOSURE-WARDEN REPORT — LCI/0 Normative Fixture Package

**Charge:** Verify ruling §10 items 4 and 5 (+ item 10) — closure of the normative fixture package.
**Gate applied at every door:** *"Is there ANY choice left to an implementer here?"* If two conforming
implementers could diverge, the door is OPEN.

**Package root (immutable):** `_staging/lci0-errata-verify/package/lci0-errata-0.1-fixture-package-2026-07-14/`
**Read first-hand, in full:** `LCI0-NORMATIVE-FIXTURE-PACKAGE-SPEC.md` (all 1832 lines / 274 969 bytes).
**Cross-referenced:** `LCI0-POST-REVIEW-RULING.md`, `LCI0-FIXTURE-PACKAGE-MANIFEST.md`,
`LCI0-FIXTURE-REGISTRY.json` (675 definitions, queried mechanically), `LCI0-FIXTURE-VECTORS.jsonl` (215 vectors).

**Method (PLUMB):** Each sub-verdict cites exact spec § and registry fixture_id(s); the load-bearing step is a
shown mechanical query, not an assertion. Scripts/outputs beside this file (`registry_index.json`,
`item_class_counts.json`). Registry facts extracted from `abstract_cd0` field records, not prose.

---

## Global structural facts

| Fact | Evidence | Result |
| --- | --- | --- |
| Registry definitions | 675 records, 0 duplicate fixture_ids | OK |
| Vectors | 215 rows, 0 duplicate vector_ids | OK |
| Appendix A item-class counts vs registry | 99 classes, 0 mismatch, 0 extra, sums 675=675 | OK |
| Appendix B index vs JSONL | 215 index rows, bijective with 215 JSONL ids | OK |
| Vector-class counts vs spec §14 | all 12 classes match exactly (sum 215) | OK |
| All 17 closed_schemas | `unknown_fields:reject` + `recursive_version_closure:true` on every one; only `claim-occurrence` has an `open_subrecord_path` (`nonidentity-metadata.entries`, deliberate §11 slot) | CLOSED |
| `P001–P030`, `N001–N032` | all present | OK |

The 99-class exact count agreement between the human spec index and machine registry is the strongest
incorporation witness: prose and byte authority cannot silently diverge.

---

## CHECK 1 — The 12 frozen items: present, closed, incorporated (≥2 spot-verified each)

| # | Item | Spec § | Spot registry fixture_ids | Closure | Verdict |
| --- | --- | --- | --- | --- | --- |
| 1 | Proposition grammar + subject/locator marking | §1.1–1.3 | `proposition.grammar.definition.0`, `proposition.placement-monotonicity-table.0`, 11× `proposition-form-schema.*.0` | each form-schema marks every arg `proposition-subject-content`\|`external-claim-location-locator`; `unknown-fields=reject`; I05 discharged | CLOSED |
| 2 | Scope calculus | §2 | `scope.calculus.primary.definition.0`, `scope.relation-table.0` | closed Scope/0; bridge-less `.second`; total table | CLOSED |
| 3 | Temporal model | §3 | `temporal.model.primary.definition.0`, `temporal.relation-table.0` | closed SubjectTime/0; bridge-less `.second`; total table | CLOSED |
| 4 | Slice+boundary calculi | §4 | `slice.calculus.primary.definition.0`, `boundary.calculus.primary.definition.0` | both `unknown_fields:reject`; enumerated forms only | CLOSED |
| 5 | Frame schema | §5 | `frame.schema.primary.definition.0`, `neutral.self-describing-frame` | exactly 5 frames incl. required `interpretation-frame.neutral`; components pinned+closed | CLOSED |
| 6 | ALL 14 StableRef schemes | §6 | `scheme-definition.artifact.structural.0` … `.policy.structural.0` | 14 defs, one per domain (Check 2) | CLOSED |
| 7 | 11 target shapes + monotonicity | §7,§2.3 | `target-schema-definition.observed.0`, `.translated.0` | 11 defs `unknown-fields=reject-recursively`, `optional=none`; monotonicity per (schema×form), never inferred | CLOSED |
| 8 | Frozen Policy-A/B | §8 | `admissibility-policy.a.0`, `.b.0` | both `hard-reject-every-f-valued-target-result=True` (Check 3) | CLOSED |
| 9 | v1 mapping tables + legacy parser | §9 | `migration.legacy-grammar.0`, `migration.package-symbol-map.0`, `migration.classification-map.0` | grammar non-evaluating; maps total over declared rows | CLOSED |
| 10 | LCI resource budgets | §10 | `resource-budget.lci-first-implementation.0`, `resource-workload-generator-registry.0` | 13 budgets, limits+failure-codes exact (Check 3) | CLOSED |
| 11 | Occurrence/artifact metadata | §11 | `closed-schema.claim-occurrence.0`, `claim-occurrence.schema-definition.0` | closed wrapper; only `nonidentity-metadata.entries` open; cache must recompute | CLOSED |
| 12 | RepresentedLoss accounts | §12 | `represented-loss-account-schema-definition.v1-migration.0`, `.handoff.0` (7 total) | 7 schemas `unknown-fields=reject-recursively` | CLOSED |

**Byte/checksum spot-cross-check (spec index ↔ registry), all PASS:** neutral.universal-scope (936B),
scheme-definition.artifact.structural.0 (1228B), admissibility-policy.a.0 (8128B), admissibility-policy.b.0
(8782B), target-schema-definition.observed.0 (5519B), proposition.grammar.definition.0 (23709B),
resource-budget.lci-first-implementation.0 (6733B), closed-schema.claim-occurrence.0 (3246B),
migration.legacy-grammar.0 (1309B), stable-ref-bridge.external-artifact-source-to-lci-fixture.0 (1551B).

**CHECK 1: CLOSED.**

---

## CHECK 2 — §10 item 4: the FOURTEEN StableRef domains

Mechanically verified: 14 domain-ids, 14 scheme-ids, 14 scheme-defs; each scheme-def's `domain` field maps 1:1
to a distinct domain (`n_scheme_defs=1` for all 14). Each carries `mutable-aliases-forbidden`, `version-rule`,
`represented-loss-rule`, `bridge-rule` structurally (single shared closed Identifier value each — no per-domain drift).

| # | Domain | one scheme-def | alias-refusal | version rule | loss rule | no-bridge/bridge witness |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | scope-calculus | `scheme-definition.scope-calculus.structural.0` | `mutable-aliases-forbidden=True`; `LCI0-E7-ALIAS-01` | `version-rule.new-meaning-new-object-version-or-object-id` | `loss-rule.explicit-account-or-refusal` | `LCI0-E7-SCHEME-01`; no-bridge `N011`(ScopeIncompatible) |
| 2 | temporal-model | `…temporal-model.structural.0` | ✓; `E7-ALIAS-02` | ✓ | ✓ | `E7-SCHEME-02`; `TEMPORAL-INCOMPATIBLE` |
| 3 | dataset-slice-calculus | `…dataset-slice-calculus.structural.0` | ✓; `E7-ALIAS-03` | ✓ | ✓ | `E7-SCHEME-03` |
| 4 | semantic-boundary-calculus | `…semantic-boundary-calculus.structural.0` | ✓; `E7-ALIAS-04` | ✓ | ✓ | `E7-SCHEME-04` |
| 5 | interpretation-frame-schema | `…interpretation-frame-schema.structural.0` | ✓; `E7-ALIAS-05` | ✓ | ✓ | `E7-SCHEME-05` |
| 6 | logical-corpus | `…logical-corpus.structural.0` | ✓; `E7-ALIAS-06` | ✓ | ✓ | `E7-SCHEME-06` |
| 7 | immutable-corpus-revision | `…immutable-corpus-revision.structural.0` | ✓; `E7-ALIAS-07` | ✓ | ✓ | `E7-SCHEME-07`; `N008`(alias) |
| 8 | module | `…module.structural.0` | ✓; `E7-ALIAS-08` | ✓ | ✓ | `E7-SCHEME-08` |
| 9 | procedure | `…procedure.structural.0` | ✓; `E7-ALIAS-09` | ✓ | ✓ | `E7-SCHEME-09` |
| 10 | model | `…model.structural.0` | ✓; `E7-ALIAS-10` | ✓ | ✓ | `E7-SCHEME-10` |
| 11 | prompt-invocation | `…prompt-invocation.structural.0` | ✓; `E7-ALIAS-11` | ✓ | ✓ | `E7-SCHEME-11` |
| 12 | artifact | `…artifact.structural.0` | ✓; `E7-ALIAS-12` | ✓ | ✓ | `E7-SCHEME-12`; bridge `E7-BRIDGE-PRESENT`/`-NONRETROACTIVE`, no-bridge `E7-BRIDGE-ABSENT` |
| 13 | principal | `…principal.structural.0` | ✓; `E7-ALIAS-13` | ✓ | ✓ | `E7-SCHEME-13` |
| 14 | policy | `…policy.structural.0` | ✓; `E7-ALIAS-14` | ✓ | ✓ | `E7-SCHEME-14` |

Every scheme uses identical structural `FixtureStableMaterial/0` (kind, schema-version, object-id,
object-version) — material record, NOT a hash. Sole bridge fixture
`stable-ref-bridge.external-artifact-source-to-lci-fixture.0`: `declared-domain=['alpha-file']`,
`total-over-declared-domain=True`, `retroactive-structural-equality=False`, `independent-test-required=True`,
distinct source-scheme → `scheme.artifact.structural.0`. Matches §6.2 exactly.

**CHECK 2: CLOSED.**

---

## CHECK 3 — §10 item 5: closure & executability

| Element | Evidence | Verdict |
| --- | --- | --- |
| Normalized grammar + subject/locator marking + `proposition-location-consistent` | `proposition.grammar.definition.0` (I05); per-form `argument-placements`; predicate structural; `PLACEMENT-*-{POS,NEG}`, `N014` | CLOSED (I05 discharged) |
| Placement rules | §1.2 + `proposition.placement-monotonicity-table.0` | CLOSED |
| Scope calculus | `scope.relation-table.0` total; 6 scope-relation + 1 F vector | CLOSED |
| Temporal calculus | `temporal.relation-table.0` total; 7 + 2 F vectors | CLOSED |
| Slice calculus | enumerated; unregistered fails closed | CLOSED |
| Boundary calculus | enumerated; relative/mutable/latest refused | CLOSED |
| 11 target schemas closed | all `unknown-fields=reject-recursively`, `recursive-version-closure=True`, `optional=none` | CLOSED |
| 11 target schemas pos+neg | all `LCI0-TARGET-NN-*-POS`(→exact-target) AND `-NEG`(→TargetBoundaryMissing) present | CLOSED |
| Policy-A hard-rejects every F | `admissibility-policy.a.0`: `hard-reject-every-f-valued-target-result=True`, `accepted=[exact-target,supports-by-scope-narrowing]`, `evaluation-order[0]=policy-step.target-relation-floor` | CLOSED |
| Policy-B hard-rejects every F | `admissibility-policy.b.0`: same floor-first + `hard-reject…=True` | CLOSED |
| F-reject witnessed both policies | 8 `admissibility-decision.{a,b}-{coverage,incompatible,nonmonotone,relation-unknown}-hard-reject` → `hard-reject-target-relation`, reasons `f-valued-target-result`+`policy-not-consulted`; `E2-*`, `P022` | CLOSED |
| Migration non-evaluating | `migration.legacy-grammar.0`: `read-eval=False`, `reader-macros=False`, `dotted-lists=False`, `circular-labels=False` | CLOSED |
| Migration zero live warrants | all 5 `migration-result.*` `live-warrants-created=False`; `N029`/`N030`/`E9-LIVE-RESTORATION` fail closed | CLOSED |
| 7→5 reconciliation total | `migration.classification-map.0`: 7 LCI classes → 5 prior-ruling terms, all covered | CLOSED |
| Resource budgets | 13 rows, every limit+failure-code byte-matches spec §10 (0 mismatch/extra); 13 `RESOURCE-*` vectors | CLOSED |
| Occurrence schema | `closed-schema.claim-occurrence.0` closed; `METADATA-NEUTRAL-ALL-FIELDS`(pos)+`METADATA-UNKNOWN-TOP-CLOSED`(neg) | CLOSED |
| RepresentedLoss accounts | 7 defs `reject-recursively`; 7 pos + 7 neg vectors; `account` never implementation-defined | CLOSED |

Multi-fault precedence (I07/E6): `algorithm.validation-precedence.0` sets
`arbitrary-multifault-order-permitted=False` + total rank+within-rank walk, `first-failure-returned=True`.

**CHECK 3: CLOSED.**

---

## CHECK 4 — Implementer-choice hunt

Searched spec `.md` AND registry JSON. Spec: `should`=0, `unspecified`=0, `TBD`=0, `TODO`=0, `at the
discretion`=0, `default`=0, `implementation-defined`=1, `implementer`=1, `placeholder`=1, `may`=7, `example`=3,
`optional`=19. Registry: `implementation-defined`=0, `may vary`=0, `unspecified`=0, `arbitrary`=3, `placeholder`=1.

All 7 `may` hits benign: §22 bounded ("only by its exact registry fixture ID"); §179 bounded ("only registered
surfaces"); §478 PROHIBITION ("no predicate may overturn"); §529/§531 bounded ("only as inert testimony…never
live"); §539 carved OUT of conformance ("only outside the conformance surface"); §706 bounded ("does not
silently alter ClaimId"). `example`×3 = pinned canonical representatives w/ octets in registry. `optional`×19 =
18× "Optional fields: none" + "no optional fields". `placeholder` = §740 "not a placeholder" + worked-claim
"replacing all §7.13 placeholders". `implementation-defined` = §588 "account is never implementation-defined".
`arbitrary`×3 = `arbitrary-multifault-order-permitted` set False.

**CHECK 4: CLOSED — 0 real implementer choices.**

---

## CHECK 5 — §10 item 10: no crypto / no live-authority / no silent fallback

| Requirement | Evidence | Verdict |
| --- | --- | --- |
| No production-crypto selection | all schemes `FixtureStableMaterial/0` structural record; registry crypto/hash-based=0; `checksum_is_semantic_identity=false` for all 675; digest fixture `stable-ref.policy.fixture-digest-zero` = "test-only…never semantic identity" (I09/E8; `N016`, `E8-*`) | CLEAN |
| No live-authority invention | `live-warrants-created=False`×5; `N029`/`N030`/`E9-LIVE-RESTORATION` fail closed; policies never turn inherited testimony into live authority | CLEAN |
| No silent version fallback | all 17 closed_schemas `recursive_version_closure=true`; target+loss schemas `reject-recursively`; `I12-RECURSIVE-NESTED-VERSION` (→RecursiveUnsupportedNestedVersion) | CLEAN |

**CHECK 5: CLEAN.**

---

## CHECK 6 — Deferral boundary == ruling-§9 list

Spec §15 defers: complete Mneme logic; production ontology; production cryptographic identity; universal
StableRef equivalence; live warrant issuance/standing/revocation/custody; capability/module authority;
production admissibility law — with "refusal gates so the identity implementation cannot improvise those systems."
Maps 1:1 to ruling-§9 / §6-decision-6. Nothing load-bearing to the first profile is deferred (all 12 items
present+closed). Minor wording locus: "active v1 runtime execution" not verbatim in §15 sentence — that deferral
is carried by §9's inert/non-evaluating design + legacy grammar `read-eval=False` (code-enforced). Belt-and-
suspenders, not an open door.

**CHECK 6: CLOSED.**

---

## Benign observations
- 4× `target-boundaries.observed.file-alpha.{animal,corpus-r3,exact,yesterday}` share octets (4115B): legit
  reuse — same boundaries, differing embedded ClaimId; enclosing warrant-targets are distinct sizes.
- All 11 `TARGET-NN-*-POS` share one expected result (`df040642…`, 741B): `R("exact-target")` is kind-invariant.
- Common Lisp exact-byte rerun = disclosed FABLE authorization gate (manifest row 4, §13.2, ruling §10.8), a
  byte-instrument limitation, outside the closure question. Node v22.16.0 + frozen Python both PASS 1105 docs.

---

## LANE VERDICT: PASS

- CHECK 1 (12 items present/closed/incorporated): CLOSED — byte/checksum cross-check PASS; 99-class count 675=675.
- CHECK 2 (§10.4 — 14 StableRef domains): CLOSED — one scheme/domain (mechanically verified), all 5 rules present, bridge+no-bridge tested.
- CHECK 3 (§10.5 — closure & executability): CLOSED — every element closed and vectored; both policies hard-reject every F (witnessed ×8); migration inert/zero-warrant; 7→5 total; 13 budgets exact.
- CHECK 4 (implementer-choice hunt): CLOSED — 0 real choices.
- CHECK 5 (§10.10 — no crypto/authority/silent-fallback): CLEAN.
- CHECK 6 (deferral boundary): CLOSED — exactly the ruling-§9 set.

The border holds. No door left open to an implementer within the closure surface (§10 items 4, 5, 10). The only
outstanding gate is the disclosed Common Lisp exact-byte rerun (Fable's, outside this lane).

— CLOSURE-WARDEN (Claude Opus 4.8, 1M context) · 2026-07-14
