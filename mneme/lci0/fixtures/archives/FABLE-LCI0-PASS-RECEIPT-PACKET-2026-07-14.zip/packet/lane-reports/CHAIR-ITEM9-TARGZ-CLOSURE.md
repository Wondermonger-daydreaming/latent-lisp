# Chair verification — Ruling §10 item 9 closure (ZIP/TAR.GZ twin agreement)

**Verified by:** Fable 5 (chair, first-hand — commands run in-session, outputs pasted verbatim)
**Date:** 2026-07-14 (UTC)

## Artifacts

| Archive | Path (delivery) | SHA-256 | Bytes |
|---|---|---|---|
| ZIP | `/mnt/c/Users/Tomás Pavam/Downloads/lci0-errata-0.1-fixture-package-2026-07-14.zip` | `36cc71ccf3c310a055199c54e84bf436c4505d92a6378f22e8b1d932f02e987d` | 4,857,158 |
| TAR.GZ | `/mnt/c/Users/Tomás Pavam/Downloads/lci0-errata-0.1-fixture-package-2026-07-14.tar.gz` | `ddc03ba184e835fdbd3c51e9a0f8d3edf4a93deb4d6b980544d82a5c47a83934` | 4,840,040 |

TAR.GZ was delivered by the owner mid-verification (dropped in Downloads at 01:05 local) after the chair
flagged its absence; the ZIP had arrived at 00:43.

## Checks and results

1. **Member-set identity.** `tar -tzf … | grep -v '/$' | sort` (22 members) diffed against BOOKKEEPER's
   `zip-members.txt` (zipinfo listing of the ZIP, 22 members): `diff` empty → **MEMBER SETS IDENTICAL**.
2. **Content identity.** Full extraction of the TAR.GZ to `targz-extract/`, then
   `diff -r targz-extract/lci0-errata-0.1-fixture-package-2026-07-14 package/lci0-errata-0.1-fixture-package-2026-07-14`
   (the package/ tree is the ZIP extraction): `diff -r` empty → **ALL 22 FILES BYTE-IDENTICAL**.
3. **Checksum satisfaction.** All members verified against `LCI0-FIXTURE-SHA256SUMS.txt` by BOOKKEEPER
   (20/20 OK via `sha256sum --check`; manifest + checksum-file coverage rules confirmed exact) and
   independently recomputed per-file (22/22 match). The byte-identity in (2) transfers those results to the
   TAR.GZ members.

## Verdict

**§10 item 9: PASS.** ZIP and TAR.GZ member sets are identical and all members satisfy
`LCI0-FIXTURE-SHA256SUMS.txt`.

— Claude Fable 5 (chair)
