# LANE REPORT — RELIQUARY (out-of-count embedded-document sweep; supplementary)

> Provenance: the agent returned this report as final-message text (the harness blocks
> subagent-written report files); persisted verbatim by the chair (Fable 5), 2026-07-14.
> Agent model: Sonnet. Scripts and raw sweep evidence in this directory.

## RELIQUARY findings — the overlooked drawer, opened

### 1. Census — the complete embedded-document inventory of the whole registry

Full recursive walk of `LCI0-FIXTURE-REGISTRY.json` (158MB) using two independent,
cross-validating detection methods: (A) every dict key whose name contains "hex" anywhere in
the tree, and (B) every string value anywhere in the tree starting with the magic prefix
`4c504344`, regardless of key name. Both methods converge on identical totals — meaning nothing
is hiding under an unexpected key name.

| Location | Embedded CD/0 documents | Status |
|---|---|---|
| `definitions[]` | 675 | already verified (RECKONER) |
| `relation_and_mapping_tables/scope_relation_table_0/entries[]` | 169 | **NOT in the 1,105 count — unverified until now** |
| `relation_and_mapping_tables/temporal_relation_table_0/entries[]` | 289 | **NOT in the 1,105 count — unverified until now** |
| `closed_schemas`, `normative_algorithms`, `cd0_dependency` (header fields), `fixture_namespace` | 0 | confirmed empty (header field `document_magic_hex` = bare "4c504344", 8 chars, correctly excluded — too short to be a document, just the magic constant itself) |
| **Total in registry** | **1,133** | 675 official + **458 extra** |

Also swept: 26 `hex` + 524 `utf8_hex` sub-fields inside `definitions[]`'s
`abstract_cd0`/`expected_decoded_abstract_value` trees — checked individually, none carry the
magic prefix; these are ordinary UTF-8/byte-string literals nested *inside* already-counted
documents, not additional documents.

### 2. Verification of the 458 outside-the-count documents (registry)

Applied RECKONER's exact five checks (a–e) to all 458 `scope_relation_table_0`/
`temporal_relation_table_0` entries — identical field shape to `definitions[]`
(`canonical_cd0_hex`, `canonical_octets_byte_count`, `sha256_checksum_of_canonical_octets`,
`abstract_cd0`, `expected_decoded_abstract_value`, all present on every entry).

```
documents checked = 458
documents PASS = 458
documents FAIL = 0
(a) lowercase/even-length/valid-hex FAIL = 0
(b) byte_count field mismatch FAIL = 0
(c) checksum recompute mismatch FAIL = 0
(d) decoded/abstract value missing FAIL = 0
(e) magic+version prefix mismatch FAIL = 0
bonus: abstract_cd0 missing/empty = 0
bonus: left_fixture/right_fixture referential integrity (resolve to real
definitions[].fixture_id) — dangling refs = 0
```

Independently cross-checked one entry outside Python (`xxd -r -p | sha256sum`) — matches exactly.

### 3. Sweep of `LCI0-FIXTURE-VECTORS.jsonl` — a genuine additional finding

The 215 official `inputs`+`expected` documents (430 total) confirmed present via the same
dual-method sweep, `inside_nodes == 430` verified True.

**Beyond that, 30 more embedded CD/0 documents were found**, all nested three levels deep inside
the 10 `LCI0-E1-*` vectors (errata-witness class E1, lines 67–76): each vector carries,
identically, a leaf node `{"hex": "<CD/0-magic-prefixed bytes>", "t": "bytes"}` at three
locations — `expected.abstract_cd0`, `expected.expected_decoded_abstract_value`, and
`expected_result.machine_value` — representing a CD/0 document embedded byte-for-byte as opaque
"bytes"-typed material inside the claim's own abstract syntax tree (evidently the
stable-reference/nested-material mechanism E1 is built to exercise). These use the generic key
name `hex`, not `canonical_cd0_hex`, so a naive key-name-only scan (or RECKONER's narrower
check) would not surface them.

```
outside documents checked = 30
outside documents PASS = 30
outside documents FAIL = 0
(checks c/d applied only where companion fields are present — none are, since these are bare
 {"hex","t"} leaf nodes, not full "document" records; task's own "if present"/"if claims one"
 wording licenses this)

BONUS check (byte-identity across the 3 occurrences per vector):
LCI0-E1-01..10: 3 occurrences each, 1 distinct sha256 each -> OK (all identical)
cross-occurrence identity FAILURES = 0
```

Independently spot-checked one such node outside Python — matches exactly.

**Sanity note:** this nested-embedding pattern is unique to the vectors file — the registry's
own `hex`/`utf8_hex` sub-fields (item 1 above) never carry the magic prefix. No document search
continued below three levels turned up anything else; both detection methods (key-name and
value-prefix) agree exactly (460 = 460) confirming no hidden magic-prefixed strings elsewhere.

*(Chair's addendum, same session: the 10 distinct nested-doc SHA-256s were matched 10/10 to the
ten E1-pinned values recomputed three-way by SMITH — so the nested material is byte-identical
to already-codec-verified octets. See the PASS receipt §4.)*

### 4. Extension index

`extra-doc-index.csv` — 488 rows (458 registry + 30 vector-nested), columns
`json_path, sha256_of_octets, byte_count`. All 488 `json_path` values unique; the only
duplicate sha256 groups are the 10 E1 vectors' expected 3-way internal repeats.

### Grand total census (whole package)

675 (definitions) + 430 (vector inputs/expected) = **1,105 officially counted** (RECKONER's
domain, untouched). 458 (relation/mapping tables) + 30 (E1 nested bytes-material) = **488
additional embedded CD/0 documents found outside the official count, all now verified, 0
failures.**

## LANE VERDICT: PASS

Zero failures across all checks on all 488 documents found outside the official 1,105-document
count. The one genuine surprise — 30 nested CD/0 documents embedded as opaque `{"hex","t":"bytes"}`
material inside the 10 `LCI0-E1-*` vector fixtures — is not a defect; it verifies clean and
internally consistent (byte-identical across its three occurrences per vector), but it is new
information: nobody had machine-verified those 30 before this sweep, and they sit at a nesting
depth a shallow census would not reach.
