# LANE REPORT — BOOKKEEPER (package/archive integrity; ruling §10 item 9 + provenance)

> Provenance: the agent returned this report as final-message text (the harness blocks
> subagent-written report files); persisted verbatim by the chair (Fable 5), 2026-07-14.
> Agent model: Sonnet. Working artifacts in this directory.
> NOTE: the lane's TAR.GZ sub-check was BLOCKED at report time; the chair subsequently
> received and verified the TAR.GZ twin first-hand — see `../chair/item9-targz-closure.md`,
> which supersedes check 3 below and closes §10 item 9 as PASS.

## LANE VERDICT: BLOCKED (superseded → PASS after chair's item-9 closure)

The package's own contents are fully sound — every checksum, manifest row, zip member, embedded
frozen-dependency packet, and consultation cross-check verifies exactly against freshly
recomputed bytes, zero mismatches anywhere. The block is a missing deliverable, not a discovered
defect.

**Check 0 — outer zip sha256: PASS.** Recomputed
`36cc71ccf3c310a055199c54e84bf436c4505d92a6378f22e8b1d932f02e987d`, matches chair's value exactly.

**Check 1 — per-file sha256 + manifest table + coverage rules: PASS.** All 22 files' recomputed
sha256 match `LCI0-FIXTURE-SHA256SUMS.txt`'s 21 entries exactly (`diff` empty); the file
correctly omits only itself. Manifest's payload table (parsed programmatically) has **20 rows,
not 19 as the brief stated** — flagging this as a brief/reality discrepancy, but internally
consistent (22 total − 2 bookkeeping files = 20; every byte count and sha256 in the table
matches disk, 0 mismatches). Coverage rules hold exactly: manifest excluded from its own table,
checksum file covers the manifest (line 1) and omits only itself, nothing missing or extra.

**Check 2 — ZIP member set: PASS.** `zipinfo -1` → 22 sorted members saved to `zip-members.txt`;
stripped of root prefix, identical to the extracted package tree. Went further than asked: full
`diff -r` of the extracted zip against `package/` is byte-identical across all 22 files.

**Check 3 — TAR.GZ twin (ruling §10 item 9): BLOCKED-ARTIFACT-NOT-DELIVERED.** Searched
`/home/gauss/Codex-Lab` and `/mnt/c/Users/Tomás Pavam/Downloads` myself; no file named
`lci0-errata-0.1-fixture-package-2026-07-14.tar.gz` (or similar) exists anywhere. The only
`lci0`-related `.tar.gz` found is the unrelated frozen-dependency sub-artifact's own tar.gz in
Codex-Lab — not a twin of the outer fixture package. Needed to close: a fixture-package tar.gz
whose 22 member paths match `zip-members-relative-sorted.txt` exactly.
*(Chair's addendum: delivered by the owner at 01:05 local; verified — member sets identical,
all 22 files byte-identical, sha256 `ddc03ba184e835fdbd3c51e9a0f8d3edf4a93deb4d6b980544d82a5c47a83934`.)*

**Check 4 — embedded frozen dependency: PASS.** Embedded zip sha256 =
`bc54a23bbd235fc0ee4d0485c2091585e506dbc7cf74b0e16318580465aa1f81`, matches expected and its own
sidecar. Unzipped: 15 files (14 payload + self-omitted `SHA256SUMS.txt`), internal checksums
match recomputed bytes exactly (diff empty). Bonus: three internal hashes (`d578e86e…` spec,
`5f1568e5…` errata, `1a0e8ff8…` ruling) match the CD/0 anchors already canonized in MEMORY.md —
independent corroboration.

**Check 5 — consultation cross-check: PASS.** Consultation packet zip sha256 =
`e2740dc037837a539e3b1b7d6e07675c139263e2b6f41ee579d85e5efcdbaaf2`, matches expected. Unzipped
and compared by filename+hash: `reviewed-inputs/consultation/{PACKET-MANIFEST.md,SHA256SUMS.txt}`,
all 3 `review/*.md`, all 7 `annexes/*.md`, plus (bonus) `normative-candidate/LOCATED-CLAIM-
IDENTITY-SPEC.md` and the frozen-dependency zip+sidecar — every one byte-identical to the
consultation packet's copy. Structural note (legitimate, not an anomaly): the consultation
packet keeps its manifest/checksums at top level while the fixture package relocates them into
`reviewed-inputs/consultation/`; content matches regardless of path.

**Check 6 — UTF-8/LF encoding claim: PASS.** 20 `.md/.txt/.json/.jsonl` members (the two
`.zip`/`.zip.sha256` frozen-dependency files correctly excluded as binary). `grep -lP '\r'`
found zero CRLF occurrences; Python strict `utf-8` decode succeeded on all 20 files including
the 158MB registry and 26MB vectors file. Bonus: also CRLF-scanned the 28 text files inside the
two embedded/consultation archives — clean.

The package cannot be certified complete against ruling §10 item 9 until a TAR.GZ twin is
produced and its member set verified identical to the ZIP's 22-member set. Everything checkable
without that artifact is clean. *(Closed by the chair, same session — see provenance note.)*
