# LANE REPORT — VECTOR-MARSHAL (typed-vector execution; ruling §10 item 6)

> Provenance: the agent returned this report as final-message text (the harness blocks
> subagent-written report files); persisted verbatim by the chair (Fable 5), 2026-07-14.
> Agent model: Opus. Harness + machine data (`harness.py`, `passB.py`, `results.csv` 215 rows,
> `passA_rows.json`, `passB_results.json`) in this directory.

**Package (immutable):** `_staging/lci0-errata-verify/package/lci0-errata-0.1-fixture-package-2026-07-14/`
**Verifier:** VECTOR-MARSHAL · Claude Opus 4.8 (1M)

## 0. Method & evidence tiers (PLUMB — what each check actually ran)

Each vector's `inputs`/`expected` are self-contained CD/0 documents (`canonical_cd0_hex` +
`abstract_cd0` + byte-count + sha256 + `expected_decoded_abstract_value`); `expected_result =
{machine_value, status}` plus, on failure, `{category, code, stage, path}`. I re-derived from
the package's **closed** tables — never trusting a vector's self-report — on two axes:

- **Pass A — integrity + CD/0 self-consistency (ALL 215, complete).**
- **Pass B — decision re-derivation from the closed normative tables (all families the ruling
  names).** Tiers:
  - **T1-REDERIVED (79):** I independently recomputed the *typed decision* (relation token /
    failure code / status) from a closed rule and it matched exactly.
  - **T2-CONSISTENCY (136):** Pass A fully consistent AND the governing closed rule is present
    and cited, but I did **not** re-encode the full success payload (that needs the whole CD/0
    encoder + LCI projector — the four-instrument stack the manifest itself used). Not
    underdetermined: rule exists, decision determined, octets self-consistent. 84 successes +
    52 failures.
  - **UNDERDETERMINED: 0. MISMATCH: 0.**

Honest scope: T1 is genuine recomputation; T2 is rigorous consistency + closed-rule existence,
not byte-reproduction of success payloads.

## CHECK 1 — Census (PASS)
215 lines, **215 unique** IDs (0 duplicates). `LCI0-P001`–`P030` and `LCI0-N001`–`N032` all
present (0 missing). My vector-class and operation counts reproduce fixture-spec §14
**line-for-line**. Full ID-family classification (all 215 accounted for): P### 30, N### 32,
E1* 10, E2* 4, E3* 7, E4* 5, E5* 2, E6* 2, E7* 31, E8* 3, E9* 15, I12* 3, TARGET-* 22,
SCOPE-* 7, TEMPORAL-* 9, RESOURCE-* 13, LOSS-ACCOUNT-* 14, PLACEMENT-* 4, METADATA-* 2 = **215**.

## CHECK 2 — Execute all 215 (PASS: 215/215; 0 mismatch, 0 underdetermined)
**Pass A (215/215 clean)** — per vector, both sides: octet law (sha256 + byte-count over the
canonical hex), decode identity (`abstract_cd0 == expected_decoded_abstract_value`), embedded
`operation`/`vector-id` self-labels match the vector, `machine_value == expected.abstract_cd0`,
status↔failure coherence with category/code/stage/path cross-checked against the machine_value
failure record, and LCI failure namespace.

**Pass B** — 79 T1 re-derived, 136 T2 consistency, 0 mismatch, 0 underdetermined. Independently
recomputed: scope relations (§2.2 set-semantics, 7/7 match), temporal relations (§3 interval
algebra with endpoint-closure, 9/9 match the actual output token), migration classifications
(§9.3/E9.1 map, 7/7), the 13 §10 budgets + N032 (resource→code), 11 target-NEG
first-field-missing (§7 field order), E2×4, E5×2, E6×2, collision pairs, restoration refusals,
E9 adversaries. **Deterministic failure taxonomy:** 54 codes → exactly 10 disjoint categories
(no code under two categories).

**One documentation note (not a defect):** `LCI0-TEMPORAL-DISJOINT` ([0,50] vs [200,220]) and
`LCI0-TEMPORAL-OVERLAP` ([100,124] vs (100,124]) deterministically emit the *precise*
sub-relations `before`/`contains` — my interval algebra reproduces them exactly. The §3 *prose
witness-table* "Expected" column labels those two rows with the coarser words
`disjoint`/`overlap`. The vectors are correct and fully derivable; only the illustrative §3
prose label is looser than the normative output.

## CHECK 3 — Witnesses (PASS, all six)
- **(a)** 11 target kinds each have POS+NEG (`LCI0-TARGET-01..11-{POS,NEG}`); each NEG
  re-derives to `TargetBoundaryMissing` at its schema field-1.
- **(b)** Both policies hard-reject every F: `LCI0-E2-{COVERAGE,INCOMPATIBLE,NONMONOTONE,UNKNOWN}`
  each carry policy-a AND policy-b = `hard-reject-target-relation` + `policy-not-consulted` (×2);
  plus `LCI0-P016–P020`, `LCI0-P022`.
- **(c)** `LCI0-E5-NONMONOTONE-NARROWING`→`ScopeNarrowingNotDeclared`,
  `LCI0-E5-COVERAGE-INSUFFICIENT`→`ScopeNarrowingCoverageInsufficient`; distinct codes, neither
  collapses to `ClaimTargetMismatch`/`ScopeWideningForbidden`.
- **(d)** `LCI0-E6-MULTIFAULT-CLAIM-SHAPE` (missing `identity-policy` + extra field →
  first-fault `MissingRequiredField@identity-policy`) and `LCI0-E6-MULTIFAULT-TARGET-BOUNDARY`
  (missing field-1 `observer-or-instrument` + unknown `confidence` →
  `TargetBoundaryMissing@observer-or-instrument`); both carry the precedence algorithm inline.
- **(e)** Full E9 set: Unicode-nonnorm, printer-perturbation, hostile read-eval→
  `UnsupportedLegacyForm`, ambiguous as-of→`UnclassifiedAsOf`, near-miss→`AmbiguousIdentifier`,
  semantically-wrong→`SemanticIdentifierMappingMismatch`, **3 collision dimensions**
  P027=subject-time / P028=scope / P029=corpus-revision (same fingerprint →
  `new-claim-ids-equal=false`, distinct ClaimIds), inert predecessor, live-restoration→
  `PrivilegedRestorationAttempt`.
- **(f)** Migration non-evaluating, zero live warrants — every live-* token is a
  `false`/`Seq[]`/`0` assertion; all 3 `restore-live-warrant` vectors refuse.

## CHECK 4 — Failure namespace (PASS)
All 101 failure vectors' category/code/stage in `["lisp-plus","lci","0","failure"]`
(10 lowercase-hyphenated LCI categories). CD/0's seven categories are CamelCase in the
canonical-datum namespace; **no CD/0 category name is reused as an LCI category**. The one
shared spelling, `PrivilegedRestorationAttempt`, is a CD/0 *category* but an LCI *code*
(category `privilege-refusal`), explicitly disclaimed by Errata I12(c). 54 distinct LCI codes.

## LANE VERDICT: **PASS**
- **Check 1 Census:** PASS — 215/215 unique, P/N series complete, §14 counts reproduced.
- **Check 2 Execute:** PASS — Pass A 215/215 consistent; Pass B 79 re-derived + 136
  consistency-verified; **0 mismatch, 0 underdetermined**; deterministic taxonomy. (1 doc-note
  on §3 temporal prose labels; vectors unaffected.)
- **Check 3 Witnesses:** PASS — all six.
- **Check 4 Namespace:** PASS — no CD/0 category-name reuse; I12(c) case handled.
