#!/usr/bin/env python3
"""
RECKONER check 4: vector file line count, JSON validity, ID uniqueness,
ID scheme census, and presence of the 62 core IDs (LCI0-P001..P030,
LCI0-N001..N032).
"""
import json
import re
import sys
from collections import Counter, defaultdict

VEC_PATH = "/home/gauss/Claude-Code-Lab/_staging/lci0-errata-verify/package/lci0-errata-0.1-fixture-package-2026-07-14/LCI0-FIXTURE-VECTORS.jsonl"

# raw line count (including any blank/trailing lines) vs parsed-object count
with open(VEC_PATH, "rb") as f:
    raw_bytes = f.read()

# does the file end with a newline? count lines the "wc -l" way (newline-terminated lines)
newline_count = raw_bytes.count(b"\n")
ends_with_newline = raw_bytes.endswith(b"\n")
print(f"raw newline count = {newline_count}")
print(f"file ends with newline = {ends_with_newline}")

lines = raw_bytes.decode("utf-8").split("\n")
if lines and lines[-1] == "":
    lines = lines[:-1]
print(f"non-trailing-empty line count = {len(lines)}")

parse_errors = []
records = []
for i, line in enumerate(lines, 1):
    if line == "":
        parse_errors.append((i, "blank line"))
        continue
    try:
        obj = json.loads(line)
        records.append((i, obj))
    except json.JSONDecodeError as e:
        parse_errors.append((i, str(e)))

print()
print("=== CHECK 4a: line count and JSON validity ===")
print(f"total lines = {len(lines)}")
print(f"lines == 215 ? {len(lines) == 215}")
print(f"successfully parsed as JSON = {len(records)}")
print(f"parse errors = {len(parse_errors)}")
if parse_errors:
    for ln, err in parse_errors:
        print(f"  line {ln}: {err}")

# ID uniqueness
ids = [obj.get("vector_id") for _, obj in records]
id_counter = Counter(ids)
dupes = {k: v for k, v in id_counter.items() if v > 1}
missing_id = sum(1 for i in ids if i is None)

print()
print("=== CHECK 4b: vector_id uniqueness ===")
print(f"total ids collected = {len(ids)}")
print(f"unique ids = {len(set(ids))}")
print(f"duplicate ids = {dupes}")
print(f"records missing vector_id = {missing_id}")

# ID scheme: prefix pattern
ID_RE = re.compile(r"^(LCI0)-([A-Z]+)(\d+)$")
prefix_counter = Counter()
category_examples = defaultdict(list)
non_matching = []
for vid in ids:
    m = ID_RE.match(vid or "")
    if m:
        prefix = m.group(2)
        prefix_counter[prefix] += 1
        if len(category_examples[prefix]) < 3:
            category_examples[prefix].append(vid)
    else:
        non_matching.append(vid)

print()
print("=== CHECK 4c: ID scheme census (prefix = LCI0-<LETTERS><digits>) ===")
for prefix in sorted(prefix_counter):
    print(f"  {prefix}: {prefix_counter[prefix]}   e.g. {category_examples[prefix]}")
print(f"IDs not matching LCI0-<LETTERS><digits> scheme: {len(non_matching)}")
if non_matching:
    print("  ", non_matching[:20])

total_census = sum(prefix_counter.values()) + len(non_matching)
print(f"sum of census + non-matching = {total_census} (should equal {len(ids)})")

# core 62: P001-P030, N001-N032
core_p = [f"LCI0-P{n:03d}" for n in range(1, 31)]
core_n = [f"LCI0-N{n:03d}" for n in range(1, 33)]
core_all = core_p + core_n
id_set = set(ids)
missing_core = [c for c in core_all if c not in id_set]
present_core = [c for c in core_all if c in id_set]

print()
print("=== CHECK 4d: core 62 presence (LCI0-P001..P030, LCI0-N001..N032) ===")
print(f"core IDs expected = {len(core_all)}")
print(f"core IDs present  = {len(present_core)}")
print(f"core IDs missing  = {len(missing_core)}")
if missing_core:
    print("  MISSING:", missing_core)

non_core_ids = [i for i in ids if i not in set(core_all)]
print()
print(f"non-core (added errata/fixture) vector count = {len(non_core_ids)}")
print(f"core + non-core = {len(present_core) + len(non_core_ids)} (should equal {len(ids)})")

# full alphabetized list of non-core ids grouped
print()
print("=== full non-core ID list, grouped by prefix ===")
by_prefix = defaultdict(list)
for vid in non_core_ids:
    m = ID_RE.match(vid or "")
    prefix = m.group(2) if m else "UNMATCHED"
    by_prefix[prefix].append(vid)
for prefix in sorted(by_prefix):
    lst = sorted(by_prefix[prefix])
    print(f"{prefix} (n={len(lst)}): {lst}")
