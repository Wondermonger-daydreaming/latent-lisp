#!/usr/bin/env python3
"""
RECKONER check 2 + check 3 + check 5 (doc-index.csv).

Enumerates every embedded CD/0 document across:
  - registry "definitions" array (675 claimed)
  - vector "inputs" (aggregate input document, one per vector line)
  - vector "expected" (exact expected document, one per vector line)

This matches LCI0-NORMATIVE-FIXTURE-PACKAGE-SPEC.md §13.2 verbatim:
"All 675 registry definitions plus the aggregate input and expected-output
document for all 215 vectors-1,105 complete documents."

Per-document well-formedness (ruling §10 item 2):
  (a) canonical hex present, strictly lowercase, even length, valid hex
  (b) byte count field == len(hex)/2
  (c) checksum field (sha256_checksum_of_canonical_octets) recomputes
      exactly as sha256(bytes.fromhex(hex))
  (d) decoded abstract value (expected_decoded_abstract_value) present
      and non-empty
  (e) hex begins with document magic 4c504344 + version uvar 00
      (from registry header cd0_dependency.document_magic_hex /
      version_uvar_hex)

Writes doc-index.csv: stable_path_or_id, sha256_of_octets, byte_count, source
"""
import json
import hashlib
import csv
import sys
import re

REG_PATH = "/home/gauss/Claude-Code-Lab/_staging/lci0-errata-verify/package/lci0-errata-0.1-fixture-package-2026-07-14/LCI0-FIXTURE-REGISTRY.json"
VEC_PATH = "/home/gauss/Claude-Code-Lab/_staging/lci0-errata-verify/package/lci0-errata-0.1-fixture-package-2026-07-14/LCI0-FIXTURE-VECTORS.jsonl"
CSV_PATH = "/home/gauss/Claude-Code-Lab/_staging/lci0-errata-verify/scratch/reckoner/doc-index.csv"

HEX_RE = re.compile(r"^[0-9a-f]+$")

registry = json.load(open(REG_PATH, "rb"))
cd0_dep = registry["cd0_dependency"]
MAGIC = cd0_dep["document_magic_hex"]
VERSION_UVAR = cd0_dep["version_uvar_hex"]
REQUIRED_PREFIX = MAGIC + VERSION_UVAR
print(f"document_magic_hex = {MAGIC!r}, version_uvar_hex = {VERSION_UVAR!r}, required prefix = {REQUIRED_PREFIX!r}", file=sys.stderr)

definitions = registry["definitions"]
print(f"registry definitions count = {len(definitions)}", file=sys.stderr)

vectors = []
with open(VEC_PATH, "r", encoding="utf-8") as f:
    for lineno, line in enumerate(f, 1):
        line = line.rstrip("\n")
        if not line:
            continue
        vectors.append((lineno, json.loads(line)))
print(f"vector lines parsed = {len(vectors)}", file=sys.stderr)


def check_document(doc, stable_id, source, failures, csv_rows):
    """doc is the dict carrying canonical_cd0_hex etc. Returns True if fully well-formed."""
    ok = True
    reasons = []

    hex_val = doc.get("canonical_cd0_hex")
    if hex_val is None:
        failures.append((stable_id, source, "MISSING canonical_cd0_hex"))
        return False

    # (a) hex present, strictly lowercase, even length, valid hex
    if hex_val != hex_val.lower():
        reasons.append("hex not strictly lowercase")
        ok = False
    if len(hex_val) % 2 != 0:
        reasons.append(f"hex has odd length {len(hex_val)}")
        ok = False
    if not HEX_RE.match(hex_val):
        reasons.append("hex contains invalid characters")
        ok = False

    if not ok:
        failures.append((stable_id, source, "; ".join(reasons)))
        return False

    octets = bytes.fromhex(hex_val)
    computed_byte_count = len(octets)
    computed_sha256 = hashlib.sha256(octets).hexdigest()

    # (b) byte count field == len(hex)/2
    claimed_byte_count = doc.get("canonical_octets_byte_count")
    if claimed_byte_count != computed_byte_count:
        reasons.append(f"byte_count mismatch: claimed={claimed_byte_count} computed={computed_byte_count}")
        ok = False

    # (c) checksum recomputes exactly
    claimed_checksum = doc.get("sha256_checksum_of_canonical_octets")
    if claimed_checksum != computed_sha256:
        reasons.append(f"checksum mismatch: claimed={claimed_checksum} computed={computed_sha256}")
        ok = False

    # (d) decoded abstract value present, non-empty
    decoded = doc.get("expected_decoded_abstract_value", "__MISSING__")
    if decoded == "__MISSING__" or decoded is None:
        reasons.append("expected_decoded_abstract_value missing/null")
        ok = False
    elif isinstance(decoded, (dict, list, str)) and len(decoded) == 0:
        reasons.append("expected_decoded_abstract_value is empty")
        ok = False

    # (e) hex begins with document magic + version uvar
    if not hex_val.startswith(REQUIRED_PREFIX):
        reasons.append(f"hex does not start with required prefix {REQUIRED_PREFIX!r}; got {hex_val[:len(REQUIRED_PREFIX)]!r}")
        ok = False

    if not ok:
        failures.append((stable_id, source, "; ".join(reasons)))

    csv_rows.append((stable_id, computed_sha256, computed_byte_count, source))
    return ok


failures = []
csv_rows = []
pass_count = 0

# 1. registry definitions
seen_fixture_ids = set()
for d in definitions:
    fid = d.get("fixture_id", "<NO-FIXTURE-ID>")
    if fid in seen_fixture_ids:
        failures.append((fid, "registry", "DUPLICATE fixture_id"))
    seen_fixture_ids.add(fid)
    stable_id = f"registry:{fid}"
    if check_document(d, stable_id, "registry", failures, csv_rows):
        pass_count += 1

registry_doc_count = len(definitions)

# 2. vector inputs + expected
seen_vector_ids = set()
for lineno, v in vectors:
    vid = v.get("vector_id", f"<NO-VECTOR-ID line {lineno}>")
    if vid in seen_vector_ids:
        failures.append((vid, "vector", f"DUPLICATE vector_id (line {lineno})"))
    seen_vector_ids.add(vid)

    inp = v.get("inputs")
    if inp is None:
        failures.append((f"{vid}:input", "vector-input", "MISSING inputs document"))
    else:
        stable_id = f"{vid}:input"
        if check_document(inp, stable_id, "vector-input", failures, csv_rows):
            pass_count += 1

    exp = v.get("expected")
    if exp is None:
        failures.append((f"{vid}:expected", "vector-expected", "MISSING expected document"))
    else:
        stable_id = f"{vid}:expected"
        if check_document(exp, stable_id, "vector-expected", failures, csv_rows):
            pass_count += 1

vector_doc_count = len(vectors) * 2

total_docs_enumerated = registry_doc_count + vector_doc_count

print()
print("=== CHECK 2: document enumeration ===")
print(f"registry docs (definitions[]) = {registry_doc_count}")
print(f"vector docs (215 * 2 = inputs+expected) = {vector_doc_count}")
print(f"  vector input docs = {len(vectors)}")
print(f"  vector expected docs = {len(vectors)}")
print(f"TOTAL documents enumerated = {total_docs_enumerated}")
print(f"TOTAL == 1105 ? {total_docs_enumerated == 1105}")

print()
print("=== CHECK 3: well-formedness ===")
print(f"documents checked = {total_docs_enumerated}")
print(f"documents PASS = {pass_count}")
print(f"documents FAIL = {len(failures)}")
if failures:
    print("FAILURES:")
    for fid, source, reason in failures:
        print(f"  [{source}] {fid}: {reason}")
else:
    print("FAILURES: NONE")

# write CSV
csv_rows.sort(key=lambda r: (r[3], r[0]))
with open(CSV_PATH, "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["stable_path_or_id", "sha256_of_octets", "byte_count", "source"])
    for row in csv_rows:
        w.writerow(row)

print()
print(f"doc-index.csv written: {CSV_PATH}, rows = {len(csv_rows)}")

# sanity: max byte count among the 1105 (context for reviewer)
max_row = max(csv_rows, key=lambda r: r[2])
print(f"largest document among the 1105: {max_row[0]} ({max_row[3]}), {max_row[2]} bytes")
