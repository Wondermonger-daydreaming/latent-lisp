#!/usr/bin/env python3
"""
RECKONER check 1: load the registry, report top-level structure and
collection counts. Also sanity-checks that 'definitions' is the only
array of CD/0 documents at top level (closed_schemas / normative_algorithms
/ relation_and_mapping_tables are schema-metadata, not document carriers).
"""
import json
import sys
import time
from collections import Counter

REG_PATH = "/home/gauss/Claude-Code-Lab/_staging/lci0-errata-verify/package/lci0-errata-0.1-fixture-package-2026-07-14/LCI0-FIXTURE-REGISTRY.json"

t0 = time.time()
with open(REG_PATH, "rb") as f:
    registry = json.load(f)
t1 = time.time()
print(f"load time: {t1-t0:.2f}s", file=sys.stderr)

print("=== top-level keys ===")
for k in registry.keys():
    v = registry[k]
    if isinstance(v, list):
        print(f"{k}: list, len={len(v)}")
    elif isinstance(v, dict):
        print(f"{k}: dict, keys={len(v)}")
    else:
        print(f"{k}: {type(v).__name__} = {v!r}")

definitions = registry["definitions"]
print()
print("=== definitions array ===")
print("len(definitions) =", len(definitions))

# fixture_id uniqueness
fixture_ids = [d["fixture_id"] for d in definitions]
print("unique fixture_id count =", len(set(fixture_ids)))
dupes = [fid for fid, c in Counter(fixture_ids).items() if c > 1]
print("duplicate fixture_ids:", dupes)

# item_class counts
item_class_counts = Counter(d["item_class"] for d in definitions)
print()
print("=== item_class counts (recomputed from definitions[]) ===")
total = 0
for k in sorted(item_class_counts):
    print(f"{k}: {item_class_counts[k]}")
    total += item_class_counts[k]
print("SUM of item_class counts =", total)

print()
print("=== other top-level dict sizes (non-document metadata, for context) ===")
print("closed_schemas keys:", len(registry.get("closed_schemas", {})))
print("normative_algorithms keys:", len(registry.get("normative_algorithms", {})))
print("relation_and_mapping_tables keys:", len(registry.get("relation_and_mapping_tables", {})))
print("cd0_dependency:", registry.get("cd0_dependency"))
print("fixture_namespace:", registry.get("fixture_namespace"))
print("fixture_package_version:", registry.get("fixture_package_version"))
print("artifact:", registry.get("artifact"))
print("artifact_schema_version:", registry.get("artifact_schema_version"))

# check none of the metadata dicts contain canonical_cd0_hex documents themselves
def scan_for_doc_fields(obj, path=""):
    hits = []
    if isinstance(obj, dict):
        if "canonical_cd0_hex" in obj:
            hits.append(path)
        for k, v in obj.items():
            hits.extend(scan_for_doc_fields(v, path + "/" + k))
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            hits.extend(scan_for_doc_fields(v, path + f"[{i}]"))
    return hits

print()
print("=== scanning closed_schemas/normative_algorithms/relation_and_mapping_tables for embedded canonical_cd0_hex documents ===")
for topkey in ["closed_schemas", "normative_algorithms", "relation_and_mapping_tables"]:
    hits = scan_for_doc_fields(registry.get(topkey, {}), topkey)
    print(f"{topkey}: {len(hits)} embedded documents found")
    if hits[:5]:
        print("  sample:", hits[:5])

print()
print("DONE")
