#!/usr/bin/env python3
"""
RELIQUARY check 3: full recursive sweep of LCI0-FIXTURE-VECTORS.jsonl.

RECKONER's coverage of this file assumed exactly two embedded CD/0
documents per line: obj["inputs"] and obj["expected"] (215*2 = 430,
matching spec section 13.2's count together with the 675 registry
definitions = 1105). This check does NOT take that assumption on faith:
it walks the FULL parsed JSON object of every one of the 215 lines,
looking for:

  (A) any dict key containing "hex" (case-insensitive), anywhere in the
      object tree (not just top-level inputs/expected).
  (B) any STRING value anywhere in the tree that starts with the CD/0
      document magic prefix "4c504344", regardless of key name.

RESULT (first pass, kept as evidence): this DOES turn up 30 extra
magic-prefixed nodes beyond the 430 official inputs/expected documents,
all inside the 10 "LCI0-E1-*" vectors (errata-witness class E1). Each
of those 10 vectors carries, 3 times over (once in expected.abstract_cd0,
once in expected.expected_decoded_abstract_value, once in
expected_result.machine_value), a leaf node of the shape
{"hex": "<...>", "t": "bytes"} whose hex payload independently begins
with the CD/0 magic+version prefix -- i.e. a CD/0 document embedded
BYTE-FOR-BYTE as an opaque "bytes"-typed leaf value inside the abstract
syntax tree of a claim (E1 is exactly the vector class exercising
nested/embedded stable-reference material). This node shape carries only
{"hex", "t"} -- no canonical_octets_byte_count / sha256_checksum_of_
canonical_octets / expected_decoded_abstract_value companion fields, so
checks (c)/(d)/(e) are "not present" (not applicable) for these nodes
per the task's own "if present" / "if the node claims one" wording --
NOT a failure. What IS checked: (a) valid hex, (b) magic+version prefix,
plus a bonus check the task didn't ask for but the finding demands:
byte-identity of the embedded document across all 3 places it recurs
per vector (an internal-consistency guarantee the fixture is implicitly
making).

Writes: appends all 30 extra nodes to extra-doc-index.csv (json_path,
sha256_of_octets, byte_count), after check 2's 458 rows.
"""
import json
import re
import hashlib
import csv
import sys
from collections import Counter

VEC_PATH = "/home/gauss/Claude-Code-Lab/_staging/lci0-errata-verify/package/lci0-errata-0.1-fixture-package-2026-07-14/LCI0-FIXTURE-VECTORS.jsonl"
REG_PATH = "/home/gauss/Claude-Code-Lab/_staging/lci0-errata-verify/package/lci0-errata-0.1-fixture-package-2026-07-14/LCI0-FIXTURE-REGISTRY.json"
CSV_PATH = "/home/gauss/Claude-Code-Lab/_staging/lci0-errata-verify/scratch/reliquary/extra-doc-index.csv"

MAGIC_PREFIX_LOWER = "4c504344"
HEX_RE = re.compile(r"^[0-9a-f]+$")

registry = json.load(open(REG_PATH, "rb"))
cd0_dep = registry["cd0_dependency"]
MAGIC = cd0_dep["document_magic_hex"]
VERSION_UVAR = cd0_dep["version_uvar_hex"]
REQUIRED_PREFIX = MAGIC + VERSION_UVAR

hex_key_hits = []      # (lineno, vector_id, path, key)
magic_value_hits = []  # (lineno, vector_id, path, key, value_len)
# document_nodes keyed by (lineno, path); value = (vector_id, key_name_used, hex_value, full_node_dict)
document_nodes = {}


def walk(obj, path, lineno, vector_id):
    if isinstance(obj, dict):
        local_hex_keys = []
        for k, v in obj.items():
            newpath = f"{path}/{k}"
            if "hex" in k.lower():
                hex_key_hits.append((lineno, vector_id, newpath, k))
                if isinstance(v, str):
                    local_hex_keys.append((k, v))
            if isinstance(v, str) and v[:8].lower() == MAGIC_PREFIX_LOWER:
                magic_value_hits.append((lineno, vector_id, newpath, k, len(v)))
            walk(v, newpath, lineno, vector_id)
        for k, v in local_hex_keys:
            if v[:10].lower() == (MAGIC_PREFIX_LOWER + "00"):
                document_nodes[(lineno, path)] = (vector_id, k, v, obj)
                break
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            walk(v, f"{path}[{i}]", lineno, vector_id)


vectors = []
with open(VEC_PATH, "r", encoding="utf-8") as f:
    for lineno, line in enumerate(f, 1):
        line = line.rstrip("\n")
        if not line:
            continue
        obj = json.loads(line)
        vectors.append((lineno, obj))

print(f"vector lines parsed = {len(vectors)}", file=sys.stderr)

for lineno, obj in vectors:
    vid = obj.get("vector_id", f"<NO-VECTOR-ID line {lineno}>")
    walk(obj, "", lineno, vid)

print()
print("=== FULL SWEEP (vectors): hex-named-key hits (any key containing 'hex'), whole-line tree ===")
print(f"total hex-key hits = {len(hex_key_hits)}")
top_seg_counts = Counter(p.lstrip("/").split("/")[0] for _, _, p, _ in hex_key_hits)
for seg, c in sorted(top_seg_counts.items()):
    print(f"  top-level field {seg!r}: {c}")
keyname_counts = Counter(k for _, _, _, k in hex_key_hits)
print("distinct hex-ish key names:")
for k, c in sorted(keyname_counts.items()):
    print(f"  {k!r}: {c}")

print()
print("=== FULL SWEEP (vectors): magic-prefix VALUE hits (string starts with 4c504344, any key name) ===")
print(f"total magic-value hits = {len(magic_value_hits)}")
top_seg_counts2 = Counter(p.lstrip("/").split("/")[0] for _, _, p, _, _ in magic_value_hits)
for seg, c in sorted(top_seg_counts2.items()):
    print(f"  top-level field {seg!r}: {c}")
keyname_counts2 = Counter(k for _, _, _, k, _ in magic_value_hits)
print("distinct key names carrying magic-prefixed strings:")
for k, c in sorted(keyname_counts2.items()):
    print(f"  {k!r}: {c}")

print()
print("=== FULL SWEEP (vectors): document-shaped dict nodes (any *hex* key, magic+version-valid value) ===")
print(f"total document nodes found = {len(document_nodes)}")
doc_top_counts = Counter(path.lstrip("/").split("/")[0] for (lineno, path) in document_nodes)
for seg, c in sorted(doc_top_counts.items()):
    print(f"  top-level field {seg!r}: {c}")

# "official" nodes are the top-level /inputs and /expected docs (path == "/inputs" or "/expected" exactly)
official_paths = {"/inputs", "/expected"}
inside_nodes = {k: v for k, v in document_nodes.items() if k[1] in official_paths}
outside_nodes = {k: v for k, v in document_nodes.items() if k[1] not in official_paths}

print()
print(f"document nodes at path in {{'/inputs','/expected'}} (officially counted, RECKONER-verified) = {len(inside_nodes)}")
print(f"document nodes OUTSIDE {{'/inputs','/expected'}} (NOT covered by the 215+215 count) = {len(outside_nodes)}")
print(f"  (sanity: 215 lines * 2 official docs = {215*2}; inside_nodes should equal that)")
print(f"  inside_nodes == 430 ? {len(inside_nodes) == 430}")

extra_rows = []
failures = []
pass_count = 0

if outside_nodes:
    print()
    print("=== outside-nodes: per-node breakdown by vector_id and json-path shape ===")
    by_vid = Counter(vid for (vid, k, v, node) in outside_nodes.values())
    for vid, c in sorted(by_vid.items()):
        print(f"  {vid}: {c} nested embedded-document node(s)")

    print()
    print("=== outside-nodes: verifying with a schema-agnostic check (uses the ACTUAL hex-field key name found, not a hardcoded 'canonical_cd0_hex') ===")
    print("checks applied: (a) valid hex (lowercase, even-length, hex-chars only); (b) magic+version prefix;")
    print("(c)/(d) byte_count/checksum companion fields checked ONLY IF PRESENT on the node (task's own 'if present' clause);")
    print("(e) decoded/abstract value checked ONLY IF THE NODE CLAIMS ONE (task's own 'if the node claims one' clause).")

    # group nested nodes by vector_id to also run the bonus cross-occurrence
    # byte-identity check the finding demands
    per_vid_shas = {}

    for (lineno, path), (vid, key_name, hex_val, node) in sorted(outside_nodes.items()):
        json_path = f"vectors.jsonl:line{lineno}:{vid}:{path}"
        ok = True
        reasons = []

        # (a)
        if hex_val != hex_val.lower():
            reasons.append("hex not strictly lowercase"); ok = False
        if len(hex_val) % 2 != 0:
            reasons.append(f"hex has odd length {len(hex_val)}"); ok = False
        if not HEX_RE.match(hex_val):
            reasons.append("hex contains invalid characters"); ok = False

        if not ok:
            failures.append((json_path, "; ".join(reasons)))
            continue

        octets = bytes.fromhex(hex_val)
        computed_byte_count = len(octets)
        computed_sha256 = hashlib.sha256(octets).hexdigest()

        # (b)
        if not hex_val.startswith(REQUIRED_PREFIX):
            reasons.append(f"magic+version prefix mismatch; got {hex_val[:len(REQUIRED_PREFIX)]!r}")
            ok = False

        # (c) byte_count field, if present
        if "canonical_octets_byte_count" in node:
            claimed_bc = node["canonical_octets_byte_count"]
            if claimed_bc != computed_byte_count:
                reasons.append(f"byte_count mismatch: claimed={claimed_bc} computed={computed_byte_count}")
                ok = False

        # (d) checksum field, if present
        if "sha256_checksum_of_canonical_octets" in node:
            claimed_sum = node["sha256_checksum_of_canonical_octets"]
            if claimed_sum != computed_sha256:
                reasons.append(f"checksum mismatch: claimed={claimed_sum} computed={computed_sha256}")
                ok = False

        # (e) decoded/abstract value, only if the node claims one
        if "expected_decoded_abstract_value" in node:
            decoded = node["expected_decoded_abstract_value"]
            if decoded is None or (isinstance(decoded, (dict, list, str)) and len(decoded) == 0):
                reasons.append("expected_decoded_abstract_value present but empty/null")
                ok = False

        if not ok:
            failures.append((json_path, "; ".join(reasons)))
        else:
            pass_count += 1
            extra_rows.append((json_path, computed_sha256, computed_byte_count))

        per_vid_shas.setdefault(vid, []).append(computed_sha256)

    print()
    print(f"outside documents checked = {len(outside_nodes)}")
    print(f"outside documents PASS = {pass_count}")
    print(f"outside documents FAIL = {len(failures)}")
    if failures:
        for p, r in failures:
            print(f"  {p}: {r}")
    else:
        print("FAILURES: NONE")

    print()
    print("=== BONUS check: byte-identity of the embedded document across all its occurrences within one vector ===")
    print("(not requested by the task's checklist, but a natural integrity guarantee this finding implies:")
    print(" the same embedded document should appear byte-identical in abstract_cd0, expected_decoded_abstract_value,")
    print(" and expected_result.machine_value -- otherwise the fixture would be internally inconsistent)")
    identity_fail = 0
    for vid, shas in sorted(per_vid_shas.items()):
        distinct = set(shas)
        status = "OK (all identical)" if len(distinct) == 1 else "MISMATCH"
        if len(distinct) != 1:
            identity_fail += 1
        print(f"  {vid}: {len(shas)} occurrence(s), {len(distinct)} distinct sha256 -> {status}")
    print(f"cross-occurrence identity FAILURES = {identity_fail}")

    # append to extra-doc-index.csv (created by check 2)
    with open(CSV_PATH, "a", newline="") as f:
        w = csv.writer(f)
        for row in sorted(extra_rows):
            w.writerow(row)
    print()
    print(f"appended {len(extra_rows)} rows to {CSV_PATH}")
else:
    print()
    print("NO extra embedded documents found in LCI0-FIXTURE-VECTORS.jsonl beyond the")
    print("215 'inputs' + 215 'expected' aggregate documents RECKONER already verified.")

print()
print("DONE")
