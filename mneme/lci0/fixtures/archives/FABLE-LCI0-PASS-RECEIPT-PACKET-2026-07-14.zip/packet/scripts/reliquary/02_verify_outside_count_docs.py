#!/usr/bin/env python3
"""
RELIQUARY check 2: verify the 458 CD/0 documents found by the full sweep
(check 1) that live OUTSIDE spec §13.2's "1,105 documents" count —
i.e. the entries[] of relation_and_mapping_tables/scope_relation_table_0
(169) and relation_and_mapping_tables/temporal_relation_table_0 (289).

Applies the SAME five checks RECKONER's 02_enumerate_and_verify_documents.py
applied to the officially-counted 1,105:
  (a) canonical hex present, strictly lowercase, even length, valid hex
  (b) byte count field == len(hex)/2   [canonical_octets_byte_count]
  (c) checksum field recomputes exactly as sha256(bytes.fromhex(hex))
      [sha256_checksum_of_canonical_octets]
  (d) decoded abstract value present and non-empty
      [expected_decoded_abstract_value]
  (e) hex begins with document magic + version uvar (4c504344 + 00)

Writes extra-doc-index.csv: json_path, sha256_of_octets, byte_count
for every one of the 458 documents (all of them are outside the 1,105,
by construction of check 1).
"""
import json
import hashlib
import csv
import re
import sys

REG_PATH = "/home/gauss/Claude-Code-Lab/_staging/lci0-errata-verify/package/lci0-errata-0.1-fixture-package-2026-07-14/LCI0-FIXTURE-REGISTRY.json"
CSV_PATH = "/home/gauss/Claude-Code-Lab/_staging/lci0-errata-verify/scratch/reliquary/extra-doc-index.csv"

HEX_RE = re.compile(r"^[0-9a-f]+$")

registry = json.load(open(REG_PATH, "rb"))
cd0_dep = registry["cd0_dependency"]
MAGIC = cd0_dep["document_magic_hex"]
VERSION_UVAR = cd0_dep["version_uvar_hex"]
REQUIRED_PREFIX = MAGIC + VERSION_UVAR
print(f"document_magic_hex = {MAGIC!r}, version_uvar_hex = {VERSION_UVAR!r}, required prefix = {REQUIRED_PREFIX!r}", file=sys.stderr)

rmt = registry["relation_and_mapping_tables"]


def check_document(doc, json_path, failures, csv_rows):
    """Identical logic to RECKONER's check_document, applied to a
    relation_and_mapping_tables entry. Returns True if fully well-formed."""
    ok = True
    reasons = []

    hex_val = doc.get("canonical_cd0_hex")
    if hex_val is None:
        failures.append((json_path, "MISSING canonical_cd0_hex"))
        return False

    # (a) hex present, strictly lowercase, even length, valid hex
    if hex_val != hex_val.lower():
        reasons.append("hex not strictly lowercase")
        ok = False
    if len(hex_val) % 2 != 0:
        reasons.append(f"hex has odd length {len(hex_val)}")
        ok = False
    if not HEX_RE.match(hex_val):
        reasons.append("hex contains invalid characters")
        ok = False

    if not ok:
        failures.append((json_path, "; ".join(reasons)))
        return False

    octets = bytes.fromhex(hex_val)
    computed_byte_count = len(octets)
    computed_sha256 = hashlib.sha256(octets).hexdigest()

    # (b) byte count field == len(hex)/2
    claimed_byte_count = doc.get("canonical_octets_byte_count")
    if claimed_byte_count != computed_byte_count:
        reasons.append(f"byte_count mismatch: claimed={claimed_byte_count} computed={computed_byte_count}")
        ok = False

    # (c) checksum recomputes exactly
    claimed_checksum = doc.get("sha256_checksum_of_canonical_octets")
    if claimed_checksum != computed_sha256:
        reasons.append(f"checksum mismatch: claimed={claimed_checksum} computed={computed_sha256}")
        ok = False

    # (d) decoded abstract value present, non-empty
    decoded = doc.get("expected_decoded_abstract_value", "__MISSING__")
    if decoded == "__MISSING__" or decoded is None:
        reasons.append("expected_decoded_abstract_value missing/null")
        ok = False
    elif isinstance(decoded, (dict, list, str)) and len(decoded) == 0:
        reasons.append("expected_decoded_abstract_value is empty")
        ok = False

    # (e) hex begins with document magic + version uvar
    if not hex_val.startswith(REQUIRED_PREFIX):
        reasons.append(f"hex does not start with required prefix {REQUIRED_PREFIX!r}; got {hex_val[:len(REQUIRED_PREFIX)]!r}")
        ok = False

    if not ok:
        failures.append((json_path, "; ".join(reasons)))

    csv_rows.append((json_path, computed_sha256, computed_byte_count))
    return ok


failures = []
csv_rows = []
pass_count = 0
total_checked = 0

table_counts = {}

for table_name in ["scope_relation_table_0", "temporal_relation_table_0"]:
    entries = rmt[table_name]["entries"]
    table_counts[table_name] = len(entries)
    for i, e in enumerate(entries):
        json_path = f"relation_and_mapping_tables/{table_name}/entries[{i}]"
        total_checked += 1
        if check_document(e, json_path, failures, csv_rows):
            pass_count += 1

print()
print("=== CHECK 2: outside-the-count document enumeration ===")
for t, c in table_counts.items():
    print(f"{t}: {c} entries")
print(f"TOTAL outside-the-count documents enumerated = {total_checked}")
print(f"TOTAL == 458 ? {total_checked == 458}")

print()
print("=== CHECK 2: well-formedness (checks a-e) ===")
print(f"documents checked = {total_checked}")
print(f"documents PASS = {pass_count}")
print(f"documents FAIL = {len(failures)}")
if failures:
    print("FAILURES:")
    for json_path, reason in failures:
        print(f"  {json_path}: {reason}")
else:
    print("FAILURES: NONE")

# per-check breakdown (re-derive individually for a clean per-check integer report)
check_a_fail = 0
check_b_fail = 0
check_c_fail = 0
check_d_fail = 0
check_e_fail = 0
for table_name in ["scope_relation_table_0", "temporal_relation_table_0"]:
    for e in rmt[table_name]["entries"]:
        hex_val = e.get("canonical_cd0_hex", "")
        a_ok = (hex_val == hex_val.lower()) and (len(hex_val) % 2 == 0) and bool(HEX_RE.match(hex_val))
        if not a_ok:
            check_a_fail += 1
            continue  # can't compute b/c meaningfully without valid hex
        octets = bytes.fromhex(hex_val)
        if e.get("canonical_octets_byte_count") != len(octets):
            check_b_fail += 1
        if e.get("sha256_checksum_of_canonical_octets") != hashlib.sha256(octets).hexdigest():
            check_c_fail += 1
        decoded = e.get("expected_decoded_abstract_value", "__MISSING__")
        if decoded == "__MISSING__" or decoded is None or (isinstance(decoded, (dict, list, str)) and len(decoded) == 0):
            check_d_fail += 1
        if not hex_val.startswith(REQUIRED_PREFIX):
            check_e_fail += 1

print()
print("=== per-check failure counts (of 458) ===")
print(f"(a) lowercase/even-length/valid-hex FAIL count = {check_a_fail}")
print(f"(b) byte_count field mismatch FAIL count        = {check_b_fail}")
print(f"(c) checksum recompute mismatch FAIL count       = {check_c_fail}")
print(f"(d) decoded/abstract value missing FAIL count    = {check_d_fail}")
print(f"(e) magic+version prefix mismatch FAIL count     = {check_e_fail}")

# additionally verify abstract_cd0 (the "as authored" companion of
# expected_decoded_abstract_value) is also present and non-empty on every
# entry, since these tables carry BOTH fields (unlike some vector docs)
abstract_cd0_missing = 0
for table_name in ["scope_relation_table_0", "temporal_relation_table_0"]:
    for e in rmt[table_name]["entries"]:
        v = e.get("abstract_cd0", "__MISSING__")
        if v == "__MISSING__" or v is None or (isinstance(v, (dict, list, str)) and len(v) == 0):
            abstract_cd0_missing += 1
print(f"(bonus) abstract_cd0 missing/empty count          = {abstract_cd0_missing}")

# left_fixture / right_fixture referential sanity: do they point at real
# fixture_ids in registry['definitions']?
definitions = registry["definitions"]
def_ids = set(d["fixture_id"] for d in definitions)
dangling_refs = []
for table_name in ["scope_relation_table_0", "temporal_relation_table_0"]:
    for i, e in enumerate(rmt[table_name]["entries"]):
        for side in ("left_fixture", "right_fixture"):
            ref = e.get(side)
            if ref not in def_ids:
                dangling_refs.append((f"relation_and_mapping_tables/{table_name}/entries[{i}]/{side}", ref))
print()
print(f"=== referential check: left_fixture/right_fixture resolve to a real registry definitions[].fixture_id ===")
print(f"dangling references = {len(dangling_refs)}")
if dangling_refs:
    for p, ref in dangling_refs[:20]:
        print(f"  {p}: {ref!r} NOT FOUND in definitions[].fixture_id")

# write CSV
csv_rows.sort(key=lambda r: r[0])
with open(CSV_PATH, "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["json_path", "sha256_of_octets", "byte_count"])
    for row in csv_rows:
        w.writerow(row)

print()
print(f"extra-doc-index.csv written: {CSV_PATH}, rows = {len(csv_rows)}")

if csv_rows:
    max_row = max(csv_rows, key=lambda r: r[2])
    min_row = min(csv_rows, key=lambda r: r[2])
    print(f"largest document among the 458: {max_row[0]}, {max_row[2]} bytes")
    print(f"smallest document among the 458: {min_row[0]}, {min_row[2]} bytes")

print()
print("DONE")
