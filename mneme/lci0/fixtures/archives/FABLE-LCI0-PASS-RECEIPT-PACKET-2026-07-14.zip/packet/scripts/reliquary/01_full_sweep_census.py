#!/usr/bin/env python3
"""
RELIQUARY check 1: FULL recursive sweep of LCI0-FIXTURE-REGISTRY.json.

Unlike RECKONER's scan (which looked only for the exact key name
"canonical_cd0_hex"), this sweep is deliberately paranoid:

  (A) collect every dict-key hit whose key name contains "hex" (case-
      insensitive), anywhere in the whole tree — not just the three
      "metadata" top-level keys RECKONER spot-checked. This re-derives
      RECKONER's 458 findings from scratch as a cross-check, AND would
      catch any differently-named hex field RECKONER's narrower
      "canonical_cd0_hex"-only scan could have missed.
  (B) independently, collect every STRING value anywhere in the tree
      (regardless of what key it hangs off) whose value starts with the
      CD/0 document magic prefix "4c504344" (case-insensitive on the hex
      digits). This catches a document hiding under an unexpected key
      name entirely (e.g. "value", "cd0", "octets_hex", etc.) that a
      key-name-based scan would miss.

Also records, for every dict node that looks like a full CD/0 document
carrier (has canonical_cd0_hex sibling fields), which of the companion
fields are present, so check 2 knows exactly what to verify.

Writes:
  - full-sweep-hex-key-hits.json   (path -> key for every "*hex*" key)
  - full-sweep-magic-value-hits.json (path -> key for every string
    starting with the magic prefix)
  - full-sweep-document-nodes.json  (path -> full dict, for every dict
    node bearing a canonical_cd0_hex-shaped field, wherever located)
  - census-summary.txt (human-readable census table)
"""
import json
import re
import sys
import time
from collections import defaultdict, Counter

REG_PATH = "/home/gauss/Claude-Code-Lab/_staging/lci0-errata-verify/package/lci0-errata-0.1-fixture-package-2026-07-14/LCI0-FIXTURE-REGISTRY.json"
OUTDIR = "/home/gauss/Claude-Code-Lab/_staging/lci0-errata-verify/scratch/reliquary"

MAGIC_PREFIX_LOWER = "4c504344"  # document_magic_hex, confirmed from registry cd0_dependency

t0 = time.time()
with open(REG_PATH, "rb") as f:
    registry = json.load(f)
t1 = time.time()
print(f"load time: {t1-t0:.2f}s", file=sys.stderr)

hex_key_hits = []       # (path, key)
magic_value_hits = []   # (path, key, value_len)
document_nodes = {}     # path -> dict (dict nodes that carry a *hex key AND look like documents)

# location-path top-level bucket for the census (first path segment, with
# any trailing [N] array index stripped so definitions[0], definitions[1],
# ... all collapse into the single bucket "definitions")
INDEX_STRIP_RE = re.compile(r"\[\d+\]$")
def top_bucket(path):
    # path looks like "/definitions[3]/foo" or "/relation_and_mapping_tables/..."
    parts = path.lstrip("/").split("/")
    first = parts[0] if parts else "<root>"
    return INDEX_STRIP_RE.sub("", first)

def walk(obj, path):
    if isinstance(obj, dict):
        local_hex_keys = []
        for k, v in obj.items():
            newpath = f"{path}/{k}"
            if "hex" in k.lower():
                hex_key_hits.append((newpath, k))
                if isinstance(v, str):
                    local_hex_keys.append((k, v))
            if isinstance(v, str):
                # magic-value scan: check prefix regardless of key name
                if v[:8].lower() == MAGIC_PREFIX_LOWER:
                    magic_value_hits.append((newpath, k, len(v)))
            walk(v, newpath)
        # if this dict node itself carries a hex field that starts with
        # the magic prefix, treat it as a "document node" and stash it
        # whole for check 2 (dedup safety: keyed by path, always unique)
        for k, v in local_hex_keys:
            if v[:10].lower() == (MAGIC_PREFIX_LOWER + "00"):
                document_nodes[path] = obj
                break
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            walk(v, f"{path}[{i}]")

walk(registry, "")

print(f"walk time: {time.time()-t1:.2f}s", file=sys.stderr)

# ============ CENSUS ============
print("=== FULL SWEEP: hex-named-key hits (any key containing 'hex') ===")
print(f"total hex-key hits = {len(hex_key_hits)}")
bucket_counts = Counter(top_bucket(p) for p, k in hex_key_hits)
for b in sorted(bucket_counts):
    print(f"  {b}: {bucket_counts[b]}")

# distinct key names seen
keynames = Counter(k for p, k in hex_key_hits)
print()
print("distinct hex-ish key names seen and counts:")
for k, c in sorted(keynames.items()):
    print(f"  {k!r}: {c}")

print()
print("=== FULL SWEEP: magic-prefix VALUE hits (string starts with 4c504344, any key name) ===")
print(f"total magic-value hits = {len(magic_value_hits)}")
bucket_counts2 = Counter(top_bucket(p) for p, k, l in magic_value_hits)
for b in sorted(bucket_counts2):
    print(f"  {b}: {bucket_counts2[b]}")
keynames2 = Counter(k for p, k, l in magic_value_hits)
print()
print("distinct key names carrying magic-prefixed strings:")
for k, c in sorted(keynames2.items()):
    print(f"  {k!r}: {c}")

print()
print("=== FULL SWEEP: document-shaped dict nodes (canonical_cd0_hex-bearing dicts with valid magic+version prefix) ===")
print(f"total document nodes found = {len(document_nodes)}")
doc_bucket_counts = Counter(top_bucket(p) for p in document_nodes)
for b in sorted(doc_bucket_counts):
    print(f"  {b}: {doc_bucket_counts[b]}")

# finer-grained breakdown within relation_and_mapping_tables
rmt_paths = [p for p in document_nodes if top_bucket(p) == "relation_and_mapping_tables"]
rmt_subbucket = Counter()
for p in rmt_paths:
    parts = p.lstrip("/").split("/")
    # e.g. relation_and_mapping_tables/scope_relation_table_0/entries[3]
    sub = parts[1] if len(parts) > 1 else "<direct>"
    rmt_subbucket[sub] += 1
print()
print("relation_and_mapping_tables sub-buckets:")
for sub, c in sorted(rmt_subbucket.items()):
    print(f"  {sub}: {c}")

# how many document nodes are OUTSIDE the already-verified 675 'definitions'?
definitions_paths = set(p for p in document_nodes if top_bucket(p) == "definitions")
outside_paths = set(document_nodes.keys()) - definitions_paths
print()
print(f"document nodes INSIDE definitions[] (already RECKONER-verified) = {len(definitions_paths)}")
print(f"document nodes OUTSIDE definitions[] (NOT covered by the 675 count) = {len(outside_paths)}")

# sanity: definitions[] should be exactly 675
print(f"  (sanity: len(registry['definitions']) = {len(registry['definitions'])})")

# write outputs
with open(f"{OUTDIR}/full-sweep-hex-key-hits.json", "w") as f:
    json.dump([{"path": p, "key": k} for p, k in hex_key_hits], f, indent=1)

with open(f"{OUTDIR}/full-sweep-magic-value-hits.json", "w") as f:
    json.dump([{"path": p, "key": k, "value_len": l} for p, k, l in magic_value_hits], f, indent=1)

# document_nodes values are large (contain the full hex blob); write paths +
# byte-length only for the summary artifact, full nodes handled in-memory by
# check 2 script (re-walked there) to avoid double-writing 458 large hex blobs.
with open(f"{OUTDIR}/full-sweep-document-node-paths.json", "w") as f:
    json.dump(sorted(document_nodes.keys()), f, indent=1)

with open(f"{OUTDIR}/full-sweep-outside-count-paths.json", "w") as f:
    json.dump(sorted(outside_paths), f, indent=1)

print()
print("DONE")
print(f"wrote: {OUTDIR}/full-sweep-hex-key-hits.json")
print(f"wrote: {OUTDIR}/full-sweep-magic-value-hits.json")
print(f"wrote: {OUTDIR}/full-sweep-document-node-paths.json")
print(f"wrote: {OUTDIR}/full-sweep-outside-count-paths.json")
