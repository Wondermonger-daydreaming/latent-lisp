#!/usr/bin/env python3
"""CODA LEG D — frozen Python CD/0 codec over the 458 relation/mapping-table
documents RELIQUARY found that no codec had yet recomputed.

These 458 documents live OUTSIDE the manifest-counted 1,105 (SMITH's LEG A
covered `definitions[]` (675) + vector inputs/expected (215+215) = 1,105).
RELIQUARY's full-sweep census found them embedded in the registry's own
`relation_and_mapping_tables`:
  - relation_and_mapping_tables.scope_relation_table_0.entries[]     (169)
  - relation_and_mapping_tables.temporal_relation_table_0.entries[]  (289)
Each entry carries the SAME document shape as `definitions[]` (verified by
direct inspection: identical field set for the encode/decode-relevant keys —
`abstract_cd0`, `canonical_cd0_hex`, `canonical_octets_byte_count`,
`sha256_checksum_of_canonical_octets`, `expected_decoded_abstract_value` —
entries additionally carry `left_fixture`/`right_fixture`/`relation`, which
are relational metadata, not codec input).

ADAPTER: reused VERBATIM from SMITH's leg_a_python.py (imported as a module,
not re-derived) — same `adapt()`, same `hexseg()`, same frozen `cd0` import,
same `cd0-conformance-default` budget object. No new schema-translation logic
is written here; this script only adds the enumeration over the 458 relation-
table entries and the encode/decode-agreement bookkeeping, mirroring LEG A's
per-document procedure exactly:
  1. ENCODE:   from_fixture_ast(adapt(abstract_cd0)) -> encode_exact -> bytes
               byte-compare to package canonical_cd0_hex
  2. BYTECOUNT len(bytes) == canonical_octets_byte_count
  3. CHECKSUM  sha256(bytes) == sha256_checksum_of_canonical_octets
  4. DECODE:   decode_exact(canonical octets) -> Datum
               equal_datum(decoded, adapt(expected_decoded_abstract_value))
"""
import hashlib
import json
import sys

PKG = "/home/gauss/Claude-Code-Lab/_staging/lci0-errata-verify/package/lci0-errata-0.1-fixture-package-2026-07-14"
SMITH_DIR = "/home/gauss/Claude-Code-Lab/_staging/lci0-errata-verify/scratch/smith"

sys.path.insert(0, SMITH_DIR)
import leg_a_python as smith  # noqa: E402  -- SMITH's frozen adapter, reused verbatim

cd0 = smith.cd0
BUDGET = smith.BUDGET
adapt = smith.adapt
first_divergence = smith.first_divergence

# NOTE: adapt() (imported verbatim from SMITH) appends string text<->utf8_hex
# consistency findings into the MODULE-LEVEL list `smith.string_consistency_failures`
# (defined inside leg_a_python.py itself) -- not a local list here. Reference that
# same list directly so the count/report reflect what adapt() actually recorded.
string_consistency_failures = smith.string_consistency_failures


def relation_documents():
    """Yield (source, docid, bundle) for the 458 relation-table entries."""
    reg = json.load(open(f"{PKG}/LCI0-FIXTURE-REGISTRY.json"))
    rmt = reg["relation_and_mapping_tables"]

    scope_entries = rmt["scope_relation_table_0"]["entries"]
    assert len(scope_entries) == 169, f"expected 169 scope entries, got {len(scope_entries)}"
    for i, e in enumerate(scope_entries):
        docid = f"scope_relation_table_0/entries[{i}]"
        yield ("scope_relation_table_0", docid, e)

    temporal_entries = rmt["temporal_relation_table_0"]["entries"]
    assert len(temporal_entries) == 289, f"expected 289 temporal entries, got {len(temporal_entries)}"
    for i, e in enumerate(temporal_entries):
        docid = f"temporal_relation_table_0/entries[{i}]"
        yield ("temporal_relation_table_0", docid, e)


def main():
    counts = {"total": 0, "encode_agree": 0, "decode_agree": 0,
              "bytecount_agree": 0, "checksum_agree": 0}
    per_source = {}
    mismatches = []

    for source, docid, bundle in relation_documents():
        counts["total"] += 1
        ps = per_source.setdefault(source, {"n": 0, "enc": 0, "dec": 0, "bc": 0, "cs": 0})
        ps["n"] += 1
        docref = f"[{source} {docid}] "
        canon_hex = bundle["canonical_cd0_hex"]
        canon = bytes.fromhex(canon_hex)

        # ENCODE
        try:
            datum = cd0.from_fixture_ast(adapt(bundle["abstract_cd0"], docref), BUDGET)
            enc = cd0.encode_exact(datum, BUDGET)
        except Exception as exc:
            mismatches.append((docid, "ENCODE-EXC", repr(exc)))
            continue
        if enc == canon:
            counts["encode_agree"] += 1
            ps["enc"] += 1
        else:
            off = first_divergence(enc, canon)
            mismatches.append((docid, "ENCODE-MISMATCH",
                               f"json_path=relation_and_mapping_tables.{docid}.abstract_cd0 "
                               f"first divergent byte offset={off} "
                               f"got={enc.hex()[:80]}... exp={canon_hex[:80]}..."))
            continue

        # BYTECOUNT
        if len(enc) == bundle["canonical_octets_byte_count"]:
            counts["bytecount_agree"] += 1
            ps["bc"] += 1
        else:
            mismatches.append((docid, "BYTECOUNT-MISMATCH",
                               f"len={len(enc)} field={bundle['canonical_octets_byte_count']}"))

        # CHECKSUM
        got_cs = hashlib.sha256(enc).hexdigest()
        if got_cs == bundle["sha256_checksum_of_canonical_octets"]:
            counts["checksum_agree"] += 1
            ps["cs"] += 1
        else:
            mismatches.append((docid, "CHECKSUM-MISMATCH",
                               f"got={got_cs} field={bundle['sha256_checksum_of_canonical_octets']}"))

        # DECODE
        try:
            decoded = cd0.decode_exact(canon, BUDGET)
            exp_datum = cd0.from_fixture_ast(adapt(bundle["expected_decoded_abstract_value"], docref), BUDGET)
        except Exception as exc:
            mismatches.append((docid, "DECODE-EXC", repr(exc)))
            continue
        if cd0.equal_datum(decoded, exp_datum):
            counts["decode_agree"] += 1
            ps["dec"] += 1
        else:
            mismatches.append((docid, "DECODE-MISMATCH",
                               f"json_path=relation_and_mapping_tables.{docid}.expected_decoded_abstract_value "
                               "equal_datum(decoded, expected)=False"))

    print("=== LEG D: frozen Python codec over 458 relation-table documents (RELIQUARY's find) ===")
    print(f"budget: {BUDGET.identifier}")
    print(f"cd0 module: {cd0.__file__}")
    print(f"adapter reused from: {smith.__file__}")
    print(f"python: {sys.version.split()[0]}")
    print()
    print("per-source breakdown (n / encode / bytecount / checksum / decode):")
    for src, ps in sorted(per_source.items()):
        print(f"  {src:28s} n={ps['n']:4d} enc={ps['enc']:4d} bc={ps['bc']:4d} cs={ps['cs']:4d} dec={ps['dec']:4d}")
    print()
    for k in ["total", "encode_agree", "bytecount_agree", "checksum_agree", "decode_agree"]:
        print(f"  {k}: {counts[k]}")
    print()
    print(f"string text<->utf8_hex consistency failures: {len(string_consistency_failures)}")
    print()
    if mismatches:
        print(f"!!! MISMATCHES: {len(mismatches)} (STOP — not papered over) !!!")
        for m in mismatches[:50]:
            print(f"    {m}")
    else:
        print("MISMATCHES: 0")

    summary = {
        "leg": "D",
        "counts": counts,
        "per_source": per_source,
        "string_consistency_failures": len(string_consistency_failures),
        "mismatches": len(mismatches),
        "mismatch_detail": mismatches[:100],
        "budget": BUDGET.identifier,
        "verdict": "PASS" if (
            counts["total"] == 458 and counts["encode_agree"] == 458
            and counts["decode_agree"] == 458 and counts["bytecount_agree"] == 458
            and counts["checksum_agree"] == 458 and not mismatches
            and not string_consistency_failures
        ) else "FAIL",
    }
    with open("leg-d-summary.json", "w") as f:
        json.dump(summary, f, indent=1)
    print(f"\nLEG D VERDICT: {summary['verdict']}")
    return 0 if summary["verdict"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
