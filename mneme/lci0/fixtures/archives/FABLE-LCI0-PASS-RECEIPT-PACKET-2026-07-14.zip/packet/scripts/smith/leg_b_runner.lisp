;;;; SMITH LEG B (runner half) — frozen Common Lisp CD/0 over 1105 documents.
;;;;
;;;; Loads the FROZEN system unmodified (package.lisp + cd0.lisp), reads the
;;;; SMITH-generated s-expression corpus form by form with the native CL reader
;;;; (no hand-written JSON parser), and for every document:
;;;;   ENCODE:  datum-from-fixture-ast(abstract) -> encode-exact -> octets-to-hex
;;;;            compare to package canonical hex
;;;;   DECODE:  hex-to-octets(canonical) -> decode-exact -> datum
;;;;            equal-datum(decoded, datum-from-fixture-ast(expected))
;;;; Uses (default-resource-budget), which is byte-identical to the Python
;;;; cd0-conformance-default budget used in LEG A.

(setf *read-eval* nil)          ; no #. evaluation while reading corpus data

(load "/home/gauss/Claude-Code-Lab/_staging/lci0-errata-verify/frozen-56f0ce55/canonical-datum/common-lisp/package.lisp")
(load "/home/gauss/Claude-Code-Lab/_staging/lci0-errata-verify/frozen-56f0ce55/canonical-datum/common-lisp/cd0.lisp")

(defpackage #:smith-leg-b (:use #:cl #:lisp-plus-cd0))
(in-package #:smith-leg-b)

(defparameter *corpus*
  "/home/gauss/Claude-Code-Lab/_staging/lci0-errata-verify/scratch/smith/leg-b-corpus.lisp-data")

(defun run ()
  (let ((budget (default-resource-budget))
        (total 0) (enc-ok 0) (dec-ok 0)
        (enc-fail '()) (dec-fail '()) (errs '()))
    (with-open-file (in *corpus* :direction :input :external-format :utf-8)
      (loop for form = (read in nil :eof)
            until (eq form :eof)
            do (incf total)
               (destructuring-bind (docid abstract canon-hex expected) form
                 (handler-case
                     (let* ((datum (datum-from-fixture-ast abstract :budget budget))
                            (enc (encode-exact datum :budget budget))
                            (enc-hex (octets-to-hex enc)))
                       ;; ENCODE byte comparison
                       (if (string= enc-hex canon-hex)
                           (incf enc-ok)
                           (push (list docid
                                       (subseq enc-hex 0 (min 80 (length enc-hex)))
                                       (subseq canon-hex 0 (min 80 (length canon-hex))))
                                 enc-fail))
                       ;; DECODE round trip and structural equality
                       (let* ((octets (hex-to-octets canon-hex))
                              (decoded (decode-exact octets :budget budget))
                              (expected-datum (datum-from-fixture-ast expected :budget budget)))
                         (if (equal-datum decoded expected-datum)
                             (incf dec-ok)
                             (push docid dec-fail))))
                   (error (c)
                     (push (list docid (princ-to-string c)) errs))))))
    (format t "=== LEG B: frozen Common Lisp codec over ~a documents ===~%" total)
    (format t "budget: ~a~%" (budget-id budget))
    (format t "total: ~a~%" total)
    (format t "encode_agree: ~a~%" enc-ok)
    (format t "decode_agree: ~a~%" dec-ok)
    (format t "encode_fail: ~a~%" (length enc-fail))
    (format t "decode_fail: ~a~%" (length dec-fail))
    (format t "errors: ~a~%" (length errs))
    (when enc-fail
      (format t "~%--- ENCODE mismatches (docid got80 exp80) ---~%")
      (dolist (e (reverse enc-fail)) (format t "  ~s~%" e)))
    (when dec-fail
      (format t "~%--- DECODE mismatches (docid) ---~%")
      (dolist (d (reverse dec-fail)) (format t "  ~s~%" d)))
    (when errs
      (format t "~%--- ERRORS (docid condition) ---~%")
      (dolist (e (reverse errs)) (format t "  ~s~%" e)))
    (let ((verdict (if (and (= total 1105) (= enc-ok 1105) (= dec-ok 1105)
                            (null enc-fail) (null dec-fail) (null errs))
                       "PASS" "FAIL")))
      (format t "~%LEG B VERDICT: ~a~%" verdict)
      (if (string= verdict "PASS") 0 1))))

(let ((code (run)))
  (finish-output)
  (sb-ext:exit :code code))
