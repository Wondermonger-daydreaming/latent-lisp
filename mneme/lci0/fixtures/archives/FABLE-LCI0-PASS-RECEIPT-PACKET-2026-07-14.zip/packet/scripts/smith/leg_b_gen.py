#!/usr/bin/env python3
"""SMITH LEG B (generator half) — emit a CL-readable s-expression corpus.

For each of the 1105 package documents, emit one top-level Lisp form:

    ("<docid>" <abstract-fixture-ast> "<canonical-hex>" <expected-fixture-ast>)

The two fixture-ASTs are string-keyed DOTTED-PAIR alists in the EXACT schema
that the frozen `datum-from-fixture-ast` consumes (hex-based: utf8_hex, hex,
namespace_utf8_hex, path_utf8_hex; bool as Lisp T/NIL). This is the same pure
structural ADAPTER used in LEG A (plain-string -> UTF-8 hex; rat num/den ->
p/q; string drop redundant `text`, keep authoritative utf8_hex), re-targeted to
s-expression syntax so Common Lisp's own reader parses it — NO hand-written
JSON parser reaches the CL side.

Everything emitted is pure ASCII (unicode is carried as hex), so the CL reader
never sees a raw non-ASCII byte.
"""
import json
import sys

PKG = "/home/gauss/Claude-Code-Lab/_staging/lci0-errata-verify/package/lci0-errata-0.1-fixture-package-2026-07-14"
OUT = "/home/gauss/Claude-Code-Lab/_staging/lci0-errata-verify/scratch/smith/leg-b-corpus.lisp-data"


def L(s):
    """Render a Python str as a Common Lisp string literal."""
    return '"' + str(s).replace("\\", "\\\\").replace('"', '\\"') + '"'


def dotted(key, val_literal):
    return f"({L(key)} . {val_literal})"


def alist(entries):
    return "(" + " ".join(dotted(k, v) for k, v in entries) + ")"


def lisplist(elems):
    return "(" + " ".join(elems) + ")"


def hexseg(s):
    if not isinstance(s, str):
        raise TypeError(f"identifier segment is not a str: {s!r}")
    return s.encode("utf-8").hex()


def sexp(node, path="$"):
    if not isinstance(node, dict):
        raise TypeError(f"{path}: non-dict node {node!r}")
    t = node.get("t")
    if t == "unit":
        return alist([("t", L("unit"))])
    if t == "bool":
        v = node["v"]
        if not isinstance(v, bool):
            raise TypeError(f"{path}: bool value not a JSON boolean: {v!r}")
        return alist([("t", L("bool")), ("v", "T" if v else "NIL")])
    if t == "int":
        return alist([("t", L("int")), ("v", L(str(node["v"])))])
    if t == "rat":
        return alist([("t", L("rat")), ("p", L(str(node["num"]))), ("q", L(str(node["den"])))])
    if t == "string":
        return alist([("t", L("string")), ("utf8_hex", L(node["utf8_hex"]))])
    if t == "bytes":
        return alist([("t", L("bytes")), ("hex", L(node["hex"]))])
    if t == "id":
        ns = lisplist([L(hexseg(s)) for s in node["namespace"]])
        pa = lisplist([L(hexseg(s)) for s in node["path"]])
        return alist([("t", L("id")), ("namespace_utf8_hex", ns), ("path_utf8_hex", pa)])
    if t == "seq":
        items = lisplist([sexp(x, f"{path}.items[{i}]") for i, x in enumerate(node["items"])])
        return alist([("t", L("seq")), ("items", items)])
    if t == "record":
        fields = []
        for i, fld in enumerate(node["fields"]):
            if set(fld) != {"key", "value"}:
                raise ValueError(f"{path}.fields[{i}]: field keys {set(fld)} != {{key,value}}")
            fields.append(alist([
                ("key", sexp(fld["key"], f"{path}.fields[{i}].key")),
                ("value", sexp(fld["value"], f"{path}.fields[{i}].value")),
            ]))
        return alist([("t", L("record")), ("fields", lisplist(fields))])
    raise ValueError(f"{path}: unknown/ambiguous node tag {t!r} keys={sorted(node)}")


def documents():
    reg = json.load(open(f"{PKG}/LCI0-FIXTURE-REGISTRY.json"))
    for d in reg["definitions"]:
        yield (d.get("fixture_id", "?"), d)
    with open(f"{PKG}/LCI0-FIXTURE-VECTORS.jsonl") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            r = json.loads(line)
            vid = r.get("vector_id", "?")
            yield (f"{vid}:inputs", r["inputs"])
            yield (f"{vid}:expected", r["expected"])


def main():
    n = 0
    with open(OUT, "w", encoding="ascii") as out:
        for docid, bundle in documents():
            form = "(" + " ".join([
                L(docid),
                sexp(bundle["abstract_cd0"]),
                L(bundle["canonical_cd0_hex"]),
                sexp(bundle["expected_decoded_abstract_value"]),
            ]) + ")\n"
            # ascii-only guarantee
            form.encode("ascii")
            out.write(form)
            n += 1
    print(f"wrote {n} forms to {OUT}")


if __name__ == "__main__":
    main()
