#!/usr/bin/env python3
"""SMITH LEG-A prep: empirically enumerate the package abstract-value schema.

Walks every abstract value in all 1105 documents (675 registry definitions +
215 vectors x {inputs, expected}) and records, for each node, the pair
(tag, sorted(keys)).  Also reports the enumeration count breakdown and the
max canonical byte count (to confirm the conformance-default budget covers it).

No frozen tools touched; pure inspection of the package JSON.
"""
import json
import sys
from collections import Counter

PKG = "/home/gauss/Claude-Code-Lab/_staging/lci0-errata-verify/package/lci0-errata-0.1-fixture-package-2026-07-14"

shapes = Counter()          # (tag, sorted-keys) -> count, over abstract_cd0 nodes
shapes_expected = Counter()  # same, over expected_decoded_abstract_value nodes
notag_shapes = Counter()     # nodes that are dicts lacking a "t" key


def walk(node, sink):
    if isinstance(node, dict):
        t = node.get("t")
        keyset = tuple(sorted(node.keys()))
        if t is None:
            notag_shapes[keyset] += 1
            sink[("<no-t>", keyset)] += 1
        else:
            sink[(t, keyset)] += 1
        for v in node.values():
            walk(v, sink)
    elif isinstance(node, list):
        for v in node:
            walk(v, sink)
    # scalars: ignore


def bundle_docs():
    """Yield (source_label, bundle_dict) for all 1105 documents."""
    reg = json.load(open(f"{PKG}/LCI0-FIXTURE-REGISTRY.json"))
    defs = reg["definitions"]
    for d in defs:
        yield ("registry-definition", d)
    with open(f"{PKG}/LCI0-FIXTURE-VECTORS.jsonl") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            r = json.loads(line)
            yield ("vector-inputs", r["inputs"])
            yield ("vector-expected", r["expected"])


def main():
    breakdown = Counter()
    total = 0
    have_hex = 0
    max_bytes = 0
    max_bytes_id = None
    hex_matches_bytecount = 0
    for label, bundle in bundle_docs():
        total += 1
        breakdown[label] += 1
        if "canonical_cd0_hex" in bundle and bundle["canonical_cd0_hex"] is not None:
            have_hex += 1
            hx = bundle["canonical_cd0_hex"]
            nb = len(hx) // 2
            if bundle.get("canonical_octets_byte_count") == nb:
                hex_matches_bytecount += 1
            if nb > max_bytes:
                max_bytes = nb
                max_bytes_id = bundle.get("fixture_id") or bundle.get("equality_class")
        walk(bundle.get("abstract_cd0"), shapes)
        walk(bundle.get("expected_decoded_abstract_value"), shapes_expected)

    print("=== ENUMERATION BREAKDOWN ===")
    for k, v in breakdown.items():
        print(f"  {k}: {v}")
    print(f"  TOTAL documents: {total}")
    print(f"  documents with canonical_cd0_hex: {have_hex}")
    print(f"  hex-length matches byte_count field: {hex_matches_bytecount}")
    print(f"  max canonical byte count: {max_bytes}  (doc: {max_bytes_id})")
    print()
    print("=== abstract_cd0 NODE SHAPES (tag, keys) -> count ===")
    for (t, keys), c in sorted(shapes.items()):
        print(f"  {t:12s} keys={list(keys)}  x{c}")
    print()
    print("=== expected_decoded_abstract_value NODE SHAPES ===")
    for (t, keys), c in sorted(shapes_expected.items()):
        print(f"  {t:12s} keys={list(keys)}  x{c}")
    print()
    print("=== dict nodes lacking a 't' key (would be ambiguous) ===")
    if not notag_shapes:
        print("  NONE — every dict node carries an explicit 't' tag.")
    else:
        for keys, c in sorted(notag_shapes.items()):
            print(f"  keys={list(keys)}  x{c}")


if __name__ == "__main__":
    main()
