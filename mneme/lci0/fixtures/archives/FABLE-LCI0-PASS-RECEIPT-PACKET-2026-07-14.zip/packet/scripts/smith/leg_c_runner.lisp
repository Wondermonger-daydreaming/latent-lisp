;;;; SMITH LEG C (CL half) — re-encode the ten E1 abstract values with the
;;;; frozen Common Lisp codec and byte-compare to the errata-pinned hex.
;;;; Third leg of the three-way agreement (errata text = Python = CL).

(setf *read-eval* nil)

(load "/home/gauss/Claude-Code-Lab/_staging/lci0-errata-verify/frozen-56f0ce55/canonical-datum/common-lisp/package.lisp")
(load "/home/gauss/Claude-Code-Lab/_staging/lci0-errata-verify/frozen-56f0ce55/canonical-datum/common-lisp/cd0.lisp")

(defpackage #:smith-leg-c (:use #:cl #:lisp-plus-cd0))
(in-package #:smith-leg-c)

(defparameter *corpus*
  "/home/gauss/Claude-Code-Lab/_staging/lci0-errata-verify/scratch/smith/e1-corpus.lisp-data")

(let ((budget (default-resource-budget))
      (total 0) (ok 0) (fails '()))
  (with-open-file (in *corpus* :direction :input :external-format :utf-8)
    (loop for form = (read in nil :eof)
          until (eq form :eof)
          do (incf total)
             (destructuring-bind (docid abstract errata-hex) form
               (handler-case
                   (let* ((datum (datum-from-fixture-ast abstract :budget budget))
                          (cl-hex (octets-to-hex (encode-exact datum :budget budget))))
                     (if (string= cl-hex errata-hex)
                         (progn (incf ok)
                                (format t "OK  ~a~%" docid))
                         (progn
                           (push docid fails)
                           (format t "BAD ~a  cl=~a... errata=~a...~%"
                                   docid
                                   (subseq cl-hex 0 (min 60 (length cl-hex)))
                                   (subseq errata-hex 0 (min 60 (length errata-hex)))))))
                 (error (c)
                   (push docid fails)
                   (format t "ERR ~a  ~a~%" docid (princ-to-string c)))))))
  (format t "~%=== LEG C (CL): ten E1 values ===~%")
  (format t "total: ~a  cl_matches_errata: ~a  fails: ~a~%" total ok (length fails))
  (let ((verdict (if (and (= total 10) (= ok 10) (null fails)) "PASS" "FAIL")))
    (format t "LEG C CL VERDICT: ~a~%" verdict)
    (finish-output)
    (sb-ext:exit :code (if (string= verdict "PASS") 0 1))))
