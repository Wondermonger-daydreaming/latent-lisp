#!/usr/bin/env python3
"""SMITH LEG A — frozen Python CD/0 codec over all 1105 package documents.

Uses the frozen codec EXACTLY as frozen (canonical-datum/python/cd0). The only
new code is a pure structural ADAPTER translating the package abstract-value
schema (plain-string identifiers/strings) into the codec's own fixture-AST
import schema (utf8-hex), then it calls the frozen from_fixture_ast /
encode_exact / decode_exact / equal_datum.

Per document (registry definition, vector input, vector expected):
  1. ENCODE:   from_fixture_ast(adapt(abstract_cd0)) -> encode_exact -> bytes
               byte-compare to package canonical_cd0_hex
  2. BYTECOUNT len(bytes) == canonical_octets_byte_count
  3. CHECKSUM  sha256(bytes) == sha256_checksum_of_canonical_octets
  4. DECODE:   decode_exact(canonical octets) -> Datum
               equal_datum(decoded, adapt(expected_decoded_abstract_value))

ADAPTER DECISIONS (documented; each is a mechanical schema rename/encode with
NO semantic choice — the package byte authority is preserved verbatim):
  A. id:     {namespace:[str],path:[str]}  -> {namespace_utf8_hex:[hex],path_utf8_hex:[hex]}
             (each segment str -> UTF-8 bytes -> lowercase hex; deterministic)
  B. string: {text, utf8_hex} -> {utf8_hex}   (drop redundant `text`; keep the
             package's authoritative utf8_hex byte form. Consistency of
             text<->utf8_hex is asserted separately, not used to encode.)
  C. rat:    {num, den} -> {p, q}            (key rename only)
  D. unit/bool/int/bytes/seq/record: key-identical to codec schema; pass through
             (record fields are {key,value}, matching the codec exactly).
Any node whose shape is not one of these 10 raises -> reported, not papered over.
"""
import hashlib
import json
import sys

FROZEN = "/home/gauss/Claude-Code-Lab/_staging/lci0-errata-verify/frozen-56f0ce55"
PKG = "/home/gauss/Claude-Code-Lab/_staging/lci0-errata-verify/package/lci0-errata-0.1-fixture-package-2026-07-14"
sys.path.insert(0, f"{FROZEN}/canonical-datum/python")
import cd0  # frozen codec, untouched

# ---- frozen reference budget (the codec's own conformance-default) ----
_budgets = json.load(open(f"{FROZEN}/canonical-datum/vectors/cd0-budgets.json"))
_limits = _budgets["limits"] if isinstance(_budgets.get("limits"), list) else None
_raw = _budgets["budgets"]["cd0-conformance-default"]
BUDGET = cd0.ResourceBudget.from_mapping(_raw, identifier="cd0-conformance-default")

string_consistency_failures = []  # (docref, path, text, utf8_hex)


def hexseg(s):
    if not isinstance(s, str):
        raise TypeError(f"identifier segment is not a str: {s!r}")
    return s.encode("utf-8").hex()


def adapt(node, docref="", path="$"):
    """Package abstract-value JSON -> codec fixture-AST. Pure structural."""
    if not isinstance(node, dict):
        raise TypeError(f"{docref}{path}: non-dict node {node!r}")
    t = node.get("t")
    if t == "unit":
        return {"t": "unit"}
    if t == "bool":
        return {"t": "bool", "v": node["v"]}
    if t == "int":
        return {"t": "int", "v": node["v"]}
    if t == "rat":
        return {"t": "rat", "p": node["num"], "q": node["den"]}
    if t == "bytes":
        return {"t": "bytes", "hex": node["hex"]}
    if t == "string":
        # consistency guard: text must match utf8_hex (report, do not use to encode)
        text = node.get("text")
        uh = node["utf8_hex"]
        try:
            if text is not None and bytes.fromhex(uh).decode("utf-8") != text:
                string_consistency_failures.append((docref, path, text, uh))
        except Exception:
            string_consistency_failures.append((docref, path, text, uh))
        return {"t": "string", "utf8_hex": uh}
    if t == "id":
        return {
            "t": "id",
            "namespace_utf8_hex": [hexseg(s) for s in node["namespace"]],
            "path_utf8_hex": [hexseg(s) for s in node["path"]],
        }
    if t == "seq":
        return {"t": "seq",
                "items": [adapt(x, docref, f"{path}.items[{i}]")
                          for i, x in enumerate(node["items"])]}
    if t == "record":
        out = []
        for i, fld in enumerate(node["fields"]):
            if set(fld) != {"key", "value"}:
                raise ValueError(f"{docref}{path}.fields[{i}]: field keys {set(fld)} != {{key,value}}")
            out.append({
                "key": adapt(fld["key"], docref, f"{path}.fields[{i}].key"),
                "value": adapt(fld["value"], docref, f"{path}.fields[{i}].value"),
            })
        return {"t": "record", "fields": out}
    raise ValueError(f"{docref}{path}: unknown/ambiguous node tag {t!r} keys={sorted(node)}")


def first_divergence(a, b):
    n = min(len(a), len(b))
    for i in range(n):
        if a[i] != b[i]:
            return i
    if len(a) != len(b):
        return n
    return None


def documents():
    reg = json.load(open(f"{PKG}/LCI0-FIXTURE-REGISTRY.json"))
    for d in reg["definitions"]:
        yield ("registry-definition", d.get("fixture_id", "?"), d)
    with open(f"{PKG}/LCI0-FIXTURE-VECTORS.jsonl") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            r = json.loads(line)
            vid = r.get("vector_id", "?")
            yield ("vector-input", f"{vid}:inputs", r["inputs"])
            yield ("vector-expected", f"{vid}:expected", r["expected"])


def main():
    counts = {"total": 0, "encode_agree": 0, "decode_agree": 0,
              "bytecount_agree": 0, "checksum_agree": 0}
    per_source = {}
    mismatches = []
    for source, docid, bundle in documents():
        counts["total"] += 1
        ps = per_source.setdefault(source, {"n": 0, "enc": 0, "dec": 0, "bc": 0, "cs": 0})
        ps["n"] += 1
        docref = f"[{source} {docid}] "
        canon_hex = bundle["canonical_cd0_hex"]
        canon = bytes.fromhex(canon_hex)

        # ENCODE
        try:
            datum = cd0.from_fixture_ast(adapt(bundle["abstract_cd0"], docref), BUDGET)
            enc = cd0.encode_exact(datum, BUDGET)
        except Exception as exc:
            mismatches.append((docid, "ENCODE-EXC", repr(exc)))
            continue
        if enc == canon:
            counts["encode_agree"] += 1
            ps["enc"] += 1
        else:
            off = first_divergence(enc, canon)
            mismatches.append((docid, "ENCODE-MISMATCH",
                               f"first divergent offset={off} got={enc.hex()[:80]}... exp={canon_hex[:80]}..."))
            continue

        # BYTECOUNT
        if len(enc) == bundle["canonical_octets_byte_count"]:
            counts["bytecount_agree"] += 1
            ps["bc"] += 1
        else:
            mismatches.append((docid, "BYTECOUNT-MISMATCH",
                               f"len={len(enc)} field={bundle['canonical_octets_byte_count']}"))

        # CHECKSUM
        got_cs = hashlib.sha256(enc).hexdigest()
        if got_cs == bundle["sha256_checksum_of_canonical_octets"]:
            counts["checksum_agree"] += 1
            ps["cs"] += 1
        else:
            mismatches.append((docid, "CHECKSUM-MISMATCH",
                               f"got={got_cs} field={bundle['sha256_checksum_of_canonical_octets']}"))

        # DECODE
        try:
            decoded = cd0.decode_exact(canon, BUDGET)
            exp_datum = cd0.from_fixture_ast(adapt(bundle["expected_decoded_abstract_value"], docref), BUDGET)
        except Exception as exc:
            mismatches.append((docid, "DECODE-EXC", repr(exc)))
            continue
        if cd0.equal_datum(decoded, exp_datum):
            counts["decode_agree"] += 1
            ps["dec"] += 1
        else:
            mismatches.append((docid, "DECODE-MISMATCH", "equal_datum(decoded, expected)=False"))

    print("=== LEG A: frozen Python codec over 1105 package documents ===")
    print(f"budget: {BUDGET.identifier}")
    print(f"cd0 module: {cd0.__file__}")
    print(f"python: {sys.version.split()[0]}")
    print()
    print("per-source breakdown (n / encode / bytecount / checksum / decode):")
    for src, ps in sorted(per_source.items()):
        print(f"  {src:20s} n={ps['n']:4d} enc={ps['enc']:4d} bc={ps['bc']:4d} cs={ps['cs']:4d} dec={ps['dec']:4d}")
    print()
    for k in ["total", "encode_agree", "bytecount_agree", "checksum_agree", "decode_agree"]:
        print(f"  {k}: {counts[k]}")
    print()
    print(f"string text<->utf8_hex consistency failures: {len(string_consistency_failures)}")
    for f in string_consistency_failures[:10]:
        print(f"    {f}")
    print()
    if mismatches:
        print(f"!!! MISMATCHES: {len(mismatches)} (STOP — not papered over) !!!")
        for m in mismatches[:25]:
            print(f"    {m}")
    else:
        print("MISMATCHES: 0")

    summary = {
        "leg": "A",
        "counts": counts,
        "per_source": per_source,
        "string_consistency_failures": len(string_consistency_failures),
        "mismatches": len(mismatches),
        "mismatch_detail": mismatches[:50],
        "budget": BUDGET.identifier,
        "verdict": "PASS" if (
            counts["total"] == 1105 and counts["encode_agree"] == 1105
            and counts["decode_agree"] == 1105 and counts["bytecount_agree"] == 1105
            and counts["checksum_agree"] == 1105 and not mismatches
            and not string_consistency_failures
        ) else "FAIL",
    }
    json.dump(summary, open("leg-a-summary.json", "w"), indent=1)
    print(f"\nLEG A VERDICT: {summary['verdict']}")
    return 0 if summary["verdict"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
