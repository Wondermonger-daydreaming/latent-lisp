#!/usr/bin/env python3
"""SMITH LEG C — the TEN E1-pinned values, three-way byte agreement.

1. Parse errata §E1 to extract, for each of the ten pinned values:
     registry fixture id, byte count, SHA-256 review checksum,
     the EXACT abstract CD/0 value (```json block), and the pinned
     canonical hex (```text block).
2. Recompute octets with the FROZEN Python codec from the abstract value;
   byte-compare to the errata hex.  Also verify byte count and the review
   checksum against sha256(errata octets).
3. Emit e1-values.jsonl (docid, abstract, hex) for the CL side to re-encode.
4. Confirm the same fixture ids appear in the registry with IDENTICAL octets.
5. Write e1-recompute.json with per-value verdicts (CL results merged later).
"""
import hashlib
import json
import re
import sys

FROZEN = "/home/gauss/Claude-Code-Lab/_staging/lci0-errata-verify/frozen-56f0ce55"
PKG = "/home/gauss/Claude-Code-Lab/_staging/lci0-errata-verify/package/lci0-errata-0.1-fixture-package-2026-07-14"
ERRATA = f"{PKG}/LOCATED-CLAIM-IDENTITY-SPEC-ERRATA-0.1.md"
REG = f"{PKG}/LCI0-FIXTURE-REGISTRY.json"
sys.path.insert(0, f"{FROZEN}/canonical-datum/python")
import cd0

_raw = json.load(open(f"{FROZEN}/canonical-datum/vectors/cd0-budgets.json"))["budgets"]["cd0-conformance-default"]
BUDGET = cd0.ResourceBudget.from_mapping(_raw, identifier="cd0-conformance-default")


# ---- same pure adapter as LEG A: package abstract-value JSON -> codec fixture-AST ----
def hexseg(s):
    return s.encode("utf-8").hex()


def adapt(node):
    t = node.get("t")
    if t == "unit":
        return {"t": "unit"}
    if t == "bool":
        return {"t": "bool", "v": node["v"]}
    if t == "int":
        return {"t": "int", "v": node["v"]}
    if t == "rat":
        return {"t": "rat", "p": node["num"], "q": node["den"]}
    if t == "bytes":
        return {"t": "bytes", "hex": node["hex"]}
    if t == "string":
        return {"t": "string", "utf8_hex": node["utf8_hex"]}
    if t == "id":
        return {"t": "id",
                "namespace_utf8_hex": [hexseg(s) for s in node["namespace"]],
                "path_utf8_hex": [hexseg(s) for s in node["path"]]}
    if t == "seq":
        return {"t": "seq", "items": [adapt(x) for x in node["items"]]}
    if t == "record":
        return {"t": "record",
                "fields": [{"key": adapt(f["key"]), "value": adapt(f["value"])} for f in node["fields"]]}
    raise ValueError(f"unknown node tag {t!r}")


def parse_e1(text):
    """Return list of dicts for the ten pinned values in errata §E1."""
    lines = text.splitlines()
    # isolate E1 region: from '## E1 ' to the next '## E1.2' (shared-octet obligation)
    start = next(i for i, l in enumerate(lines) if l.startswith("## E1 "))
    end = next(i for i, l in enumerate(lines) if l.startswith("### E1.2") or l.startswith("## E1.2"))
    region = lines[start:end]
    # split into value subsections
    idxs = [i for i, l in enumerate(region)
            if l.startswith("### Base reference") or l.startswith("### Neutral expression")]
    values = []
    for k, si in enumerate(idxs):
        ei = idxs[k + 1] if k + 1 < len(idxs) else len(region)
        block = region[si:ei]
        head = block[0].strip()
        fixture = _field(block, r"\*\*Registry fixture:\*\*\s*`([^`]+)`")
        bytecount = _field(block, r"\*\*Byte count:\*\*\s*`([^`]+)`")
        checksum = _field(block, r"\*\*SHA-256 review checksum[^`]*`([0-9a-f]+)`")
        abstract = _fenced_after(block, "Exact abstract CD/0 value")
        hexblk = _fenced_after(block, "Complete canonical CD/0 document")
        values.append({
            "head": head,
            "fixture_id": fixture,
            "byte_count": int(bytecount) if bytecount else None,
            "review_checksum": checksum,
            "abstract_value": json.loads(abstract),
            "errata_hex": hexblk.strip().replace("\n", "").replace(" ", ""),
        })
    return values


def _field(block, pattern):
    rx = re.compile(pattern)
    for l in block:
        m = rx.search(l)
        if m:
            return m.group(1)
    return None


def _fenced_after(block, marker):
    """Return the content of the first ``` fenced block appearing after a line
    containing `marker`."""
    i = 0
    while i < len(block) and marker not in block[i]:
        i += 1
    # find opening fence
    while i < len(block) and not block[i].lstrip().startswith("```"):
        i += 1
    i += 1  # first content line
    buf = []
    while i < len(block) and not block[i].lstrip().startswith("```"):
        buf.append(block[i])
        i += 1
    return "\n".join(buf)


def first_divergence(a, b):
    n = min(len(a), len(b))
    for i in range(n):
        if a[i] != b[i]:
            return i
    return None if len(a) == len(b) else n


def main():
    text = open(ERRATA, encoding="utf-8").read()
    values = parse_e1(text)
    assert len(values) == 10, f"expected 10 E1 values, extracted {len(values)}"

    # registry lookup by fixture_id
    reg = json.load(open(REG))
    reg_by_id = {d["fixture_id"]: d for d in reg["definitions"]}

    results = []
    e1_corpus = open("e1-values.jsonl", "w")
    all_ok = True
    for v in values:
        errata_hex = v["errata_hex"]
        errata_octets = bytes.fromhex(errata_hex)
        # Python recompute
        datum = cd0.from_fixture_ast(adapt(v["abstract_value"]), BUDGET)
        py_hex = cd0.encode_exact(datum, BUDGET).hex()
        py_match = (py_hex == errata_hex)
        # byte count & review checksum against errata octets
        bc_match = (len(errata_octets) == v["byte_count"])
        cs = hashlib.sha256(errata_octets).hexdigest()
        cs_match = (cs == v["review_checksum"])
        # decode round-trip (Python)
        decoded = cd0.decode_exact(errata_octets, BUDGET)
        py_roundtrip = cd0.equal_datum(decoded, datum)
        # registry cross-check
        rd = reg_by_id.get(v["fixture_id"])
        reg_hex = rd["canonical_cd0_hex"] if rd else None
        reg_match = (reg_hex == errata_hex)

        div = first_divergence(py_hex, errata_hex)
        rec = {
            "head": v["head"],
            "fixture_id": v["fixture_id"],
            "byte_count_field": v["byte_count"],
            "errata_hex_len_bytes": len(errata_octets),
            "review_checksum": v["review_checksum"],
            "recomputed_sha256": cs,
            "python_encode_hex_matches_errata": py_match,
            "python_first_divergence_offset": div,
            "byte_count_matches": bc_match,
            "review_checksum_matches": cs_match,
            "python_decode_roundtrip": py_roundtrip,
            "registry_present": rd is not None,
            "registry_octets_match_errata": reg_match,
            "errata_hex": errata_hex,
        }
        results.append(rec)
        e1_corpus.write(json.dumps({
            "docid": v["fixture_id"],
            "abstract": v["abstract_value"],
            "errata_hex": errata_hex,
        }) + "\n")
        ok = py_match and bc_match and cs_match and py_roundtrip and reg_match and (rd is not None)
        all_ok = all_ok and ok
        print(f"{'OK ' if ok else 'BAD'} {v['fixture_id']:45s} py={py_match} bc={bc_match} cs={cs_match} rt={py_roundtrip} reg={reg_match}")
    e1_corpus.close()

    json.dump({"budget": BUDGET.identifier, "n": len(results),
               "python_all_ok": all_ok, "values": results},
              open("e1-recompute.json", "w"), indent=1)
    print(f"\nPython side all_ok: {all_ok}")
    print("wrote e1-values.jsonl (for CL) and e1-recompute.json")
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
