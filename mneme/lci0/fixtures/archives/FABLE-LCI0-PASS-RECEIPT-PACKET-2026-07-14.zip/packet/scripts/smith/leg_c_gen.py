#!/usr/bin/env python3
"""SMITH LEG C (CL generator half) — emit the ten E1 abstract values as a
CL-readable s-expression corpus: ("<fixture-id>" <abstract-ast> "<errata-hex>").
Reuses the exact sexp adapter from LEG B (plain->hex, read-able alists)."""
import json
from leg_b_gen import sexp, L

IN = "/home/gauss/Claude-Code-Lab/_staging/lci0-errata-verify/scratch/smith/e1-values.jsonl"
OUT = "/home/gauss/Claude-Code-Lab/_staging/lci0-errata-verify/scratch/smith/e1-corpus.lisp-data"

n = 0
with open(OUT, "w", encoding="ascii") as out:
    for line in open(IN):
        line = line.strip()
        if not line:
            continue
        r = json.loads(line)
        form = "(" + " ".join([L(r["docid"]), sexp(r["abstract"]), L(r["errata_hex"])]) + ")\n"
        form.encode("ascii")
        out.write(form)
        n += 1
print(f"wrote {n} E1 forms to {OUT}")
