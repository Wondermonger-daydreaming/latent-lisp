#!/usr/bin/env python3
"""VECTOR-MARSHAL harness for LCI/0 fixture vectors.

Two verification axes:
  Pass A (all 215): octet integrity + CD/0 self-consistency + failure-metadata
                    cross-check + namespace membership. No codec required (octet
                    check is sha256/bytecount over the supplied canonical hex).
  Pass B (targeted): re-derive the DECISION (status / failure classification)
                    from the spec's CLOSED tables for tractable operation
                    families, driven by the payload arguments. Emits
                    MATCH / MISMATCH / UNDERDETERMINED / CONSISTENCY-ONLY.
"""
import json, re, hashlib, sys, csv
from collections import defaultdict, Counter

PKG = "/home/gauss/Claude-Code-Lab/_staging/lci0-errata-verify/package/lci0-errata-0.1-fixture-package-2026-07-14"
VECTORS = PKG + "/LCI0-FIXTURE-VECTORS.jsonl"

LCI_FAIL_NS = ["lisp-plus", "lci", "0", "failure"]

# ----- abstract CD/0 node helpers -----
def is_id(n):    return isinstance(n, dict) and n.get("t") == "id"
def is_rec(n):   return isinstance(n, dict) and n.get("t") == "record"
def is_seq(n):   return isinstance(n, dict) and n.get("t") == "seq"
def is_int(n):   return isinstance(n, dict) and n.get("t") == "int"
def is_str(n):   return isinstance(n, dict) and n.get("t") == "string"
def is_bool(n):  return isinstance(n, dict) and n.get("t") == "bool"

def id_key(n):
    """Canonical comparable key for an id node."""
    if not is_id(n): return None
    return (tuple(n["namespace"]), tuple(n["path"]))

def id_path(n):
    return tuple(n["path"]) if is_id(n) else None

def rec_fields(n):
    return n["fields"] if is_rec(n) else []

def rec_get(rec, path, ns=None):
    """Return value node whose key-id has path==path (tuple/list) and optionally ns."""
    if isinstance(path, str): path = [path]
    path = list(path)
    for f in rec_fields(rec):
        k = f["key"]
        if is_id(k) and list(k["path"]) == path and (ns is None or list(k["namespace"]) == list(ns)):
            return f["value"]
    return None

def rec_get_bytail(rec, tail):
    """Return value for the field whose key path ends with `tail` (str)."""
    for f in rec_fields(rec):
        k = f["key"]
        if is_id(k) and k["path"] and k["path"][-1] == tail:
            return f["value"]
    return None

def seq_items(n):
    return n["items"] if is_seq(n) else []

def as_int(n):
    return int(n["v"]) if is_int(n) else None

def as_str(n):
    if is_str(n): return n.get("text")
    return None

# ----- failure diagnostic-string parser -----
ID_RE = re.compile(r'Id\(\[(.*?)\],\s*\[(.*?)\]\)')
def parse_id_string(s):
    """'Id(["a","b"], ["c"])' -> (['a','b'],['c'])"""
    if s is None: return None
    m = ID_RE.search(s)
    if not m: return None
    def toks(x):
        return [t.strip().strip('"') for t in x.split(",")] if x.strip() else []
    return (toks(m.group(1)), toks(m.group(2)))

def load():
    out = []
    with open(VECTORS) as f:
        for line in f:
            line = line.strip()
            if line:
                out.append(json.loads(line))
    return out

def octet_check(side):
    hexstr = side["canonical_cd0_hex"]
    raw = bytes.fromhex(hexstr)
    bc = side["canonical_octets_byte_count"]
    sh = side["sha256_checksum_of_canonical_octets"]
    ok_len = (len(raw) == bc)
    ok_sha = (hashlib.sha256(raw).hexdigest() == sh)
    return ok_len, ok_sha, len(raw), hashlib.sha256(raw).hexdigest()

def deep_eq(a, b):
    return json.dumps(a, sort_keys=True) == json.dumps(b, sort_keys=True)

def passA(vecs):
    rows = []
    fails = []
    for d in vecs:
        vid = d["vector_id"]
        rec = {"vector_id": vid, "operation": d["operation"], "vector_class": d["vector_class"],
               "status": d["expected_result"]["status"]}
        issues = []

        # A1 octet integrity (inputs + expected)
        for side_name in ("inputs", "expected"):
            side = d[side_name]
            ok_len, ok_sha, glen, gsha = octet_check(side)
            if not ok_len: issues.append(f"{side_name}:bytecount({glen}!={side['canonical_octets_byte_count']})")
            if not ok_sha: issues.append(f"{side_name}:sha256_mismatch")

        # A2 abstract == expected_decoded (both sides)
        for side_name in ("inputs", "expected"):
            side = d[side_name]
            if not deep_eq(side["abstract_cd0"], side["expected_decoded_abstract_value"]):
                issues.append(f"{side_name}:abstract!=decoded")

        # A3 embedded operation & vector-id inside inputs.payload wrapper
        inp = d["inputs"]["abstract_cd0"]
        emb_op = rec_get_bytail(inp, "operation")
        emb_vid = rec_get_bytail(inp, "vector-id")
        if is_id(emb_op):
            if emb_op["path"][-1] != d["operation"]:
                issues.append(f"embedded-op({emb_op['path'][-1]}!={d['operation']})")
            rec["embedded_op"] = emb_op["path"][-1]
        else:
            issues.append("embedded-op-missing")
        if as_str(emb_vid) != vid:
            issues.append(f"embedded-vid({as_str(emb_vid)}!={vid})")

        # A4 machine_value == expected.abstract_cd0
        if not deep_eq(d["expected_result"]["machine_value"], d["expected"]["abstract_cd0"]):
            issues.append("machine_value!=expected.abstract")

        # A5 status<->failure presence + failure metadata cross-check vs machine_value
        st = d["expected_result"]["status"]
        fv = d.get("failure")
        if st == "failure":
            if fv is None:
                issues.append("status=failure_but_no_failure_obj")
            else:
                # machine_value must be a failure record; cross-check category/code/stage/path
                mv = d["expected_result"]["machine_value"]
                mv_kind = rec_get(mv, ["kind"])
                if not (is_id(mv_kind) and mv_kind["path"][-1] == "failure"):
                    issues.append("machine_value_not_failure_record")
                for field, key in (("category", "category"), ("code", "code"), ("stage", "stage")):
                    exp = parse_id_string(fv.get(field))
                    got = rec_get(mv, [key])
                    if got is None or not is_id(got):
                        issues.append(f"mv_missing_{key}")
                        continue
                    if exp is None or (list(got["namespace"]), list(got["path"])) != (exp[0], exp[1]):
                        issues.append(f"mv_{key}_mismatch({got['path']}!={exp})")
                # path
                exp_path = [parse_id_string(p) for p in fv.get("path", [])]
                mv_path = rec_get(mv, ["path"])
                got_path = [ (list(x["namespace"]), list(x["path"])) for x in seq_items(mv_path) if is_id(x)] if mv_path is not None else []
                if got_path != [ (e[0], e[1]) for e in exp_path if e]:
                    issues.append(f"mv_path_mismatch")
                # record failure identity
                rec["fail_category"] = parse_id_string(fv.get("category"))[1][-1] if parse_id_string(fv.get("category")) else None
                rec["fail_code"] = parse_id_string(fv.get("code"))[1][-1] if parse_id_string(fv.get("code")) else None
                rec["fail_stage"] = parse_id_string(fv.get("stage"))[1][-1] if parse_id_string(fv.get("stage")) else None
        else:  # success
            if fv is not None:
                issues.append("status=success_but_failure_obj_present")
            mv = d["expected_result"]["machine_value"]
            mv_status = rec_get_bytail(mv, "status")
            if is_id(mv_status):
                rec["result_status"] = mv_status["path"][-1]
                if mv_status["path"][-1] != "success":
                    issues.append(f"success_result_status={mv_status['path'][-1]}")

        # A6 namespace membership of failure identity
        if fv is not None:
            for field in ("category", "code", "stage"):
                pid = parse_id_string(fv.get(field))
                if pid and pid[0] != LCI_FAIL_NS:
                    issues.append(f"{field}_wrong_ns({pid[0]})")

        rec["issues"] = ";".join(issues)
        rec["passA"] = (len(issues) == 0)
        rows.append(rec)
        if issues:
            fails.append((vid, issues))
    return rows, fails

if __name__ == "__main__":
    vecs = load()
    print(f"loaded {len(vecs)} vectors")
    rows, fails = passA(vecs)
    nok = sum(1 for r in rows if r["passA"])
    print(f"Pass A OK: {nok}/{len(rows)}")
    if fails:
        print("Pass A FAILURES:")
        for vid, iss in fails:
            print("  ", vid, iss)
    else:
        print("Pass A: 215/215 fully consistent (octets, decode-equality, embedded ids, machine_value, failure cross-check, namespace).")
    # save distilled rows
    with open("/home/gauss/Claude-Code-Lab/_staging/lci0-errata-verify/scratch/vector-marshal/passA_rows.json", "w") as f:
        json.dump(rows, f, indent=1, default=lambda o: list(o) if isinstance(o, tuple) else str(o))
